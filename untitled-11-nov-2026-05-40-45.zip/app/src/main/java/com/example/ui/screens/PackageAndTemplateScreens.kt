package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.WorkoutPackageEntity
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateCategory
import com.example.domain.model.TemplateMetadata
import com.example.domain.util.FormattersAndValidators
import com.example.render.CardRenderEngine
import com.example.ui.components.CardCanvasPreviewBox
import com.example.ui.components.TemplateLargePreviewBanner

@Composable
fun PackageConfigSubScreen(
    packages: List<WorkoutPackageEntity>,
    onBack: () -> Unit,
    onSavePackage: (WorkoutPackageEntity) -> Unit,
    onDeletePackage: (WorkoutPackageEntity) -> Unit,
    onResetDefaultPackagesForCategory: (CardType) -> Unit
) {
    var selectedType by remember { mutableStateOf(CardType.GYM_MONTHLY) }
    var selectedGroup by remember { mutableStateOf(TargetGroup.NAM) }
    var editingPkg by remember { mutableStateOf<WorkoutPackageEntity?>(null) }
    var isCreatingNew by remember { mutableStateOf(false) }
    var deletingPkg by remember { mutableStateOf<WorkoutPackageEntity?>(null) }
    var showResetConfirm by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    val filteredPackages = remember(packages, selectedType, selectedGroup) {
        packages.filter { pkg ->
            pkg.cardType == selectedType.code &&
                (selectedType != CardType.GYM_MONTHLY || pkg.targetGroup == selectedGroup.code)
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingPkg = null
                    isCreatingNew = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("fab_add_package")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Thêm gói tập")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("pkg_config_back_btn")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Cấu hình gói tập mặc định",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Tự động điền nhanh thời hạn, số buổi và giá tiền",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (selectedType != CardType.GYM_PT) {
                            IconButton(onClick = { showResetConfirm = true }) {
                                Icon(Icons.Default.Restore, contentDescription = "Khôi phục bảng giá mặc định")
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CardType.entries.forEach { type ->
                            FilterChip(
                                selected = selectedType == type,
                                onClick = { selectedType = type },
                                label = { Text(type.displayTitle) },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 38.dp)
                                    .testTag("settings_pkg_type_${type.code}")
                            )
                        }
                    }

                    if (selectedType == CardType.GYM_MONTHLY) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TargetGroup.entries.forEach { group ->
                                FilterChip(
                                    selected = selectedGroup == group,
                                    onClick = { selectedGroup = group },
                                    label = { Text("Nhóm ${group.displayLabel}") },
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 38.dp)
                                        .testTag("settings_pkg_group_${group.code}")
                                )
                            }
                        }
                    }
                }
            }

            if (filteredPackages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Chưa có gói tập nào cho ${selectedType.displayTitle}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Nhấn nút (+) ở góc dưới để tạo gói mới với thời hạn/số buổi và giá tiền chuẩn của 89 FITNESS & YOGA.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredPackages, key = { it.id }) { pkg ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .wrapContentHeight()
                                .testTag("pkg_row_${pkg.id}"),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = pkg.packageName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    val metaText = when (selectedType) {
                                        CardType.GYM_PT -> "Tổng số buổi: ${pkg.totalSessions ?: 1} buổi PT"
                                        else -> "Thời hạn: ${pkg.durationMonths ?: 1} tháng"
                                    }
                                    Text(
                                        text = metaText,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = FormattersAndValidators.formatVnd(pkg.priceVnd),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(
                                    onClick = {
                                        editingPkg = pkg
                                        isCreatingNew = false
                                    }
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Sửa gói")
                                }
                                IconButton(onClick = { deletingPkg = pkg }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Xóa gói",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (isCreatingNew || editingPkg != null) {
        val current = editingPkg
        var name by remember(current) { mutableStateOf(current?.packageName ?: "") }
        var durationOrSessions by remember(current) {
            mutableStateOf(
                when (selectedType) {
                    CardType.GYM_PT -> current?.totalSessions?.toString() ?: "12"
                    else -> current?.durationMonths?.toString() ?: "1"
                }
            )
        }
        var priceText by remember(current) {
            mutableStateOf(
                current?.priceVnd?.let { FormattersAndValidators.formatVndDigitsOnly(it) } ?: ""
            )
        }
        var validationError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = {
                isCreatingNew = false
                editingPkg = null
            },
            title = {
                Text(
                    if (current == null) "Thêm gói ${selectedType.displayTitle}"
                    else "Chỉnh sửa gói ${current.packageName}"
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (selectedType == CardType.GYM_MONTHLY) {
                        Text(
                            text = "Nhóm đối tượng: ${selectedGroup.displayLabel}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Tên gói (VD: 1 tháng, Gói 12 buổi) *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = durationOrSessions,
                        onValueChange = { durationOrSessions = it.filter { ch -> ch.isDigit() } },
                        label = {
                            Text(
                                if (selectedType == CardType.GYM_PT) "Tổng số buổi PT *"
                                else "Thời hạn (số tháng) *"
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { raw ->
                            val digits = raw.filter { it.isDigit() }.toLongOrNull()
                            priceText = if (digits != null) FormattersAndValidators.formatVndDigitsOnly(digits) else ""
                        },
                        label = { Text("Giá tiền mặc định (VNĐ) *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (validationError != null) {
                        Text(
                            text = validationError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cleanName = name.trim()
                        val num = durationOrSessions.toIntOrNull()
                        val price = FormattersAndValidators.parseVndInput(priceText)
                        if (cleanName.isEmpty() || num == null || num <= 0 || price == null) {
                            validationError = "Vui lòng nhập đầy đủ tên gói, số tháng/buổi (>0) và giá tiền."
                            return@Button
                        }
                        val entity = WorkoutPackageEntity(
                            id = current?.id ?: 0L,
                            cardType = selectedType.code,
                            targetGroup = if (selectedType == CardType.GYM_MONTHLY) selectedGroup.code else null,
                            packageName = cleanName,
                            durationMonths = if (selectedType != CardType.GYM_PT) num else null,
                            totalSessions = if (selectedType == CardType.GYM_PT) num else null,
                            priceVnd = price,
                            isDefaultSeed = current?.isDefaultSeed ?: false,
                            sortOrder = current?.sortOrder ?: num
                        )
                        onSavePackage(entity)
                        isCreatingNew = false
                        editingPkg = null
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        isCreatingNew = false
                        editingPkg = null
                    }
                ) {
                    Text("Hủy")
                }
            }
        )
    }

    if (deletingPkg != null) {
        val pkg = deletingPkg!!
        AlertDialog(
            onDismissRequest = { deletingPkg = null },
            title = { Text("Xác nhận xóa gói tập") },
            text = {
                Text("Bạn có chắc chắn muốn xóa gói '${pkg.packageName}' (${FormattersAndValidators.formatVnd(pkg.priceVnd)})?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePackage(pkg)
                        deletingPkg = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Xác nhận xóa")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingPkg = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Khôi phục bảng giá ${selectedType.displayTitle} mặc định") },
            text = {
                val msg = if (selectedType == CardType.GYM_MONTHLY) {
                    "Hệ thống sẽ khôi phục lại 12 gói Gym tháng chuẩn cho Nam, Nữ và Trẻ em theo bảng giá mặc định của 89 FITNESS & YOGA."
                } else {
                    "Hệ thống sẽ khôi phục lại 3 gói Yoga tháng chuẩn (1 tháng: 500.000đ, 2 tháng: 1.000.000đ, 3 tháng: 1.500.000đ)."
                }
                Text(msg)
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirm = false
                        onResetDefaultPackagesForCategory(selectedType)
                    }
                ) {
                    Text("Khôi phục")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}

/**
 * Redesigned Template Management Screen (Section 10.4 & Section 11):
 * - Title is strictly "QUẢN LÝ PHÔI THẺ" (no version string in title).
 * - Concise group description: Mặc định, Gym, Yoga, PT.
 * - 4 filter tabs tightly aligned below compact header with zero empty space below tabs.
 * - Single-column list with large full-width 8:5 preview thumbnails, full template name, style label,
 *   active status switch, default status, and compact management buttons using responsive heightIn.
 */
@Composable
fun TemplateConfigSubScreen(
    templates: List<TemplateMetadata>,
    brandConfig: BrandConfig,
    onBack: () -> Unit,
    onSetDefaultTemplate: (CardType, String) -> Unit,
    onSetDefaultTemplateForAll: (String) -> Unit,
    onToggleTemplateEnabled: (TemplateMetadata, Boolean) -> Unit,
    onRestoreAllTemplates: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf(TemplateCategory.UNIVERSAL) }
    var previewingTemplate by remember { mutableStateOf<TemplateMetadata?>(null) }
    var universalDefaultDialogTarget by remember { mutableStateOf<TemplateMetadata?>(null) }
    var showConfirmRestoreAll by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    val filteredTemplates = remember(templates, selectedCategory) {
        templates.filter { it.category == selectedCategory }.sortedBy { it.templateId }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Compact Top Header + 4 Category Filter Tabs (Section 10.4 & 11)
        Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("tpl_config_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "QUẢN LÝ PHÔI THẺ",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = selectedCategory.tabLabelVi,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = { showConfirmRestoreAll = true },
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("restore_all_templates_btn")
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = "Khôi phục 12 phôi gốc")
                    }
                }

                // 4 Category Tabs: Mặc định | Gym | Yoga | PT
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TemplateCategory.entries.forEach { cat ->
                        val count = templates.count { it.category == cat }
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = {
                                Text(
                                    text = "${cat.tabLabelVi} ($count)",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (selectedCategory == cat) FontWeight.Bold else FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 38.dp)
                                .testTag("tpl_tab_${cat.code}")
                        )
                    }
                }
            }
        }

        // Single-Column List with Large Full-Width 8:5 Thumbnails (Section 11)
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("template_management_single_col_list"),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(filteredTemplates, key = { it.templateId }) { template ->
                val accentColorInt = CardRenderEngine.parseHexColorSafe(
                    template.accentColorHex,
                    android.graphics.Color.RED
                )
                val defaultLabels = remember(template.defaultForCardTypes) {
                    template.defaultForCardTypes.map { it.displayTitle }
                }
                val defaultBadgeText = if (defaultLabels.isNotEmpty()) {
                    "Mặc định: ${defaultLabels.joinToString(", ")}"
                } else {
                    null
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        .alpha(if (template.isEnabled) 1f else 0.62f)
                        .testTag("settings_tpl_card_${template.templateId}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Large 8:5 Preview Thumbnail (Full Width, Uncropped)
                        TemplateLargePreviewBanner(
                            template = template,
                            brandName = brandConfig.brandName,
                            previewCardType = template.category.primaryPreviewCardType(),
                            isSelected = template.isDefault,
                            defaultBadgeText = defaultBadgeText,
                            onClick = { previewingTemplate = template }
                        )

                        // 2. Full Template Name + Style Label + Active Switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(Color(accentColorInt))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = template.templateName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${template.styleName} • ${template.imageSlot.shape.labelVi}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // Compact Active Switch
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (template.isEnabled) "Bật" else "Tắt",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (template.isEnabled) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Switch(
                                    checked = template.isEnabled,
                                    onCheckedChange = { checked ->
                                        onToggleTemplateEnabled(template, checked)
                                    },
                                    modifier = Modifier.testTag("switch_tpl_${template.templateId}")
                                )
                            }
                        }

                        HorizontalDivider()

                        // 3. Compact Preview & Set Default Actions (Responsive heightIn)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { previewingTemplate = template },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 44.dp)
                                    .wrapContentHeight()
                                    .testTag("btn_preview_tpl_${template.templateId}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Visibility,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Xem thử")
                            }

                            val targetSpecificCardType = when (template.category) {
                                TemplateCategory.GYM -> CardType.GYM_MONTHLY
                                TemplateCategory.YOGA -> CardType.YOGA_MONTHLY
                                TemplateCategory.PT -> CardType.GYM_PT
                                TemplateCategory.UNIVERSAL -> null
                            }

                            val isAlreadyDefaultForSpecific = targetSpecificCardType != null &&
                                template.isDefaultFor(targetSpecificCardType)
                            val isDefaultForAllThree = template.defaultForCardTypes.size == 3

                            Button(
                                onClick = {
                                    if (targetSpecificCardType != null) {
                                        onSetDefaultTemplate(targetSpecificCardType, template.templateId)
                                    } else {
                                        universalDefaultDialogTarget = template
                                    }
                                },
                                enabled = !(isAlreadyDefaultForSpecific || isDefaultForAllThree),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 44.dp)
                                    .wrapContentHeight()
                                    .testTag("btn_default_tpl_${template.templateId}")
                            ) {
                                Icon(
                                    imageVector = if (template.isDefault) Icons.Default.Star else Icons.Outlined.StarOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    when {
                                        isAlreadyDefaultForSpecific || isDefaultForAllThree -> "Đang mặc định"
                                        else -> "Đặt mặc định"
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog to choose which card type(s) a Universal template (A1, A2, A3) should be default for
    if (universalDefaultDialogTarget != null) {
        val tpl = universalDefaultDialogTarget!!
        AlertDialog(
            onDismissRequest = { universalDefaultDialogTarget = null },
            title = { Text("Đặt '${tpl.templateName}' làm mặc định") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Phôi Mặc định dùng chung tương thích với cả 3 loại thẻ. Chọn loại thẻ bạn muốn áp dụng làm mặc định:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    CardType.entries.forEach { cardType ->
                        val isCurrDefault = tpl.isDefaultFor(cardType)
                        OutlinedButton(
                            onClick = {
                                onSetDefaultTemplate(cardType, tpl.templateId)
                                universalDefaultDialogTarget = null
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 44.dp)
                                .wrapContentHeight()
                        ) {
                            Icon(
                                imageVector = if (isCurrDefault) Icons.Default.Star else Icons.Outlined.StarOutline,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (isCurrDefault) "${cardType.displayTitle} (Đang mặc định)"
                                else "Đặt mặc định cho ${cardType.displayTitle}"
                            )
                        }
                    }
                    Button(
                        onClick = {
                            onSetDefaultTemplateForAll(tpl.templateId)
                            universalDefaultDialogTarget = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 44.dp)
                            .wrapContentHeight()
                    ) {
                        Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Đặt mặc định cho cả 3 loại thẻ")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { universalDefaultDialogTarget = null }) {
                    Text("Đóng")
                }
            }
        )
    }

    // Full Preview Modal with Card-Type Switcher for Universal Templates
    if (previewingTemplate != null) {
        val tpl = previewingTemplate!!
        var previewCardType by remember(tpl) {
            mutableStateOf(tpl.category.primaryPreviewCardType())
        }
        val samplePayload = remember(tpl, brandConfig, previewCardType) {
            CardRenderEngine.buildSamplePayload(
                template = tpl,
                brandName = brandConfig.brandName,
                previewCardType = previewCardType
            ).copy(
                brandContact = brandConfig.contactInfo,
                brandLogoPath = brandConfig.customLogoPath
            )
        }

        AlertDialog(
            onDismissRequest = { previewingTemplate = null },
            title = {
                Text(tpl.templateName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (tpl.category == TemplateCategory.UNIVERSAL) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CardType.entries.forEach { ct ->
                                FilterChip(
                                    selected = previewCardType == ct,
                                    onClick = { previewCardType = ct },
                                    label = { Text(ct.shortCardLabelVi) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 38.dp)
                                )
                            }
                        }
                    }

                    CardCanvasPreviewBox(payload = samplePayload, template = tpl)

                    Text(
                        text = tpl.styleName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "• Nhóm phôi: ${tpl.category.tabLabelVi}\n" +
                            "• Khung ảnh: ${tpl.imageSlot.shape.labelVi} • Hộp thông tin: ${tpl.infoBoxStyle.labelVi}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                val targetType = if (tpl.category == TemplateCategory.UNIVERSAL) {
                    previewCardType
                } else {
                    tpl.category.primaryPreviewCardType()
                }
                if (!tpl.isDefaultFor(targetType)) {
                    Button(
                        onClick = {
                            onSetDefaultTemplate(targetType, tpl.templateId)
                            previewingTemplate = null
                        }
                    ) {
                        Text("Đặt mặc định (${targetType.displayTitle})")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { previewingTemplate = null }) {
                    Text("Đóng")
                }
            }
        )
    }

    if (showConfirmRestoreAll) {
        AlertDialog(
            onDismissRequest = { showConfirmRestoreAll = false },
            title = { Text("Khôi phục 12 phôi thẻ mặc định") },
            text = {
                Text("Hệ thống sẽ bật lại toàn bộ 12 phôi thiết kế chuẩn (3 Mặc định dùng chung A1–A3, 3 Gym G1–G3, 3 Yoga Y1–Y3, 3 PT P1–P3) và khôi phục phôi mặc định ban đầu.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmRestoreAll = false
                        onRestoreAllTemplates()
                    }
                ) {
                    Text("Khôi phục 12 phôi")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmRestoreAll = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}
