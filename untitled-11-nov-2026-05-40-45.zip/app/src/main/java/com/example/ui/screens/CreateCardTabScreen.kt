package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.WorkoutPackageEntity
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardDraft
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateCatalog
import com.example.domain.model.TemplateCategory
import com.example.domain.model.TemplateMetadata
import com.example.domain.util.FormattersAndValidators
import com.example.render.CardRenderEngine
import com.example.render.CardRenderPayload
import com.example.ui.components.CameraCaptureDialog
import com.example.ui.components.CardCanvasPreviewBox
import com.example.ui.components.FixedFrameCropper
import com.example.ui.components.TemplateLargePreviewBanner
import com.example.ui.viewmodel.BottomNavTab
import java.io.File

@Composable
fun CreateCardTabScreen(
    wizardStep: Int?,
    draft: CardDraft,
    packages: List<WorkoutPackageEntity>,
    templates: List<TemplateMetadata>,
    brandConfig: BrandConfig,
    hasUnsavedChanges: Boolean,
    isBusy: Boolean,
    onStartNewCard: (CardType) -> Unit,
    onNavigateTab: (BottomNavTab) -> Unit,
    onExitWizard: () -> Unit,
    onGoToStep: (Int) -> Unit,
    onSelectTemplate: (String) -> Unit,
    onTargetGroupChanged: (TargetGroup) -> Unit,
    onPackageSelected: (WorkoutPackageEntity) -> Unit,
    onUpdateDraftFields: (
        fullName: String?,
        phoneNumber: String?,
        durationMonthsText: String?,
        startDate: String?,
        endDate: String?,
        totalPtSessions: String?,
        priceVndText: String?
    ) -> Unit,
    onPhotoPickedFromDevice: (Uri) -> Unit,
    onPhotoCapturedFromCamera: (File) -> Unit,
    onUpdateCropTransform: (Float, Float, Float) -> Unit,
    onResetCropTransform: () -> Unit,
    onBuildDraftPayload: () -> CardRenderPayload,
    onExportPng: (CardRenderPayload) -> Unit,
    onExportPdf: (CardRenderPayload) -> Unit,
    onShareCard: (CardRenderPayload) -> Unit,
    onPostError: (String) -> Unit
) {
    if (wizardStep == null) {
        CreateCardHomeContent(
            brandConfig = brandConfig,
            templates = templates,
            onStartNewCard = onStartNewCard
        )
    } else {
        CardCreationWizardContent(
            step = wizardStep,
            draft = draft,
            packages = packages,
            templates = templates,
            brandConfig = brandConfig,
            hasUnsavedChanges = hasUnsavedChanges,
            isBusy = isBusy,
            onExitWizard = onExitWizard,
            onGoToStep = onGoToStep,
            onSelectTemplate = onSelectTemplate,
            onTargetGroupChanged = onTargetGroupChanged,
            onPackageSelected = onPackageSelected,
            onUpdateDraftFields = onUpdateDraftFields,
            onPhotoPickedFromDevice = onPhotoPickedFromDevice,
            onPhotoCapturedFromCamera = onPhotoCapturedFromCamera,
            onUpdateCropTransform = onUpdateCropTransform,
            onResetCropTransform = onResetCropTransform,
            onBuildDraftPayload = onBuildDraftPayload,
            onExportPng = onExportPng,
            onExportPdf = onExportPdf,
            onShareCard = onShareCard,
            onPostError = onPostError
        )
    }
}

/**
 * Clean, Focused Create Card Home Screen (Section 10.2 & 10.5):
 * - Header keeps ONLY Logo + Brand Name "89 FITNESS & YOGA" (no version string, no technical subtitle).
 * - Concise section header: "CHỌN LOẠI THẺ".
 * - Three category selection buttons: GYM THÁNG, GYM PT, YOGA THÁNG.
 * - Duplicate Settings button is completely removed (Bottom Navigation already provides Cài đặt).
 */
@Composable
private fun CreateCardHomeContent(
    brandConfig: BrandConfig,
    templates: List<TemplateMetadata>,
    onStartNewCard: (CardType) -> Unit
) {
    val gymCount = templates.count { it.isCompatibleWith(CardType.GYM_MONTHLY) && it.isEnabled }
    val ptCount = templates.count { it.isCompatibleWith(CardType.GYM_PT) && it.isEnabled }
    val yogaCount = templates.count { it.isCompatibleWith(CardType.YOGA_MONTHLY) && it.isEnabled }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF12151E))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val customLogo = brandConfig.customLogoPath?.takeIf { File(it).exists() }
                    if (customLogo != null) {
                        AsyncImage(
                            model = File(customLogo),
                            contentDescription = "Logo phòng tập",
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.img_app_logo_fg_1794306459132),
                            contentDescription = "Logo 89 FITNESS & YOGA",
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Text(
                        text = brandConfig.brandName.ifBlank { "89 FITNESS & YOGA" },
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            Text(
                text = "CHỌN LOẠI THẺ",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            CategoryCardButton(
                cardType = CardType.GYM_MONTHLY,
                templateCount = gymCount,
                accentColor = Color(0xFFE11D48),
                icon = Icons.Default.FitnessCenter,
                testTag = "select_card_gym_monthly",
                onClick = { onStartNewCard(CardType.GYM_MONTHLY) }
            )
        }

        item {
            CategoryCardButton(
                cardType = CardType.GYM_PT,
                templateCount = ptCount,
                accentColor = Color(0xFFD97706),
                icon = Icons.Default.SportsGymnastics,
                testTag = "select_card_gym_pt",
                onClick = { onStartNewCard(CardType.GYM_PT) }
            )
        }

        item {
            CategoryCardButton(
                cardType = CardType.YOGA_MONTHLY,
                templateCount = yogaCount,
                accentColor = Color(0xFF059669),
                icon = Icons.Default.SelfImprovement,
                testTag = "select_card_yoga_monthly",
                onClick = { onStartNewCard(CardType.YOGA_MONTHLY) }
            )
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CategoryCardButton(
    cardType: CardType,
    templateCount: Int,
    accentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(accentColor.copy(alpha = 0.14f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = cardType.displayTitle,
                    tint = accentColor,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = cardType.displayTitle.uppercase(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = accentColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "$templateCount phôi",
                            style = MaterialTheme.typography.labelMedium,
                            color = accentColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = cardType.subtitleVi,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Chọn phôi",
                tint = accentColor
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun CardCreationWizardContent(
    step: Int,
    draft: CardDraft,
    packages: List<WorkoutPackageEntity>,
    templates: List<TemplateMetadata>,
    brandConfig: BrandConfig,
    hasUnsavedChanges: Boolean,
    isBusy: Boolean,
    onExitWizard: () -> Unit,
    onGoToStep: (Int) -> Unit,
    onSelectTemplate: (String) -> Unit,
    onTargetGroupChanged: (TargetGroup) -> Unit,
    onPackageSelected: (WorkoutPackageEntity) -> Unit,
    onUpdateDraftFields: (
        fullName: String?,
        phoneNumber: String?,
        durationMonthsText: String?,
        startDate: String?,
        endDate: String?,
        totalPtSessions: String?,
        priceVndText: String?
    ) -> Unit,
    onPhotoPickedFromDevice: (Uri) -> Unit,
    onPhotoCapturedFromCamera: (File) -> Unit,
    onUpdateCropTransform: (Float, Float, Float) -> Unit,
    onResetCropTransform: () -> Unit,
    onBuildDraftPayload: () -> CardRenderPayload,
    onExportPng: (CardRenderPayload) -> Unit,
    onExportPdf: (CardRenderPayload) -> Unit,
    onShareCard: (CardRenderPayload) -> Unit,
    onPostError: (String) -> Unit
) {
    var showUnsavedExitDialog by remember { mutableStateOf(false) }
    var showCameraDialog by remember { mutableStateOf(false) }
    var datePickerTargetField by remember { mutableStateOf<String?>(null) }
    var step1FilterGroup by remember(draft.cardType) { mutableStateOf<TemplateCategory?>(null) }
    var modalPreviewTemplate by remember { mutableStateOf<TemplateMetadata?>(null) }

    // 6 compatible templates for this card type (3 Universal A1-A3 + 3 Category-Specific)
    val enabledCompatibleTemplates = remember(templates, draft.cardType) {
        TemplateCatalog.getCompatibleTemplatesForCardType(
            allTemplates = templates,
            cardType = draft.cardType,
            onlyEnabled = true
        )
    }

    val activeTemplate = remember(enabledCompatibleTemplates, draft.selectedTemplateId) {
        enabledCompatibleTemplates.firstOrNull { it.templateId == draft.selectedTemplateId }
            ?: enabledCompatibleTemplates.firstOrNull { it.isDefaultFor(draft.cardType) }
            ?: enabledCompatibleTemplates.first()
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPhotoPickedFromDevice(uri)
        }
    }

    val handleBackNavigation = {
        when {
            step > 1 -> onGoToStep(step - 1)
            hasUnsavedChanges -> showUnsavedExitDialog = true
            else -> onExitWizard()
        }
    }

    BackHandler(onBack = handleBackNavigation)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
    ) {
        // Compact Top Wizard Header & 4-Step Progress Bar
        Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = handleBackNavigation,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("wizard_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Tạo ${draft.cardType.shortCardLabelVi} (${draft.cardType.displayTitle})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Phôi đang chọn: ${activeTemplate.templateName}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    WizardStepPill(
                        stepNumber = 1,
                        label = "1. Chọn phôi",
                        currentStep = step,
                        onClick = { onGoToStep(1) },
                        modifier = Modifier.weight(1f)
                    )
                    WizardStepPill(
                        stepNumber = 2,
                        label = "2. Thông tin",
                        currentStep = step,
                        onClick = { onGoToStep(2) },
                        modifier = Modifier.weight(1f)
                    )
                    WizardStepPill(
                        stepNumber = 3,
                        label = "3. Ảnh",
                        currentStep = step,
                        onClick = { onGoToStep(3) },
                        modifier = Modifier.weight(1f)
                    )
                    WizardStepPill(
                        stepNumber = 4,
                        label = "4. Xuất thẻ",
                        currentStep = step,
                        onClick = { onGoToStep(4) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (step) {
                1 -> {
                    // STEP 1: SINGLE-COLUMN LARGE 8:5 TEMPLATE GALLERY (6 Compatible Templates)
                    val specificCat = TemplateCategory.specificCategoryFor(draft.cardType)
                    val universalCount = enabledCompatibleTemplates.count { it.category == TemplateCategory.UNIVERSAL }
                    val specificCount = enabledCompatibleTemplates.count { it.category == specificCat }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = step1FilterGroup == null,
                            onClick = { step1FilterGroup = null },
                            label = { Text("Tất cả (${enabledCompatibleTemplates.size})") },
                            modifier = Modifier
                                .heightIn(min = 38.dp)
                                .testTag("step1_filter_all")
                        )
                        FilterChip(
                            selected = step1FilterGroup == TemplateCategory.UNIVERSAL,
                            onClick = { step1FilterGroup = TemplateCategory.UNIVERSAL },
                            label = { Text("Mặc định ($universalCount)") },
                            modifier = Modifier
                                .heightIn(min = 38.dp)
                                .testTag("step1_filter_universal")
                        )
                        FilterChip(
                            selected = step1FilterGroup == specificCat,
                            onClick = { step1FilterGroup = specificCat },
                            label = { Text("${specificCat.tabLabelVi} ($specificCount)") },
                            modifier = Modifier
                                .heightIn(min = 38.dp)
                                .testTag("step1_filter_specific")
                        )
                    }

                    val displayedTemplates = remember(enabledCompatibleTemplates, step1FilterGroup) {
                        if (step1FilterGroup == null) {
                            enabledCompatibleTemplates
                        } else {
                            enabledCompatibleTemplates.filter { it.category == step1FilterGroup }
                        }
                    }

                    displayedTemplates.forEach { tpl ->
                        val isSelected = tpl.templateId == activeTemplate.templateId
                        val isDefaultForCurrentType = tpl.isDefaultFor(draft.cardType)
                        val accentInt = CardRenderEngine.parseHexColorSafe(
                            tpl.accentColorHex,
                            android.graphics.Color.RED
                        )

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .wrapContentHeight()
                                .clickable { onSelectTemplate(tpl.templateId) }
                                .testTag("step1_template_card_${tpl.templateId}"),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) {
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                                } else {
                                    MaterialTheme.colorScheme.surface
                                }
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.5.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // 1. Large 8:5 Preview Banner showing current cardType's sample data
                                TemplateLargePreviewBanner(
                                    template = tpl,
                                    brandName = brandConfig.brandName,
                                    previewCardType = draft.cardType,
                                    isSelected = isSelected,
                                    defaultBadgeText = if (isDefaultForCurrentType) "Mặc định (${draft.cardType.displayTitle})" else null,
                                    onClick = { onSelectTemplate(tpl.templateId) }
                                )

                                // 2. Full Template Name & Style Info
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(Color(accentInt))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = tpl.templateName,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${tpl.styleName} • ${tpl.imageSlot.shape.labelVi}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = tpl.category.tabLabelVi,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                // 3. Action Row: Xem thử phóng to & Chọn phôi này (Responsive heightIn)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { modalPreviewTemplate = tpl },
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 44.dp)
                                            .wrapContentHeight()
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Visibility,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Xem thử")
                                    }

                                    Button(
                                        onClick = {
                                            onSelectTemplate(tpl.templateId)
                                            onGoToStep(2)
                                        },
                                        modifier = Modifier
                                            .weight(1.35f)
                                            .heightIn(min = 44.dp)
                                            .wrapContentHeight()
                                            .testTag("btn_use_template_${tpl.templateId}")
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Tiếp tục với phôi này", fontWeight = FontWeight.Bold)
                                        } else {
                                            Text("Chọn phôi này", fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { onGoToStep(2) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 50.dp)
                            .wrapContentHeight()
                            .testTag("step1_next_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Dùng phôi '${activeTemplate.templateName}' & Nhập thông tin",
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    }
                }

                2 -> {
                    // STEP 2: MEMBER INFORMATION FORM (Dynamic Data)
                    if (draft.cardType == CardType.GYM_MONTHLY) {
                        Text(
                            text = "Nhóm đối tượng (Nam / Nữ / Trẻ em)",
                            style = MaterialTheme.typography.labelLarge
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            TargetGroup.entries.forEach { group ->
                                val selected = draft.targetGroup == group
                                FilterChip(
                                    selected = selected,
                                    onClick = { onTargetGroupChanged(group) },
                                    label = {
                                        Text(
                                            text = group.displayLabel,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 48.dp)
                                        .testTag("target_group_chip_${group.code}")
                                )
                            }
                        }
                    }

                    val availablePackages = packages.filter { pkg ->
                        pkg.cardType == draft.cardType.code &&
                            (draft.cardType != CardType.GYM_MONTHLY || pkg.targetGroup == draft.targetGroup.code)
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Chọn gói tập cấu hình sẵn (Tự động điền - vẫn có thể sửa)",
                            style = MaterialTheme.typography.labelLarge
                        )
                        if (availablePackages.isEmpty()) {
                            Text(
                                text = "Chưa có gói cố định. Bạn có thể nhập trực tiếp bên dưới hoặc thêm gói trong Cài đặt.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                availablePackages.forEach { pkg ->
                                    val isSelected = draft.selectedPackageId == pkg.id
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { onPackageSelected(pkg) },
                                        label = {
                                            Text(
                                                text = "${pkg.packageName} • ${FormattersAndValidators.formatVnd(pkg.priceVnd)}"
                                            )
                                        },
                                        modifier = Modifier
                                            .heightIn(min = 40.dp)
                                            .testTag("pkg_chip_${pkg.id}")
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = draft.fullName,
                        onValueChange = { onUpdateDraftFields(it, null, null, null, null, null, null) },
                        label = { Text("Họ và tên hội viên *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_full_name")
                    )

                    OutlinedTextField(
                        value = draft.phoneNumber,
                        onValueChange = { onUpdateDraftFields(null, it, null, null, null, null, null) },
                        label = { Text("Số điện thoại *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_phone_number")
                    )

                    if (draft.cardType == CardType.GYM_MONTHLY || draft.cardType == CardType.YOGA_MONTHLY) {
                        OutlinedTextField(
                            value = draft.durationMonthsText,
                            onValueChange = { input ->
                                val clean = input.filter { it.isDigit() }
                                onUpdateDraftFields(null, null, clean, null, null, null, null)
                            },
                            label = { Text("Thời hạn gói (Số tháng) *") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_duration_months")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = draft.startDate,
                                onValueChange = {
                                    onUpdateDraftFields(null, null, null, it, null, null, null)
                                },
                                label = { Text("Ngày bắt đầu *") },
                                placeholder = { Text("DD/MM/YYYY") },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(onClick = { datePickerTargetField = "start" }) {
                                        Icon(Icons.Default.CalendarMonth, contentDescription = "Chọn ngày bắt đầu")
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_start_date")
                            )

                            OutlinedTextField(
                                value = draft.endDate,
                                onValueChange = {
                                    onUpdateDraftFields(null, null, null, null, it, null, null)
                                },
                                label = { Text("Ngày hết hạn *") },
                                placeholder = { Text("DD/MM/YYYY") },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(onClick = { datePickerTargetField = "end" }) {
                                        Icon(Icons.Default.CalendarMonth, contentDescription = "Chọn ngày hết hạn")
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_end_date")
                            )
                        }
                    }

                    if (draft.cardType == CardType.GYM_PT) {
                        OutlinedTextField(
                            value = draft.totalPtSessions,
                            onValueChange = { input ->
                                val clean = input.filter { it.isDigit() }
                                onUpdateDraftFields(null, null, null, null, null, clean, null)
                            },
                            label = { Text("Tổng số buổi PT đã mua *") },
                            placeholder = { Text("Ví dụ: 12, 24, 36...") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_pt_sessions")
                        )
                    }

                    val parsedPrice = FormattersAndValidators.parseVndInput(draft.priceVndText)
                    OutlinedTextField(
                        value = draft.priceVndText,
                        onValueChange = { input ->
                            val digits = input.filter { it.isDigit() }.toLongOrNull()
                            val formatted = if (digits != null) {
                                FormattersAndValidators.formatVndDigitsOnly(digits)
                            } else {
                                ""
                            }
                            onUpdateDraftFields(null, null, null, null, null, null, formatted)
                        },
                        label = { Text("Giá tiền (VNĐ) *") },
                        supportingText = {
                            Text(
                                text = if (parsedPrice != null) {
                                    "Hiển thị trên thẻ: ${FormattersAndValidators.formatVnd(parsedPrice)}"
                                } else {
                                    "Nhập số tiền VNĐ"
                                }
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_price_vnd")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onGoToStep(1) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp)
                                .wrapContentHeight(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Đổi phôi thẻ")
                        }
                        Button(
                            onClick = { onGoToStep(3) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp)
                                .wrapContentHeight()
                                .testTag("step2_next_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Tiếp tục: Ảnh", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                3 -> {
                    // STEP 3: PHOTO CAPTURE/PICK & MULTI-SHAPE FIXED-FRAME CROPPER
                    Text(
                        text = "Chụp hoặc chọn ảnh hội viên (Tự động lưu bản gốc vào Pictures/89FitnessYoga/MemberPhotos/)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { showCameraDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .wrapContentHeight()
                                .testTag("btn_open_camera"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chụp ảnh")
                        }

                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .wrapContentHeight()
                                .testTag("btn_pick_gallery_photo"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chọn từ thiết bị")
                        }
                    }

                    if (!draft.sharedMediaStorePath.isNullOrBlank()) {
                        Text(
                            text = "Đã lưu ảnh gốc tại: ${draft.sharedMediaStorePath}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    val activePhotoPath = draft.originalPhotoPath
                    if (!activePhotoPath.isNullOrBlank() && File(activePhotoPath).exists()) {
                        FixedFrameCropper(
                            photoPath = activePhotoPath,
                            imageSlot = activeTemplate.imageSlot,
                            accentColorHex = activeTemplate.accentColorHex,
                            cropScale = draft.cropScale,
                            cropOffsetX = draft.cropOffsetX,
                            cropOffsetY = draft.cropOffsetY,
                            onTransformChanged = onUpdateCropTransform,
                            onResetTransform = onResetCropTransform
                        )
                    } else {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddAPhoto,
                                    contentDescription = null,
                                    modifier = Modifier.size(48.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Chưa có ảnh hội viên",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Khung ảnh của phôi '${activeTemplate.templateName}' sử dụng định dạng ${activeTemplate.imageSlot.shape.labelVi}.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onGoToStep(2) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp)
                                .wrapContentHeight()
                                .testTag("step3_back_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Quay lại Thông tin")
                        }
                        Button(
                            onClick = { onGoToStep(4) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp)
                                .wrapContentHeight()
                                .testTag("step3_next_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Xem trước & Xuất thẻ", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                4 -> {
                    // STEP 4: PREVIEW, LOSSLESS TEMPLATE SWITCHER & EXPORT (PNG / PDF / SHARE)
                    val payload = onBuildDraftPayload()

                    Text(
                        text = "Bản xem trước chính xác (${activeTemplate.templateName} • Tỷ lệ 8:5)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    CardCanvasPreviewBox(
                        payload = payload,
                        template = activeTemplate,
                        modifier = Modifier.testTag("step4_card_preview_box")
                    )

                    // Quick Template Switcher across all 6 compatible templates (Part 14: Preserves 100% of entered data & photo)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Đổi nhanh giữa ${enabledCompatibleTemplates.size} phôi tương thích (Giữ nguyên 100% thông tin & ảnh gốc):",
                            style = MaterialTheme.typography.labelLarge
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            enabledCompatibleTemplates.forEach { tpl ->
                                FilterChip(
                                    selected = tpl.templateId == activeTemplate.templateId,
                                    onClick = { onSelectTemplate(tpl.templateId) },
                                    label = { Text(tpl.templateName) },
                                    modifier = Modifier
                                        .heightIn(min = 38.dp)
                                        .testTag("preview_switch_tpl_${tpl.templateId}")
                                )
                            }
                        }
                    }

                    // Quick Edit Navigation Buttons (Responsive heightIn)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onGoToStep(1) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 44.dp)
                                .wrapContentHeight(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.ColorLens, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Bộ phôi")
                        }
                        OutlinedButton(
                            onClick = { onGoToStep(2) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 44.dp)
                                .wrapContentHeight()
                                .testTag("step4_edit_info_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sửa TT")
                        }
                        OutlinedButton(
                            onClick = { onGoToStep(3) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 44.dp)
                                .wrapContentHeight()
                                .testTag("step4_edit_photo_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Căn ảnh")
                        }
                    }

                    HorizontalDivider()

                    // Primary Export PNG & Direct Share Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onExportPng(payload) },
                            enabled = !isBusy,
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 52.dp)
                                .wrapContentHeight()
                                .testTag("btn_export_png"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Lưu PNG", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onShareCard(payload) },
                            enabled = !isBusy,
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 52.dp)
                                .wrapContentHeight()
                                .testTag("btn_share_direct"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            )
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chia sẻ ngay", fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = { onExportPdf(payload) },
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .wrapContentHeight()
                            .testTag("btn_export_pdf"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Xuất PDF (Lưu vào Downloads/89FitnessYoga/)")
                    }
                }
            }
        }
    }

    // Modal Preview in Step 1
    if (modalPreviewTemplate != null) {
        val tpl = modalPreviewTemplate!!
        val sampleOrDraftPayload = remember(tpl, draft, brandConfig) {
            if (draft.fullName.isNotBlank()) {
                onBuildDraftPayload().copy(templateId = tpl.templateId)
            } else {
                CardRenderEngine.buildSamplePayload(
                    template = tpl,
                    brandName = brandConfig.brandName,
                    previewCardType = draft.cardType
                ).copy(
                    brandContact = brandConfig.contactInfo,
                    brandLogoPath = brandConfig.customLogoPath
                )
            }
        }

        AlertDialog(
            onDismissRequest = { modalPreviewTemplate = null },
            title = {
                Text(tpl.templateName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CardCanvasPreviewBox(payload = sampleOrDraftPayload, template = tpl)
                    Text(
                        text = tpl.styleName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "• Nhóm phôi: ${tpl.category.tabLabelVi} • Khung ảnh: ${tpl.imageSlot.shape.labelVi}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSelectTemplate(tpl.templateId)
                        modalPreviewTemplate = null
                        onGoToStep(2)
                    }
                ) {
                    Text("Chọn phôi này & Tiếp tục")
                }
            },
            dismissButton = {
                TextButton(onClick = { modalPreviewTemplate = null }) {
                    Text("Đóng")
                }
            }
        )
    }

    if (datePickerTargetField != null) {
        val currentFieldText = if (datePickerTargetField == "start") draft.startDate else draft.endDate
        val initialMillis = FormattersAndValidators.parseDdMmYyyyToUtcMillis(currentFieldText)
            ?: System.currentTimeMillis()
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)

        DatePickerDialog(
            onDismissRequest = { datePickerTargetField = null },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedMillis = pickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            val formatted = FormattersAndValidators.formatUtcMillisToDdMmYyyy(selectedMillis)
                            if (datePickerTargetField == "start") {
                                onUpdateDraftFields(null, null, null, formatted, null, null, null)
                            } else {
                                onUpdateDraftFields(null, null, null, null, formatted, null, null)
                            }
                        }
                        datePickerTargetField = null
                    }
                ) {
                    Text("Chọn ngày")
                }
            },
            dismissButton = {
                TextButton(onClick = { datePickerTargetField = null }) {
                    Text("Hủy")
                }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }

    if (showCameraDialog) {
        CameraCaptureDialog(
            onDismiss = { showCameraDialog = false },
            onPhotoCaptured = { file ->
                showCameraDialog = false
                onPhotoCapturedFromCamera(file)
            },
            onError = { msg ->
                showCameraDialog = false
                onPostError(msg)
            }
        )
    }

    if (showUnsavedExitDialog) {
        AlertDialog(
            onDismissRequest = { showUnsavedExitDialog = false },
            title = { Text("Dữ liệu thẻ đang nhập") },
            text = {
                Text("Bạn đang tạo thẻ hội viên nhưng chưa xuất thẻ. (Ảnh gốc hội viên nếu đã chụp/chọn vẫn được giữ nguyên trong Pictures/89FitnessYoga/MemberPhotos/).")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnsavedExitDialog = false
                        onExitWizard()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Thoát về trang chủ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnsavedExitDialog = false }) {
                    Text("Tiếp tục tạo thẻ")
                }
            }
        )
    }
}

@Composable
private fun WizardStepPill(
    stepNumber: Int,
    label: String,
    currentStep: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isCurrent = currentStep == stepNumber
    val isCompleted = currentStep > stepNumber
    val bgColor = when {
        isCurrent -> MaterialTheme.colorScheme.primary
        isCompleted -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val textColor = when {
        isCurrent -> MaterialTheme.colorScheme.onPrimary
        isCompleted -> MaterialTheme.colorScheme.onPrimaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = modifier
            .heightIn(min = 36.dp)
            .wrapContentHeight()
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = textColor,
            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
