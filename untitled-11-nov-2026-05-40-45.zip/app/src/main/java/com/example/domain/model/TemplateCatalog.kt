package com.example.domain.model

object TemplateCatalog {

    fun allBuiltInTemplates(): List<TemplateMetadata> =
        universalTemplates() + gymTemplates() + yogaTemplates() + ptTemplates()

    fun getInitialDefaultTemplateIdForCategory(cardType: CardType): String = when (cardType) {
        CardType.GYM_MONTHLY -> "g1_athletic_performance"
        CardType.YOGA_MONTHLY -> "y1_zen_minimal"
        CardType.GYM_PT -> "p1_elite_personal_trainer"
    }

    fun getCompatibleTemplatesForCardType(
        allTemplates: List<TemplateMetadata>,
        cardType: CardType,
        onlyEnabled: Boolean = true
    ): List<TemplateMetadata> {
        val filtered = allTemplates.filter { tpl ->
            tpl.isCompatibleWith(cardType) && (!onlyEnabled || tpl.isEnabled)
        }
        return if (filtered.isNotEmpty()) {
            filtered
        } else {
            allBuiltInTemplates().filter { it.isCompatibleWith(cardType) }
        }
    }

    // =========================================================================
    // NHÓM A – 3 PHÔI MẶC ĐỊNH DÙNG CHUNG (UNIVERSAL: GYM • YOGA • PT)
    // =========================================================================
    fun universalTemplates(): List<TemplateMetadata> = listOf(
        // A1 – Universal Premium (Royal Navy Sapphire & Warm Champagne Gold Silk)
        TemplateMetadata(
            templateId = "a1_universal_premium",
            templateVersion = 5,
            category = TemplateCategory.UNIVERSAL,
            templateName = "A1 – Universal Premium",
            styleName = "Xanh Sapphire & Vàng Champagne • Sang trọng tinh tế",
            backgroundColorHex = "#101E38",
            secondaryColorHex = "#1E325C",
            accentColorHex = "#E5C158",
            textPrimaryHex = "#FFFDF9",
            textSecondaryHex = "#DCE7F7",
            priceHighlightHex = "#FDE047",
            headerStyle = HeaderLayoutStyle.STANDARD_SPLIT,
            infoBoxStyle = InfoBoxStyle.FILLED_GLASS,
            artworkPattern = ArtworkPatternStyle.A1_UNIVERSAL_PREMIUM,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.032f,
                shape = PhotoFrameShape.ROUNDED_RECT
            )
        ),

        // A2 – Universal Modern Minimal (Bright Alabaster Cream, Cobalt Blue & Coral Accent)
        TemplateMetadata(
            templateId = "a2_universal_minimal",
            templateVersion = 5,
            category = TemplateCategory.UNIVERSAL,
            templateName = "A2 – Universal Modern Minimal",
            styleName = "Nền Trắng Ngà Tối Giản • Xanh Cobalt Hiện Đại",
            backgroundColorHex = "#FAF8F5",
            secondaryColorHex = "#EFECE6",
            accentColorHex = "#1D4ED8",
            textPrimaryHex = "#0F172A",
            textSecondaryHex = "#334155",
            priceHighlightHex = "#DC2626",
            headerStyle = HeaderLayoutStyle.MINIMAL_CLEAN,
            infoBoxStyle = InfoBoxStyle.MINIMAL_HAIRLINE,
            artworkPattern = ArtworkPatternStyle.A2_UNIVERSAL_MINIMAL,
            contentLeftRatio = 0.055f,
            contentRightRatio = 0.635f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.675f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.025f,
                shape = PhotoFrameShape.ROUNDED_RECT
            )
        ),

        // A3 – Universal Futuristic (Deep Indigo, Electric Blue & Luminous Cyan Geometry)
        TemplateMetadata(
            templateId = "a3_universal_futuristic",
            templateVersion = 5,
            category = TemplateCategory.UNIVERSAL,
            templateName = "A3 – Universal Futuristic",
            styleName = "Xanh Lam Điện Tử & Khối Đa Diện Công Nghệ",
            backgroundColorHex = "#0F1A36",
            secondaryColorHex = "#1E3A8A",
            accentColorHex = "#06B6D4",
            textPrimaryHex = "#F8FAFC",
            textSecondaryHex = "#CBD5E1",
            priceHighlightHex = "#38BDF8",
            headerStyle = HeaderLayoutStyle.TECH_HUD,
            infoBoxStyle = InfoBoxStyle.OUTLINE_SHARP,
            artworkPattern = ArtworkPatternStyle.A3_UNIVERSAL_FUTURISTIC,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.03f,
                shape = PhotoFrameShape.CHAMFERED_OCTAGON
            )
        )
    )

    // =========================================================================
    // NHÓM B – 3 PHÔI GYM MONTHLY CHUYÊN BIỆT
    // =========================================================================
    fun gymTemplates(): List<TemplateMetadata> = listOf(
        // G1 – Athletic Performance (Crimson Red, Carbon & Dynamic Gold Motion)
        TemplateMetadata(
            templateId = "g1_athletic_performance",
            templateVersion = 5,
            category = TemplateCategory.GYM,
            templateName = "G1 – Athletic Performance",
            styleName = "Đỏ Thể Thao & Carbon Chuyển Động Năng Lượng",
            backgroundColorHex = "#181B24",
            secondaryColorHex = "#2A1621",
            accentColorHex = "#E11D48",
            textPrimaryHex = "#FFFFFF",
            textSecondaryHex = "#E2E8F0",
            priceHighlightHex = "#FACC15",
            headerStyle = HeaderLayoutStyle.STANDARD_SPLIT,
            infoBoxStyle = InfoBoxStyle.FILLED_GLASS,
            artworkPattern = ArtworkPatternStyle.G1_ATHLETIC_PERFORMANCE,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.03f,
                shape = PhotoFrameShape.CUT_CORNER
            ),
            defaultForCardTypes = setOf(CardType.GYM_MONTHLY)
        ),

        // G2 – Luxury Black & Gold (Warm Brushed Bronze, Obsidian & Metallic Champagne Gold)
        TemplateMetadata(
            templateId = "g2_luxury_black_gold",
            templateVersion = 5,
            category = TemplateCategory.GYM,
            templateName = "G2 – Luxury Black & Gold",
            styleName = "Đen Ánh Đồng & Vàng Kim Loại Hoàng Gia",
            backgroundColorHex = "#141210",
            secondaryColorHex = "#29231C",
            accentColorHex = "#D4AF37",
            textPrimaryHex = "#FFFBEB",
            textSecondaryHex = "#E7E5E4",
            priceHighlightHex = "#FDE047",
            headerStyle = HeaderLayoutStyle.CENTERED_CREST,
            infoBoxStyle = InfoBoxStyle.OUTLINE_SHARP,
            artworkPattern = ArtworkPatternStyle.G2_LUXURY_BLACK_GOLD,
            contentLeftRatio = 0.055f,
            contentRightRatio = 0.635f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.675f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.135f,
                shape = PhotoFrameShape.ARCH_TOP
            )
        ),

        // G3 – Bold Sport Editorial (High-Contrast Daylight White, Stark Black & Sport Orange)
        TemplateMetadata(
            templateId = "g3_bold_sport_editorial",
            templateVersion = 5,
            category = TemplateCategory.GYM,
            templateName = "G3 – Bold Sport Editorial",
            styleName = "Tạp Chí Thể Thao Tương Phản Trắng – Đen – Cam",
            backgroundColorHex = "#F5F5F7",
            secondaryColorHex = "#E5E7EB",
            accentColorHex = "#EA580C",
            textPrimaryHex = "#111827",
            textSecondaryHex = "#374151",
            priceHighlightHex = "#C2410C",
            headerStyle = HeaderLayoutStyle.EDITORIAL_SIDEBAR,
            infoBoxStyle = InfoBoxStyle.EDITORIAL_COLUMN,
            artworkPattern = ArtworkPatternStyle.G3_BOLD_SPORT_EDITORIAL,
            contentLeftRatio = 0.095f,
            contentRightRatio = 0.645f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.68f,
                yRatio = 0.215f,
                widthRatio = 0.265f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.03f,
                shape = PhotoFrameShape.CUT_CORNER
            )
        )
    )

    // =========================================================================
    // NHÓM C – 3 PHÔI YOGA MONTHLY CHUYÊN BIỆT (TÔNG SÁNG / WELLNESS THANH LỊCH)
    // =========================================================================
    fun yogaTemplates(): List<TemplateMetadata> = listOf(
        // Y1 – Zen Minimal (Warm Ivory, Soft Oat & Sage Green)
        TemplateMetadata(
            templateId = "y1_zen_minimal",
            templateVersion = 5,
            category = TemplateCategory.YOGA,
            templateName = "Y1 – Zen Minimal",
            styleName = "Trắng Ngà & Xanh Sage • Không Gian Thiền Thư Giãn",
            backgroundColorHex = "#FBF9F4",
            secondaryColorHex = "#F0EAE0",
            accentColorHex = "#2E6F40",
            textPrimaryHex = "#163022",
            textSecondaryHex = "#3E5C4B",
            priceHighlightHex = "#14532D",
            headerStyle = HeaderLayoutStyle.MINIMAL_CLEAN,
            infoBoxStyle = InfoBoxStyle.PILL_CARD,
            artworkPattern = ArtworkPatternStyle.Y1_ZEN_MINIMAL,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.135f,
                shape = PhotoFrameShape.ARCH_TOP
            ),
            defaultForCardTypes = setOf(CardType.YOGA_MONTHLY)
        ),

        // Y2 – Botanical Elegance (Soft Botanical Cream, Emerald Leaf & Terracotta Earth)
        TemplateMetadata(
            templateId = "y2_botanical_elegance",
            templateVersion = 5,
            category = TemplateCategory.YOGA,
            templateName = "Y2 – Botanical Elegance",
            styleName = "Kem Thảo Mộc & Lá Xanh Tự Nhiên Thanh Lịch",
            backgroundColorHex = "#F2F8F4",
            secondaryColorHex = "#DCECE2",
            accentColorHex = "#1E603C",
            textPrimaryHex = "#0F291E",
            textSecondaryHex = "#2E5644",
            priceHighlightHex = "#B45309",
            headerStyle = HeaderLayoutStyle.STANDARD_SPLIT,
            infoBoxStyle = InfoBoxStyle.PILL_CARD,
            artworkPattern = ArtworkPatternStyle.Y2_BOTANICAL_ELEGANCE,
            contentLeftRatio = 0.055f,
            contentRightRatio = 0.635f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.675f,
                yRatio = 0.215f,
                widthRatio = 0.265f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.132f,
                shape = PhotoFrameShape.OVAL_PILL
            )
        ),

        // Y3 – Luxury Wellness (Soft Lavender Ivory, Champagne Rose & Lotus Plum)
        TemplateMetadata(
            templateId = "y3_luxury_wellness",
            templateVersion = 5,
            category = TemplateCategory.YOGA,
            templateName = "Y3 – Luxury Wellness",
            styleName = "Tím Lavender Sáng & Hoa Sen Champagne Cao Cấp",
            backgroundColorHex = "#FAF6FC",
            secondaryColorHex = "#F1E6F7",
            accentColorHex = "#7E22CE",
            textPrimaryHex = "#2E1042",
            textSecondaryHex = "#583570",
            priceHighlightHex = "#9D174D",
            headerStyle = HeaderLayoutStyle.CENTERED_CREST,
            infoBoxStyle = InfoBoxStyle.PILL_CARD,
            artworkPattern = ArtworkPatternStyle.Y3_LUXURY_WELLNESS,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.23f,
                widthRatio = 0.265f,
                heightRatio = 0.52f,
                cornerRadiusRatio = 0.13f,
                shape = PhotoFrameShape.CIRCLE
            )
        )
    )

    // =========================================================================
    // NHÓM D – 3 PHÔI GYM PT CHUYÊN BIỆT
    // =========================================================================
    fun ptTemplates(): List<TemplateMetadata> = listOf(
        // P1 – Elite Personal Trainer (Deep Gunmetal, Rich Amber Gold & Bold PT Badge)
        TemplateMetadata(
            templateId = "p1_elite_personal_trainer",
            templateVersion = 5,
            category = TemplateCategory.PT,
            templateName = "P1 – Elite Personal Trainer",
            styleName = "Huấn Luyện Viên Cá Nhân Cao Cấp • Nhấn Số Buổi PT",
            backgroundColorHex = "#141822",
            secondaryColorHex = "#222938",
            accentColorHex = "#F59E0B",
            textPrimaryHex = "#FFFFFF",
            textSecondaryHex = "#E2E8F0",
            priceHighlightHex = "#FDE047",
            headerStyle = HeaderLayoutStyle.STANDARD_SPLIT,
            infoBoxStyle = InfoBoxStyle.FILLED_GLASS,
            artworkPattern = ArtworkPatternStyle.P1_ELITE_PERSONAL_TRAINER,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.03f,
                shape = PhotoFrameShape.CUT_CORNER
            ),
            defaultForCardTypes = setOf(CardType.GYM_PT)
        ),

        // P2 – Performance Lab (Bright Technical Ice Silver, Deep Navy & Telemetry Cyan)
        TemplateMetadata(
            templateId = "p2_performance_lab",
            templateVersion = 5,
            category = TemplateCategory.PT,
            templateName = "P2 – Performance Lab",
            styleName = "Phòng Lab Hiệu Suất Sáng • Thông Số Kỹ Thuật Chính Xác",
            backgroundColorHex = "#F1F5F9",
            secondaryColorHex = "#E2E8F0",
            accentColorHex = "#0284C7",
            textPrimaryHex = "#0F172A",
            textSecondaryHex = "#334155",
            priceHighlightHex = "#059669",
            headerStyle = HeaderLayoutStyle.TECH_HUD,
            infoBoxStyle = InfoBoxStyle.OUTLINE_SHARP,
            artworkPattern = ArtworkPatternStyle.P2_PERFORMANCE_LAB,
            contentLeftRatio = 0.055f,
            contentRightRatio = 0.635f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.675f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.025f,
                shape = PhotoFrameShape.ROUNDED_RECT
            )
        ),

        // P3 – Black Titanium (Brushed Titanium Metal, Silver Champagne & Crimson Power)
        TemplateMetadata(
            templateId = "p3_black_titanium",
            templateVersion = 5,
            category = TemplateCategory.PT,
            templateName = "P3 – Black Titanium",
            styleName = "Kim Loại Titanium Xước • Đỏ & Bạc Độc Quyền",
            backgroundColorHex = "#181B22",
            secondaryColorHex = "#272C36",
            accentColorHex = "#EF4444",
            textPrimaryHex = "#FFFFFF",
            textSecondaryHex = "#E2E8F0",
            priceHighlightHex = "#FDE047",
            headerStyle = HeaderLayoutStyle.EDITORIAL_SIDEBAR,
            infoBoxStyle = InfoBoxStyle.EDITORIAL_COLUMN,
            artworkPattern = ArtworkPatternStyle.P3_BLACK_TITANIUM,
            contentLeftRatio = 0.375f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.085f,
                yRatio = 0.215f,
                widthRatio = 0.26f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.02f,
                shape = PhotoFrameShape.CHAMFERED_OCTAGON
            )
        )
    )
}
