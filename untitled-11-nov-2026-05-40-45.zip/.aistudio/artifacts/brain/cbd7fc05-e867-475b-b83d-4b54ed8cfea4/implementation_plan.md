# 89 FITNESS & YOGA – Nâng Cấp Hệ Thống Thiết Kế 12 Phôi Thẻ Cao Cấp & Sửa Lỗi UI/UX Thực Tế

Bản nâng cấp này tái định hình toàn diện chất lượng thiết kế đồ họa của 12 phôi thẻ hội viên theo hướng sang trọng, giàu chiều sâu, làm nổi bật tuyệt đối thông tin và ảnh hội viên, đồng thời sửa triệt để các lỗi giao diện, tràn chữ và tương thích hiển thị thực tế trên màn hình Android 12 / MIUI 13.0.7.

## User Review & Critical Decisions

> [!IMPORTANT]
> Các định hướng thiết kế và trải nghiệm dưới đây đã được xác nhận và thống nhất để triển khai trực tiếp vào mã nguồn hiện tại mà không làm xáo trộn nghiệp vụ thu ngân.

- **Confirmed Decision 1 (Phân bổ bảng màu Sáng – Trung tính – Đậm)**: Tùy chỉnh theo bản sắc từng nhóm: các phôi **Yoga (`Y1–Y3`)**, **Universal Minimal (`A2`)** và **Sport Editorial (`G3`)** sử dụng tông nền sáng/kem/ngà/sage/lavender thanh lịch, giàu sức sống; các phôi **Gym (`G1, G2`)**, **PT (`P1–P3`)** và **Universal (`A1, A3`)** sử dụng bảng màu tương phản mạnh (Navy, Obsidian Gold, Crimson, Titanium, Electric Cyan) có chiều sâu ánh sáng thay vì nền đen phẳng đơn điệu.
- **Confirmed Decision 2 (Kết hợp Artwork Nền Nghệ thuật 8:5 & Lớp Đồ họa Vector/Canvas)**: Tận dụng công cụ tạo ảnh (Nano Banana) để sinh các lớp nền nghệ thuật tỷ lệ chuẩn `8:5` (không chứa chữ giả hay logo AI) cho các nhóm chủ đề (Gym năng lượng, Yoga thảo mộc/hoa sen, PT phòng lab/kim loại, Universal trừu tượng sang trọng), kết hợp cùng bộ dựng Vector/Canvas sắc nét cho khung hình học, đường viền kim loại, hệ thống icon và chữ động theo đúng độ phân giải đích (`1×`, `1.5×`, `2×`).
- **Confirmed Decision 3 (Làm nổi bật thông tin hội viên bằng Panel tương phản & Badge điểm nhấn)**: Thiết kế bố cục đa dạng theo từng phôi; sử dụng các vùng Panel tương phản cao (nền sáng có thẻ thông tin rõ nét, nền đậm có hộp kính/khung sáng tách biệt) kết hợp **Huy hiệu (Badge) nổi bật riêng cho Thời hạn gói / Số buổi PT và Giá tiền**, đảm bảo thứ tự ưu tiên thị giác: *1. Tên hội viên → 2. Ảnh hội viên → 3. Thời hạn / Số buổi PT → 4. Ngày hết hạn → 5. Giá tiền → 6. Số điện thoại → 7. Giới tính & Ngày bắt đầu → 8. Thương hiệu*.
- **Confirmed Decision 4 (Sửa triệt để các lỗi UI/UX trong mã nguồn hiện tại)**:
  - Thay tên mẫu xem thử `"NGUYỄN VĂN HỘI VIÊN"` trong bộ dựng mẫu bằng placeholder trung tính **`"HỌ VÀ TÊN"`**, tuyệt đối không để lọt vào thẻ xuất thật.
  - Tinh gọn màn hình **Tạo thẻ**: chỉ giữ Logo + Tên thương hiệu `89 FITNESS & YOGA`, tiêu đề ngắn **`"CHỌN LOẠI THẺ"`**, 3 nút chọn loại thẻ (`GYM THÁNG`, `GYM PT`, `YOGA THÁNG`) và **xóa hoàn toàn nút cài đặt trùng lặp** ở cuối màn hình Tạo thẻ.
  - Tinh gọn tiêu đề màn hình **Cài đặt** thành **`"CÀI ĐẶT"`** (bỏ chữ `V4.0` và câu mô tả dài) và tiêu đề màn hình quản lý phôi thành **`"QUẢN LÝ PHÔI THẺ"`** với mô tả nhóm ngắn gọn (`Mặc định`, `Gym`, `Yoga`, `PT`).
  - Loại bỏ mọi chiều cao cố định (`.height(...)`) trên các nút, chip và thẻ danh mục để chống cắt chữ khi bật Font Scaling `1.0x – 1.3x` trên MIUI 13.0.7 (`1080 × 2400 px`, tỷ lệ `20:9`).

---

## 1. Overview & Core Concept

- **What It Does**: Ứng dụng chuyên dụng giúp thu ngân tại quầy **89 FITNESS & YOGA** tạo, căn chỉnh ảnh chân dung, xem trước trực tiếp và xuất thẻ hội viên kỹ thuật số chất lượng cao (`PNG` / `PDF` chuẩn tỷ lệ `8:5`) cho 3 hạng mục: **Gym tháng**, **Gym PT** và **Yoga tháng**.
- **Target Audience / Persona**: Nhân viên thu ngân thao tác nhanh tại quầy trên điện thoại Android thực tế (đặc biệt tối ưu cho màn hình tỷ lệ `20:9`, Android 12 / MIUI 13.0.7) và hội viên nhận thẻ qua Zalo/Messenger/in ấn.
- **Key Value**: Mỗi chiếc thẻ xuất ra mang đẳng cấp của một thẻ thành viên thương hiệu thể thao – wellness thực thụ với nền nghệ thuật có chiều sâu, ảnh chân dung lớn sắc nét, tên hội viên và thông tin gói tập/giá tiền nổi bật rõ ràng ngay từ cái nhìn đầu tiên.

---

## 2. User Experience & Visual Design

### 2.1. Định hướng Art Direction chi tiết cho 12 Phôi Thẻ (4 Nhóm × 3 Phôi)

| Nhóm | Mã & Tên phôi | Bảng màu chủ đạo (Color Palette) | Art Direction, Background Artwork & Bố cục thông tin |
| :--- | :--- | :--- | :--- |
| **A. Mặc định (Universal)** | **A1 – Universal Premium** | Royal Navy (`#101B2E`), Midnight Sapphire (`#1D2E4A`), Champagne Gold (`#E5C158`), Kem sáng (`#FDFBF7`) | Nền lụa xanh sapphire đa lớp kết hợp vầng sáng vàng champagne, viền kim loại kép tinh tế; ảnh chân dung bo góc lớn bên trái; cụm thông tin bên phải đặt trên nền kính tương phản cao kèm huy hiệu Giá tiền vàng kim. |
| **A. Mặc định (Universal)** | **A2 – Universal Modern Minimal** | Alabaster Cream (`#FAF8F5`), Warm Sand (`#EFECE6`), Deep Slate (`#0F172A`), Cobalt Blue (`#1D4ED8`), Coral Red (`#DC2626`) | **Tông sáng hiện đại**: nền trắng ngà ấm áp, lưới kiến trúc Thụy Sĩ thanh mảnh, điểm nhấn hình học xanh cobalt; ảnh chân dung bên phải; tên hội viên chữ đậm sắc nét trên nền sáng, Thời hạn và Giá tiền đóng khung pill nổi bật. |
| **A. Mặc định (Universal)** | **A3 – Universal Futuristic** | Deep Indigo (`#0E172A`), Electric Blue (`#1E3A8A`), Cyan Glow (`#06B6D4`), Ice White (`#F8FAFC`) | Đa diện hình học chiều sâu xanh lam điện tử và ánh sáng quang học tinh tế (không dùng nền đen đặc); khung ảnh bát giác vát cạnh bên trái; các ô thông tin viền kỹ thuật sắc sảo. |
| **B. Gym Monthly** | **G1 – Athletic Performance** | Carbon Charcoal (`#141821`), Crimson Sport (`#E11D48`), Pure White (`#FFFFFF`), Volt Gold (`#FACC15`) | Nền nghệ thuật thể thao năng động với dải chuyển động chéo đỏ – trắng – than chì mạnh mẽ; khung ảnh vát góc tốc độ bên trái; băng rôn tên hội viên cỡ lớn và huy hiệu Thời hạn / Giá tiền tương phản rực rỡ. |
| **B. Gym Monthly** | **G2 – Luxury Black & Gold** | Obsidian (`#121110`), Brushed Bronze (`#29241E`), Metallic Gold (`#D4AF37`), Warm Ivory (`#FCF9F2`) | Chất liệu kim loại xước ánh đồng và họa tiết vòm hoàng gia; khung ảnh vòm nghệ thuật bên phải; các trường dữ liệu đặt trong khung viền vàng champagne với điểm nhấn ngày hết hạn và giá tiền sang trọng. |
| **B. Gym Monthly** | **G3 – Bold Sport Editorial** | Crisp Daylight (`#F4F4F6`), Stark Black (`#111827`), Energetic Orange (`#EA580C`), Slate Gray (`#4B5563`) | **Phong cách tạp chí thể thao nền sáng tương phản**: cột dọc cam thể thao bên trái, mảng khối bất đối xứng trắng – đen; khung ảnh vát chéo bên phải; typography đậm cá tính, bảng thông tin tách lớp rõ như bìa tạp chí fitness. |
| **C. Yoga Monthly** | **Y1 – Zen Minimal** | Warm Ivory (`#FBF9F4`), Soft Oat (`#F2ECE1`), Sage Green (`#3D6B52`), Deep Forest (`#1B3B2B`) | **Tông sáng thư giãn**: nền kem lụa kết hợp vòng tròn thiền Enso và đường lượn sóng cát mềm mại; khung ảnh vòm bên trái; hộp thông tin nền trắng ngà viền xanh sage thanh thoát. |
| **C. Yoga Monthly** | **Y2 – Botanical Elegance** | Soft Botanical Cream (`#F3F8F4`), Mist Sage (`#DCECE0`), Emerald Leaf (`#1E5E3A`), Terracotta Gold (`#B45309`) | **Tông sáng thảo mộc tự nhiên**: họa tiết lá thực vật hữu cơ và đường cong mềm mại trên nền kem xanh dịu; khung ảnh viên nang Oval bên phải; các thẻ thông tin bo tròn thanh lịch. |
| **C. Yoga Monthly** | **Y3 – Luxury Wellness** | Soft Lavender Ivory (`#FAF6FC`), Champagne Rose (`#F3E8F8`), Royal Plum (`#4A2559`), Warm Gold (`#B7791F`) | **Tông sáng Lavender – Champagne cao cấp**: họa tiết cánh sen wellness đa lớp mềm mại; khung ảnh tròn huy chương bên trái có hào quang vàng hồng; tên hội viên và thông tin màu tím trầm sắc nét. |
| **D. Gym PT** | **P1 – Elite Personal Trainer** | Deep Gunmetal (`#131720`),Rich Amber (`#F59E0B`), Pure White (`#FFFFFF`), Warm Platinum (`#E2E8F0`) | Phong cách huấn luyện viên cá nhân cao cấp với dải chevron năng lượng vàng hổ phách; khung ảnh vát góc bên trái; **Huy hiệu Số buổi PT cỡ lớn** đặt tại vị trí trung tâm thu hút ánh nhìn ngay lập tức. |
| **D. Gym PT** | **P2 – Performance Lab** | Ice Technical Silver (`#F1F5F9`), Deep Navy (`#0F172A`), Cyan Telemetry (`#0284C7`), Emerald Metric (`#059669`) | **Tông sáng kỹ thuật phòng Lab hiệu suất**: nền bạc sáng kết hợp lưới tọa độ sinh trắc học mảnh và thước đo hiệu suất; khung ảnh bên phải; bảng thông số PT và giá tiền hiển thị chuẩn xác như bảng phân tích thể lực. |
| **D. Gym PT** | **P3 – Black Titanium** | Brushed Titanium (`#181B20`), Metallic Silver (`#94A3B8`), Crimson Red (`#DC2626`), Champagne (`#FDE68A`) | Bề mặt kim loại titan xước có chiều sâu ánh bạc kết hợp thanh trụ đỏ thể thao bên trái; khung ảnh bát giác kim loại; cụm thông tin PT và giá tiền đóng khung sắc nét, quyền lực. |

### 2.2. Thứ tự ưu tiên thị giác & Hệ thống Icon Vector đồng bộ

- **Thứ tự ưu tiên thị giác trên mọi phôi**:
  1. **Tên hội viên**: Cỡ chữ lớn nhất trên thẻ (`38–44px` trên hệ quy chiếu `1200×750`), in hoa, độ tương phản tuyệt đối, tự động co cỡ chữ mượt mà khi tên dài và giữ nguyên đầy đủ dấu tiếng Việt.
  2. **Ảnh hội viên**: Chiếm diện tích nổi bật (`26%–28%` chiều rộng thẻ), viền khung có lớp phát sáng/đổ bóng nhẹ tách biệt khỏi nền.
  3. **Thời hạn gói / Số buổi PT**: Đặt trong **Badge/Panel điểm nhấn** với màu sắc nổi bật.
  4. **Ngày hết hạn & Giá tiền**: Nhấn màu sắc riêng dễ quét mắt ngay lập tức.
  5. **Số điện thoại, Giới tính/Nhóm & Ngày bắt đầu**: Bố trí trong các ô thông tin có nền bán trong suốt hoặc viền tách biệt rõ ràng.
  6. **Logo & Thương hiệu**: Gọn gàng trên thanh Header cùng nhãn loại thẻ tiếng Việt duy nhất (`Thẻ Gym`, `Thẻ Yoga`, `Thẻ PT`).
- **Hệ thống 9 Icon Vector chuyên nghiệp**:
  - Vẽ bằng đường nét hình học vector đồng nhất độ dày nét (`strokeWidth`) và bo góc (`StrokeCap.ROUND`, `StrokeJoin.ROUND`) cho: *Hội viên (`USER`), Giới tính/Nhóm (`GROUP`), Điện thoại (`PHONE`), Ngày bắt đầu (`CALENDAR`), Ngày hết hạn (`CALENDAR_CHECK`), Thời hạn (`CLOCK`), Số buổi PT (`DUMBBELL`), Giá tiền (`WALLET`), Loại thẻ (`MEMBERSHIP_CARD`)*.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Kết hợp Background Artwork tỷ lệ 8:5 với Bộ dựng Vector/Canvas động**
  - *Chosen Approach*: Tạo các tài nguyên ảnh nền nghệ thuật tỷ lệ `8:5` (không chữ, không logo giả) bằng công cụ tạo ảnh cho các chủ đề cốt lõi, kết hợp vẽ đa lớp (gradient ánh sáng, họa tiết hình học, khung panel thông tin, icon vector, ảnh hội viên gốc và typography) trực tiếp bằng `Canvas` ở đúng độ phân giải đích (`1200×750`, `1800×1125`, `2400×1500`).
  - *Why*: Đảm bảo nền thẻ có chiều sâu mỹ thuật cao cấp của một thẻ thành viên thực thụ trong khi chữ, số liệu, khung ảnh và icon luôn đạt độ sắc nét vector tuyệt đối ở mọi mức xuất `1×`, `1.5×`, `2×` mà không bao giờ có chữ AI giả hay vỡ hạt.
- **Decision 2: Loại bỏ triệt để chiều cao cố định (Fixed Height) và các tiêu đề thừa trên giao diện Compose**
  - *Chosen Approach*: Chuyển toàn bộ các nút, chip, thẻ danh mục và thanh điều khiển sang `heightIn(min = 48.dp)` + `wrapContentHeight()`, xóa nút Cài đặt trùng trên trang Tạo thẻ, rút gọn tiêu đề trang Tạo thẻ (`CHỌN LOẠI THẺ`), trang Cài đặt (`CÀI ĐẶT`) và trang Quản lý phôi (`QUẢN LÝ PHÔI THẺ`).
  - *Why*: Khắc phục hoàn toàn hiện tượng cắt chữ, chồng lấn hoặc khoảng trắng bất thường trên màn hình tỷ lệ `20:9` (`Redmi Note 11 Pro+`, MIUI 13.0.7) ngay cả khi người dùng tăng cỡ chữ hệ thống lên `1.15x` hoặc `1.3x`.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### 4.1. Sơ đồ Kiến trúc Hệ thống Render & Quản lý Phôi V4.0

```
┌────────────────────────────────────────────────────────────────────────────┐
│                   GIAO DIỆN JETPACK COMPOSE (RESPONSIVE)                   │
│  ┌───────────────────────────────────┐  ┌────────────────────────────────┐ │
│  │       MÀN HÌNH TẠO THẺ            │  │       MÀN HÌNH CÀI ĐẶT         │ │
│  │ • Header gọn: Logo + Thương hiệu  │  │ • Tiêu đề gọn: "CÀI ĐẶT"       │ │
│  │ • "CHỌN LOẠI THẺ" (Không nút phụ) │  │ • "QUẢN LÝ PHÔI THẺ" (4 Tab:   │ │
│  │ • Bước 1: Danh sách 1 cột 6 phôi  │  │   Mặc định | Gym | Yoga | PT)  │ │
│  │   tương thích (Thumbnail 8:5 lớn) │  │ • Cài đặt Gói tập & Thương hiệu│ │
│  │ • Bước 2–4: Nhập liệu, Crop, Xuất │  │ • Chọn phân giải 1×, 1.5×, 2×  │ │
│  └─────────────────┬─────────────────┘  └────────────────┬───────────────┘ │
└────────────────────┼─────────────────────────────────────┼─────────────────┘
                     ▼                                     ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                  VIEWMODEL & REPOSITORY (STATE & STORAGE)                  │
│  • Bảo toàn 100% dữ liệu hội viên & ảnh gốc khi chuyển đổi giữa các phôi   │
│  • Quản lý trạng thái Bật/Tắt & Mặc định độc lập cho Gym, Yoga, PT         │
│  • Lưu ảnh gốc (MediaStore) + Xuất PNG / PDF theo đúng tỷ lệ 8:5           │
└────────────────────────────────────┬───────────────────────────────────────┘
                                     ▼
┌────────────────────────────────────────────────────────────────────────────┐
│              METADATA-DRIVEN RENDER ENGINE (1 RENDERER CHUNG)              │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌───────────────────┐ │
│  │ 1. LỚP NỀN & ARTWORK │  │ 2. PANEL & KHUNG ẢNH │  │ 3. ICON & DỮ LIỆU │ │
│  │ • Artwork nền 8:5 +  │─▶│ • Khung ảnh gốc sắc  │─▶│ • 9 Icon Vector   │ │
│  │   Đồ họa Vector đa   │  │   nét + Viền nổi bật │  │ • Badge Thời hạn  │ │
│  │   lớp giàu chiều sâu │  │ • Panel thông tin có │  │   / Số buổi & Giá │ │
│  │ • 6 Sáng / 6 Đậm     │  │   độ tương phản cao  │  │ • Placeholder mẫu │ │
│  └──────────────────────┘  └──────────────────────┘  │   "HỌ VÀ TÊN"     │ │
│                                                      └───────────────────┘ │
└────────────────────────────────────────────────────────────────────────────┘
```

### 4.2. Mô hình Metadata & Quy tắc Bảo toàn Dữ liệu

- **Metadata mỗi phôi (`TemplateMetadata`)**: Lưu trữ đầy đủ `templateId`, `templateName`, `category`, `styleName`, `templateVersion`, `canvasWidth` (`1200`), `canvasHeight` (`750`), `aspectRatio` (`1.6f`), `backgroundAsset`, `artworkAssets`, `photoFrame`, `logoPosition`, `textFieldPositions`, `iconPositions`, `typography`, `colorPalette` (bao gồm cả màu nền Panel thông tin và màu Badge điểm nhấn), `alignment`, `spacing`, `overflowRules`, `isEnabled` và `previewThumbnail`.
- **Phân tách dữ liệu mẫu (`buildSamplePayload`) và dữ liệu xuất thật (`buildRenderPayloadFromDraft`)**:
  - Khi xem thử phôi trong danh sách hoặc hộp thoại Xem thử, `buildSamplePayload` hiển thị tên placeholder trung tính **`"HỌ VÀ TÊN"`** và hình bóng minh họa trong khung ảnh.
  - Khi xuất PNG/PDF hoặc chia sẻ ở Bước 4, hệ thống kiểm tra nghiêm ngặt dữ liệu hội viên và ảnh chụp/chọn thực tế từ `CardDraft`, tuyệt đối không bao giờ dùng dữ liệu mẫu hay ảnh thumbnail để xuất.
- **Tương thích thiết bị thật & Giới hạn môi trường kiểm thử**:
  - Giao diện sử dụng hoàn toàn đơn vị `dp`/`sp`, `WindowInsets.safeDrawing` tại một cấp `Scaffold` duy nhất (không cộng trùng Insets hai lần), và các thành phần co giãn tự nhiên theo `fontScale` (`1.0x`, `1.15x`, `1.3x`).
  - Do môi trường đám mây không kết nối vật lý trực tiếp với điện thoại `Redmi Note 11 Pro+`, quá trình kiểm thử sẽ bao gồm: kiểm thử đơn vị tự động (`JUnit`), kiểm tra bố cục đa kích thước/tỷ lệ `20:9` và biên dịch APK hoàn chỉnh sẵn sàng cài đặt trên thiết bị thật.
