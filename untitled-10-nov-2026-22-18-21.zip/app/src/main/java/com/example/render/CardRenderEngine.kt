package com.example.render

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.util.LruCache
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.domain.model.ArtworkPatternStyle
import com.example.domain.model.CardIconType
import com.example.domain.model.CardType
import com.example.domain.model.HeaderLayoutStyle
import com.example.domain.model.InfoBoxStyle
import com.example.domain.model.PhotoFrameShape
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateMetadata
import com.example.domain.util.FormattersAndValidators
import java.io.File
import kotlin.math.max
import kotlin.math.min

data class CardRenderPayload(
    val cardType: CardType,
    val templateId: String,
    val fullName: String,
    val phoneNumber: String,
    val targetGroup: TargetGroup?, // Only for GYM_MONTHLY
    val packageName: String = "",
    val durationMonths: Int?, // For GYM_MONTHLY & YOGA_MONTHLY
    val startDateFormatted: String?, // For GYM_MONTHLY & YOGA_MONTHLY
    val endDateFormatted: String?, // For GYM_MONTHLY & YOGA_MONTHLY
    val totalPtSessions: Int?, // Only for GYM_PT
    val priceVnd: Long,
    val photoPath: String?,
    val cropScale: Float = 1f,
    val cropOffsetX: Float = 0f,
    val cropOffsetY: Float = 0f,
    val brandName: String = "89 FITNESS & YOGA",
    val brandContact: String = "Hội viên chính thức • 89 FITNESS & YOGA",
    val brandLogoPath: String? = null
)

object CardRenderEngine {

    // Cache 8:5 sample thumbnails (720x450) for smooth scrolling in 1-column template lists
    private val thumbnailCache = object : LruCache<String, Bitmap>(28) {}

    fun getOrRenderSampleThumbnail(
        context: Context,
        template: TemplateMetadata,
        brandName: String = "89 FITNESS & YOGA",
        previewCardType: CardType = template.category.primaryPreviewCardType()
    ): Bitmap {
        val cacheKey = "${template.templateId}_v${template.templateVersion}_${previewCardType.code}_$brandName"
        thumbnailCache.get(cacheKey)?.let { if (!it.isRecycled) return it }

        val samplePayload = buildSamplePayload(template, brandName, previewCardType)
        val bmp = renderCardBitmap(
            context = context,
            payload = samplePayload,
            template = template,
            targetWidth = 760,
            targetHeight = 475
        )
        thumbnailCache.put(cacheKey, bmp)
        return bmp
    }

    fun buildSamplePayload(
        template: TemplateMetadata,
        brandName: String = "89 FITNESS & YOGA",
        previewCardType: CardType = template.category.primaryPreviewCardType()
    ): CardRenderPayload = CardRenderPayload(
        cardType = previewCardType,
        templateId = template.templateId,
        fullName = "NGUYỄN VĂN HỘI VIÊN",
        phoneNumber = "0989 898 989",
        targetGroup = if (previewCardType == CardType.GYM_MONTHLY) TargetGroup.NAM else null,
        packageName = when (previewCardType) {
            CardType.GYM_MONTHLY -> "3 tháng"
            CardType.YOGA_MONTHLY -> "2 tháng"
            CardType.GYM_PT -> "Gói 24 buổi PT"
        },
        durationMonths = when (previewCardType) {
            CardType.GYM_MONTHLY -> 3
            CardType.YOGA_MONTHLY -> 2
            CardType.GYM_PT -> null
        },
        startDateFormatted = if (previewCardType != CardType.GYM_PT) "01/11/2026" else null,
        endDateFormatted = if (previewCardType != CardType.GYM_PT) "01/02/2027" else null,
        totalPtSessions = if (previewCardType == CardType.GYM_PT) 24 else null,
        priceVnd = when (previewCardType) {
            CardType.GYM_MONTHLY -> 800_000L
            CardType.GYM_PT -> 6_000_000L
            CardType.YOGA_MONTHLY -> 1_000_000L
        },
        photoPath = null,
        brandName = brandName
    )

    fun renderCardBitmap(
        context: Context,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        targetWidth: Int = template.canvasWidth,
        targetHeight: Int = template.canvasHeight
    ): Bitmap {
        val width = targetWidth.coerceAtLeast(480)
        val height = targetHeight.coerceAtLeast(300)
        val scale = width.toFloat() / 1200f

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val montserratBase = try {
            ResourcesCompat.getFont(context, R.font.montserrat) ?: Typeface.SANS_SERIF
        } catch (_: Exception) {
            Typeface.SANS_SERIF
        }
        val montserratBold = Typeface.create(montserratBase, Typeface.BOLD)

        val beVietnamBase = try {
            ResourcesCompat.getFont(context, R.font.be_vietnam_pro) ?: Typeface.SANS_SERIF
        } catch (_: Exception) {
            Typeface.SANS_SERIF
        }
        val beVietnamMedium = Typeface.create(beVietnamBase, Typeface.NORMAL)
        val beVietnamBold = Typeface.create(beVietnamBase, Typeface.BOLD)

        // 1. Render Distinct Procedural Template Artwork & Background (12 V4.0 Styles)
        drawTemplateArtwork(canvas, width.toFloat(), height.toFloat(), scale, template)

        // 2. Render Clean Header (Brand Logo + Brand Name + Single Vietnamese Card Type Label with Vector Icon)
        // Strictly NO top-right English pill badge ("GYM MONTHLY", etc.) per Part 5!
        drawHeaderByStyle(
            context = context,
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scale,
            payload = payload,
            template = template,
            titleTypeface = montserratBold,
            subtitleTypeface = beVietnamBold
        )

        // 3. Render Fixed Photo Frame According to PhotoFrameShape & Coordinates (High-Res Original Photo)
        drawPhotoSlotByShape(
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scale,
            payload = payload,
            template = template,
            labelTypeface = beVietnamMedium
        )

        // 4. Render Dynamic Card Content Fields with Unified Vector Icons
        drawFieldsByStyle(
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scale,
            payload = payload,
            template = template,
            headingTypeface = montserratBold,
            labelTypeface = beVietnamMedium,
            valueTypeface = beVietnamBold
        )

        // 5. Render Footer Bar
        drawFooterBar(
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scale,
            payload = payload,
            template = template,
            footerTypeface = beVietnamMedium
        )

        return bitmap
    }

    private fun drawTemplateArtwork(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        template: TemplateMetadata
    ) {
        val bgPrimary = parseHexColorSafe(template.backgroundColorHex, Color.parseColor("#0F141C"))
        val bgSecondary = parseHexColorSafe(template.secondaryColorHex, Color.parseColor("#1E2633"))
        val accent = parseHexColorSafe(template.accentColorHex, Color.parseColor("#D4AF37"))

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, width, height,
                intArrayOf(bgPrimary, bgSecondary, bgPrimary),
                floatArrayOf(0f, 0.56f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val artPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent
            style = Paint.Style.FILL
        }

        when (template.artworkPattern) {
            ArtworkPatternStyle.A1_UNIVERSAL_PREMIUM -> {
                // Soft radial champagne glow + fine luxury double frame + subtle wave arc
                val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(
                        width * 0.85f, height * 0.18f, 420f * scale,
                        Color.argb(46, Color.red(accent), Color.green(accent), Color.blue(accent)),
                        Color.TRANSPARENT,
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(0f, 0f, width, height, glowPaint)

                val frameStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2.2f * scale
                    alpha = 135
                }
                val m = 22f * scale
                canvas.drawRoundRect(RectF(m, m, width - m, height - m), 20f * scale, 20f * scale, frameStroke)

                val arcStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 1.6f * scale
                    alpha = 55
                }
                for (i in 0..2) {
                    val offset = i * 24f * scale
                    val path = Path().apply {
                        moveTo(width * 0.55f, height + offset)
                        cubicTo(
                            width * 0.72f, height * 0.68f + offset,
                            width * 0.88f, height * 0.82f + offset,
                            width + 20f, height * 0.50f + offset
                        )
                    }
                    canvas.drawPath(path, arcStroke)
                }
            }

            ArtworkPatternStyle.A2_UNIVERSAL_MINIMAL -> {
                // Clean Swiss architectural grid & top accent bar on high-key alabaster
                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, width, 8f * scale, artPaint)

                val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#CBD5E1")
                    strokeWidth = 1.4f * scale
                    alpha = 150
                }
                canvas.drawLine(width * 0.655f, 132f * scale, width * 0.655f, height - 64f * scale, gridPaint)

                // Subtle geometric circle accent in top-right safe area
                artPaint.alpha = 18
                canvas.drawCircle(width * 0.90f, 70f * scale, 95f * scale, artPaint)
            }

            ArtworkPatternStyle.A3_UNIVERSAL_FUTURISTIC -> {
                // Controlled tech HUD lines, corner brackets & subtle geometric polygon
                val hudStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2f * scale
                    alpha = 90
                }
                val pad = 24f * scale
                val corner = 24f * scale
                val hudPath = Path().apply {
                    moveTo(pad + corner, pad)
                    lineTo(width - pad - corner, pad)
                    lineTo(width - pad, pad + corner)
                    lineTo(width - pad, height - pad - corner)
                    lineTo(width - pad - corner, height - pad)
                    lineTo(pad + corner, height - pad)
                    lineTo(pad, height - pad - corner)
                    lineTo(pad, pad + corner)
                    close()
                }
                canvas.drawPath(hudPath, hudStroke)

                // Subtle circuit traces in top right
                hudStroke.alpha = 55
                canvas.drawLine(width * 0.72f, 52f * scale, width * 0.92f, 52f * scale, hudStroke)
                canvas.drawLine(width * 0.78f, 76f * scale, width * 0.92f, 76f * scale, hudStroke)
                artPaint.alpha = 120
                canvas.drawCircle(width * 0.72f, 52f * scale, 4.5f * scale, artPaint)
                canvas.drawCircle(width * 0.78f, 76f * scale, 4.5f * scale, artPaint)
            }

            ArtworkPatternStyle.G1_ATHLETIC_PERFORMANCE -> {
                // High-energy athletic diagonal slashes + top crimson bar
                artPaint.alpha = 40
                val slash1 = Path().apply {
                    moveTo(width * 0.72f, 0f)
                    lineTo(width * 0.85f, 0f)
                    lineTo(width * 0.62f, height)
                    lineTo(width * 0.49f, height)
                    close()
                }
                canvas.drawPath(slash1, artPaint)
                artPaint.alpha = 20
                val slash2 = Path().apply {
                    moveTo(width * 0.88f, 0f)
                    lineTo(width * 0.96f, 0f)
                    lineTo(width * 0.73f, height)
                    lineTo(width * 0.65f, height)
                    close()
                }
                canvas.drawPath(slash2, artPaint)
                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, width, 10f * scale, artPaint)
            }

            ArtworkPatternStyle.G2_LUXURY_BLACK_GOLD -> {
                // Double gold filigree border + soft golden halo behind right arch frame
                val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2.8f * scale
                    alpha = 185
                }
                val m1 = 20f * scale
                val m2 = 30f * scale
                canvas.drawRoundRect(RectF(m1, m1, width - m1, height - m1), 18f * scale, 18f * scale, strokePaint)
                strokePaint.strokeWidth = 1.2f * scale
                strokePaint.alpha = 105
                canvas.drawRoundRect(RectF(m2, m2, width - m2, height - m2), 12f * scale, 12f * scale, strokePaint)

                artPaint.alpha = 28
                canvas.drawCircle(width * 0.81f, height * 0.52f, 220f * scale, artPaint)
            }

            ArtworkPatternStyle.G3_BOLD_SPORT_EDITORIAL -> {
                // Left vertical editorial accent pillar + diagonal geometric wedge
                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, 52f * scale, height, artPaint)
                artPaint.alpha = 32
                val wedge = Path().apply {
                    moveTo(width * 0.56f, 0f)
                    lineTo(width, 0f)
                    lineTo(width, height * 0.42f)
                    close()
                }
                canvas.drawPath(wedge, artPaint)
            }

            ArtworkPatternStyle.Y1_ZEN_MINIMAL -> {
                // Serene Enso Zen circle + warm minimal horizon line
                val ensoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 18f * scale
                    strokeCap = Paint.Cap.ROUND
                    alpha = 26
                }
                val r = 230f * scale
                val cx = width * 0.82f
                val cy = height * 0.50f
                canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 25f, 305f, false, ensoPaint)
            }

            ArtworkPatternStyle.Y2_BOTANICAL_ELEGANCE -> {
                // Organic botanical leaf curves in deep forest & mint
                artPaint.alpha = 28
                val leaf1 = Path().apply {
                    moveTo(width, height)
                    quadTo(width * 0.70f, height * 0.86f, width * 0.78f, height * 0.42f)
                    quadTo(width * 0.95f, height * 0.65f, width, height)
                    close()
                }
                canvas.drawPath(leaf1, artPaint)

                val stemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2f * scale
                    alpha = 70
                }
                val curve = Path().apply {
                    moveTo(0f, height * 0.88f)
                    cubicTo(width * 0.30f, height * 0.78f, width * 0.65f, height * 0.96f, width, height * 0.82f)
                }
                canvas.drawPath(curve, stemPaint)
            }

            ArtworkPatternStyle.Y3_LUXURY_WELLNESS -> {
                // Flowing silk wellness waves + soft rose champagne halo around circular frame
                val silkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2.2f * scale
                    alpha = 68
                }
                for (i in 0..3) {
                    val dy = i * 18f * scale
                    val wave = Path().apply {
                        moveTo(0f, height * 0.76f + dy)
                        cubicTo(
                            width * 0.32f, height * 0.62f + dy,
                            width * 0.68f, height * 0.90f + dy,
                            width, height * 0.70f + dy
                        )
                    }
                    canvas.drawPath(wave, silkPaint)
                }
                artPaint.alpha = 24
                canvas.drawCircle(width * 0.188f, height * 0.49f, 200f * scale, artPaint)
            }

            ArtworkPatternStyle.P1_ELITE_PERSONAL_TRAINER -> {
                // Strong PT chevron badge accent + top & bottom gold power rules
                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, width, 8f * scale, artPaint)
                canvas.drawRect(0f, height - 8f * scale, width, height, artPaint)

                val chevPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 10f * scale
                    alpha = 32
                }
                for (i in 0..2) {
                    val ox = width * 0.76f + i * 44f * scale
                    val path = Path().apply {
                        moveTo(ox, height * 0.18f)
                        lineTo(ox + 48f * scale, height * 0.50f)
                        lineTo(ox, height * 0.82f)
                    }
                    canvas.drawPath(path, chevPaint)
                }
            }

            ArtworkPatternStyle.P2_PERFORMANCE_LAB -> {
                // Precision biometric coordinate grid + corner calibration ticks
                val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    alpha = 22
                    strokeWidth = 1.2f * scale
                }
                val step = 60f * scale
                var x = step
                while (x < width) {
                    canvas.drawLine(x, 0f, x, height, gridPaint)
                    x += step
                }
                var y = step
                while (y < height) {
                    canvas.drawLine(0f, y, width, y, gridPaint)
                    y += step
                }
                val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    alpha = 180
                    strokeWidth = 4f * scale
                    style = Paint.Style.STROKE
                }
                val m = 24f * scale
                val len = 36f * scale
                canvas.drawLine(m, m, m + len, m, cornerPaint)
                canvas.drawLine(m, m, m, m + len, cornerPaint)
                canvas.drawLine(width - m, m, width - m - len, m, cornerPaint)
                canvas.drawLine(width - m, m, width - m, m + len, cornerPaint)
                canvas.drawLine(m, height - m, m + len, height - m, cornerPaint)
                canvas.drawLine(m, height - m, m, height - m - len, cornerPaint)
                canvas.drawLine(width - m, height - m, width - m - len, height - m, cornerPaint)
                canvas.drawLine(width - m, height - m, width - m, height - m - len, cornerPaint)
            }

            ArtworkPatternStyle.P3_BLACK_TITANIUM -> {
                // Brushed black titanium texture + left metallic silver-red pillar + chamfered border
                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, 34f * scale, height, artPaint)

                val brushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    alpha = 12
                    strokeWidth = 1f * scale
                }
                var by = 16f * scale
                while (by < height) {
                    canvas.drawLine(34f * scale, by, width, by, brushPaint)
                    by += 12f * scale
                }

                val metalBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#94A3B8")
                    style = Paint.Style.STROKE
                    strokeWidth = 2f * scale
                    alpha = 110
                }
                val m = 22f * scale
                canvas.drawRect(RectF(34f * scale + m, m, width - m, height - m), metalBorder)
            }
        }
    }

    private fun drawHeaderByStyle(
        context: Context,
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        titleTypeface: Typeface,
        subtitleTypeface: Typeface
    ) {
        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))
        val primaryTextColor = parseHexColorSafe(template.textPrimaryHex, Color.WHITE)
        val secondaryTextColor = parseHexColorSafe(template.textSecondaryHex, Color.LTGRAY)

        val customLogo = payload.brandLogoPath
            ?.takeIf { File(it).exists() }
            ?.let { decodeSampledBitmap(it, 256, 256) }
        val logoBitmap = customLogo
            ?: BitmapFactory.decodeResource(context.resources, R.drawable.img_app_logo_fg_1794306459132)

        val leftStart = when {
            template.artworkPattern == ArtworkPatternStyle.G3_BOLD_SPORT_EDITORIAL -> 96f * scale
            template.artworkPattern == ArtworkPatternStyle.P3_BLACK_TITANIUM -> 78f * scale
            else -> 64f * scale
        }

        val logoSize = 76f * scale
        val logoTop = 36f * scale
        val logoRect = RectF(leftStart, logoTop, leftStart + logoSize, logoTop + logoSize)
        drawLogoBox(canvas, logoBitmap, logoRect, accentColor, scale)
        if (customLogo != null && !customLogo.isRecycled) {
            customLogo.recycle()
        }

        val brandX = logoRect.right + 20f * scale
        val brandPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = titleTypeface
            color = primaryTextColor
            textSize = 32f * scale
            letterSpacing = 0.04f
        }
        val fittedBrand = fitAndEllipsizeText(
            text = payload.brandName.ifBlank { "89 FITNESS & YOGA" }.uppercase(),
            paint = brandPaint,
            maxWidth = width - brandX - 56f * scale,
            minTextSize = 20f * scale
        )
        canvas.drawText(fittedBrand, brandX, logoTop + 38f * scale, brandPaint)

        // Single concise Vietnamese card type label + vector icon right below brand name (User Decision 2 & Part 5)
        val iconSize = 22f * scale
        val subBaselineY = logoTop + 69f * scale
        val iconCenterY = subBaselineY - 7f * scale
        drawVectorIcon(
            canvas = canvas,
            iconType = CardIconType.MEMBERSHIP_CARD,
            cx = brandX + iconSize / 2f,
            cy = iconCenterY,
            size = iconSize,
            color = accentColor,
            scale = scale
        )

        val cardTypePaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = subtitleTypeface
            color = accentColor
            textSize = 19.5f * scale
            letterSpacing = 0.03f
        }
        val cardTypeLabel = payload.cardType.shortCardLabelVi.uppercase()
        val typeX = brandX + iconSize + 10f * scale
        canvas.drawText(cardTypeLabel, typeX, subBaselineY, cardTypePaint)

        val dotAndStylePaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = subtitleTypeface
            color = secondaryTextColor
            textSize = 16.5f * scale
            letterSpacing = 0.02f
        }
        val styleStartX = typeX + cardTypePaint.measureText(cardTypeLabel) + 14f * scale
        val maxStyleWidth = (width - styleStartX - 56f * scale).coerceAtLeast(80f)
        val fittedStyle = fitAndEllipsizeText(
            text = "•  ${template.templateName}",
            paint = dotAndStylePaint,
            maxWidth = maxStyleWidth,
            minTextSize = 13f * scale
        )
        canvas.drawText(fittedStyle, styleStartX, subBaselineY, dotAndStylePaint)

        // Subtle header divider line
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (template.headerStyle == HeaderLayoutStyle.CENTERED_CREST) accentColor else primaryTextColor
            alpha = if (template.headerStyle == HeaderLayoutStyle.CENTERED_CREST) 95 else 34
            strokeWidth = 1.6f * scale
        }
        canvas.drawLine(leftStart, 132f * scale, width - 56f * scale, 132f * scale, dividerPaint)
    }

    private fun drawLogoBox(
        canvas: Canvas,
        logoBitmap: Bitmap?,
        logoRect: RectF,
        accentColor: Int,
        scale: Float
    ) {
        val clip = Path().apply {
            addRoundRect(logoRect, 16f * scale, 16f * scale, Path.Direction.CW)
        }
        canvas.save()
        canvas.clipPath(clip)
        if (logoBitmap != null) {
            drawTransformedPhotoInRect(canvas, logoBitmap, logoRect, 1f, 0f, 0f)
        } else {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
            canvas.drawRect(logoRect, p)
        }
        canvas.restore()

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.STROKE
            strokeWidth = 2.4f * scale
        }
        canvas.drawRoundRect(logoRect, 16f * scale, 16f * scale, borderPaint)
    }

    private fun drawPhotoSlotByShape(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        labelTypeface: Typeface
    ) {
        val slot = template.imageSlot
        val slotLeft = width * slot.xRatio
        val slotTop = height * slot.yRatio
        val slotW = width * slot.widthRatio
        val slotH = height * slot.heightRatio
        val slotRect = RectF(slotLeft, slotTop, slotLeft + slotW, slotTop + slotH)

        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))
        val shapePath = createFrameShapePath(slotRect, slot.shape, width * slot.cornerRadiusRatio)

        // Slot backing fill
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1E293B")
            style = Paint.Style.FILL
        }
        canvas.drawPath(shapePath, bgPaint)

        // Decode original member photo at resolution matching output canvas (1x, 1.5x, 2x)
        val reqDecodeSide = (max(width, height) * 0.9f).toInt().coerceIn(900, 2200)
        val photoBitmap = payload.photoPath
            ?.takeIf { File(it).exists() }
            ?.let { decodeSampledBitmap(it, reqDecodeSide, reqDecodeSide) }

        canvas.save()
        canvas.clipPath(shapePath)
        if (photoBitmap != null) {
            drawTransformedPhotoInRect(
                canvas = canvas,
                photoBitmap = photoBitmap,
                destRect = slotRect,
                cropScale = payload.cropScale,
                cropOffsetX = payload.cropOffsetX,
                cropOffsetY = payload.cropOffsetY
            )
            photoBitmap.recycle()
        } else {
            // Clean silhouette placeholder inside the exact frame shape
            val silPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accentColor
                alpha = 72
                style = Paint.Style.FILL
            }
            val cx = slotRect.centerX()
            val cy = slotRect.centerY() - 18f * scale
            val headR = min(slotRect.width(), slotRect.height()) * 0.15f
            canvas.drawCircle(cx, cy - headR * 0.8f, headR, silPaint)
            canvas.drawOval(
                RectF(cx - headR * 1.85f, cy + headR * 0.45f, cx + headR * 1.85f, cy + headR * 2.6f),
                silPaint
            )
            val hintPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = labelTypeface
                textSize = 17.5f * scale
                color = Color.WHITE
                alpha = 205
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("ẢNH HỘI VIÊN", cx, slotRect.bottom - 26f * scale, hintPaint)
        }
        canvas.restore()

        // Frame border
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.STROKE
            strokeWidth = 3.8f * scale
        }
        canvas.drawPath(shapePath, borderPaint)
    }

    fun createFrameShapePath(
        rect: RectF,
        shape: PhotoFrameShape,
        cornerRadius: Float
    ): Path {
        val path = Path()
        when (shape) {
            PhotoFrameShape.ROUNDED_RECT -> {
                path.addRoundRect(rect, cornerRadius, cornerRadius, Path.Direction.CW)
            }
            PhotoFrameShape.CIRCLE -> {
                val r = min(rect.width(), rect.height()) / 2f
                path.addCircle(rect.centerX(), rect.centerY(), r, Path.Direction.CW)
            }
            PhotoFrameShape.OVAL_PILL -> {
                val r = rect.width() / 2f
                path.addRoundRect(rect, r, r, Path.Direction.CW)
            }
            PhotoFrameShape.ARCH_TOP -> {
                val topRadius = rect.width() / 2f
                val bottomRadius = min(cornerRadius, 24f)
                val radii = floatArrayOf(
                    topRadius, topRadius,
                    topRadius, topRadius,
                    bottomRadius, bottomRadius,
                    bottomRadius, bottomRadius
                )
                path.addRoundRect(rect, radii, Path.Direction.CW)
            }
            PhotoFrameShape.CHAMFERED_OCTAGON -> {
                val cut = min(rect.width(), rect.height()) * 0.13f
                path.moveTo(rect.left + cut, rect.top)
                path.lineTo(rect.right - cut, rect.top)
                path.lineTo(rect.right, rect.top + cut)
                path.lineTo(rect.right, rect.bottom - cut)
                path.lineTo(rect.right - cut, rect.bottom)
                path.lineTo(rect.left + cut, rect.bottom)
                path.lineTo(rect.left, rect.bottom - cut)
                path.lineTo(rect.left, rect.top + cut)
                path.close()
            }
            PhotoFrameShape.CUT_CORNER -> {
                val cut = min(rect.width(), rect.height()) * 0.14f
                path.moveTo(rect.left + cut, rect.top)
                path.lineTo(rect.right, rect.top)
                path.lineTo(rect.right, rect.bottom - cut)
                path.lineTo(rect.right - cut, rect.bottom)
                path.lineTo(rect.left, rect.bottom)
                path.lineTo(rect.left, rect.top + cut)
                path.close()
            }
        }
        return path
    }

    private fun drawFieldsByStyle(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        headingTypeface: Typeface,
        labelTypeface: Typeface,
        valueTypeface: Typeface
    ) {
        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))
        val primaryTextColor = parseHexColorSafe(template.textPrimaryHex, Color.WHITE)
        val secondaryTextColor = parseHexColorSafe(template.textSecondaryHex, Color.parseColor("#CBD5E1"))
        val priceColor = parseHexColorSafe(template.priceHighlightHex, Color.parseColor("#FBBF24"))

        val contentLeft = width * template.contentLeftRatio
        val contentRight = width * template.contentRightRatio
        val maxContentWidth = (contentRight - contentLeft).coerceAtLeast(240f * scale)
        val colGap = 20f * scale
        val halfColWidth = (maxContentWidth - colGap) / 2f
        val col2Left = contentLeft + halfColWidth + colGap

        // 1. Member Full Name Block with USER Vector Icon
        val userIconSize = 20f * scale
        drawVectorIcon(
            canvas = canvas,
            iconType = CardIconType.USER,
            cx = contentLeft + userIconSize / 2f,
            cy = 184f * scale,
            size = userIconSize,
            color = accentColor,
            scale = scale
        )

        val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = labelTypeface
            color = secondaryTextColor
            textSize = 15.5f * scale
            letterSpacing = 0.06f
        }
        canvas.drawText(
            "HỘI VIÊN CHÍNH THỨC",
            contentLeft + userIconSize + 9f * scale,
            190f * scale,
            labelPaint
        )

        val namePaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = headingTypeface
            color = primaryTextColor
            textSize = 39f * scale
        }
        val displayName = payload.fullName.trim().ifEmpty { "CHƯA NHẬP HỌ TÊN" }.uppercase()
        val fittedName = fitAndEllipsizeText(
            text = displayName,
            paint = namePaint,
            maxWidth = maxContentWidth,
            minTextSize = 22f * scale
        )
        canvas.drawText(fittedName, contentLeft, 238f * scale, namePaint)

        val underlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            strokeWidth = 3f * scale
        }
        canvas.drawLine(contentLeft, 254f * scale, contentLeft + 135f * scale, 254f * scale, underlinePaint)

        // 2. Dynamic Duration Label (Never hardcoded!)
        val dynamicDurationText = when {
            payload.durationMonths != null && payload.durationMonths > 0 -> "${payload.durationMonths} THÁNG"
            payload.packageName.isNotBlank() -> payload.packageName.uppercase()
            else -> "1 THÁNG"
        }

        when (payload.cardType) {
            CardType.GYM_MONTHLY -> {
                // Row 1: Giới tính / Nhóm (GROUP icon) + Số điện thoại (PHONE icon)
                val groupText = (payload.targetGroup ?: TargetGroup.NAM).displayLabel
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 276f * scale, contentLeft + halfColWidth, 382f * scale),
                    iconType = CardIconType.GROUP,
                    label = "NHÓM THẺ",
                    value = groupText,
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 276f * scale, contentRight, 382f * scale),
                    iconType = CardIconType.PHONE,
                    label = "ĐIỆN THOẠI",
                    value = payload.phoneNumber.ifBlank { "—" },
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )

                // Row 2: Ngày bắt đầu (CALENDAR icon) + Ngày hết hạn (CALENDAR_CHECK icon)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 398f * scale, contentLeft + halfColWidth, 504f * scale),
                    iconType = CardIconType.CALENDAR,
                    label = "NGÀY BẮT ĐẦU",
                    value = payload.startDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 398f * scale, contentRight, 504f * scale),
                    iconType = CardIconType.CALENDAR_CHECK,
                    label = "NGÀY HẾT HẠN",
                    value = payload.endDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )

                // Row 3: Thời hạn gói (CLOCK icon) + Giá tiền (WALLET icon)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 520f * scale, contentLeft + halfColWidth, 628f * scale),
                    iconType = CardIconType.CLOCK,
                    label = "THỜI HẠN GÓI",
                    value = dynamicDurationText,
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 520f * scale, contentRight, 628f * scale),
                    iconType = CardIconType.WALLET,
                    label = "GIÁ TIỀN",
                    value = FormattersAndValidators.formatVnd(payload.priceVnd),
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = priceColor,
                    accentColor = priceColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
            }

            CardType.GYM_PT -> {
                // Strictly NO start date, NO expiry date, and NO duplicate card-type field!
                // Row 1: Số điện thoại (Full width or paired cleanly with PT program)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 282f * scale, contentRight, 396f * scale),
                    iconType = CardIconType.PHONE,
                    label = "SỐ ĐIỆN THOẠI LIÊN HỆ",
                    value = payload.phoneNumber.ifBlank { "—" },
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )

                // Row 2: Tổng số buổi PT (DUMBBELL icon) + Giá tiền (WALLET icon)
                val sessionsText = "${payload.totalPtSessions ?: 1} BUỔI PT"
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 418f * scale, contentLeft + halfColWidth, 560f * scale),
                    iconType = CardIconType.DUMBBELL,
                    label = "SỐ BUỔI PT ĐĂNG KÝ",
                    value = sessionsText,
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 418f * scale, contentRight, 560f * scale),
                    iconType = CardIconType.WALLET,
                    label = "GIÁ TIỀN GÓI PT",
                    value = FormattersAndValidators.formatVnd(payload.priceVnd),
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = priceColor,
                    accentColor = priceColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
            }

            CardType.YOGA_MONTHLY -> {
                // Row 1: Số điện thoại (PHONE icon) + Thời hạn gói (CLOCK icon)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 276f * scale, contentLeft + halfColWidth, 382f * scale),
                    iconType = CardIconType.PHONE,
                    label = "ĐIỆN THOẠI",
                    value = payload.phoneNumber.ifBlank { "—" },
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 276f * scale, contentRight, 382f * scale),
                    iconType = CardIconType.CLOCK,
                    label = "THỜI HẠN GÓI",
                    value = dynamicDurationText,
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )

                // Row 2: Ngày bắt đầu (CALENDAR icon) + Ngày hết hạn (CALENDAR_CHECK icon)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 398f * scale, contentLeft + halfColWidth, 504f * scale),
                    iconType = CardIconType.CALENDAR,
                    label = "NGÀY BẮT ĐẦU",
                    value = payload.startDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 398f * scale, contentRight, 504f * scale),
                    iconType = CardIconType.CALENDAR_CHECK,
                    label = "NGÀY HẾT HẠN",
                    value = payload.endDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )

                // Row 3: Giá tiền (WALLET icon - Full width highlight)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 520f * scale, contentRight, 628f * scale),
                    iconType = CardIconType.WALLET,
                    label = "GIÁ TIỀN GÓI TẬP",
                    value = FormattersAndValidators.formatVnd(payload.priceVnd),
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = priceColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
            }
        }
    }

    private fun drawStyledFieldBox(
        canvas: Canvas,
        rect: RectF,
        iconType: CardIconType,
        label: String,
        value: String,
        scale: Float,
        boxStyle: InfoBoxStyle,
        labelColor: Int,
        valueColor: Int,
        accentColor: Int,
        labelTypeface: Typeface,
        valueTypeface: Typeface
    ) {
        when (boxStyle) {
            InfoBoxStyle.FILLED_GLASS -> {
                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.BLACK
                    alpha = 64
                    style = Paint.Style.FILL
                }
                canvas.drawRoundRect(rect, 16f * scale, 16f * scale, bgPaint)
                val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accentColor
                    alpha = 68
                    style = Paint.Style.STROKE
                    strokeWidth = 1.5f * scale
                }
                canvas.drawRoundRect(rect, 16f * scale, 16f * scale, strokePaint)
            }

            InfoBoxStyle.OUTLINE_SHARP -> {
                val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accentColor
                    alpha = 115
                    style = Paint.Style.STROKE
                    strokeWidth = 2f * scale
                }
                canvas.drawRect(rect, strokePaint)
            }

            InfoBoxStyle.MINIMAL_HAIRLINE -> {
                val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accentColor
                    alpha = 88
                    strokeWidth = 2f * scale
                }
                canvas.drawLine(rect.left, rect.bottom, rect.right, rect.bottom, linePaint)
            }

            InfoBoxStyle.PILL_CARD -> {
                val r = rect.height() * 0.34f
                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    alpha = 20
                    style = Paint.Style.FILL
                }
                canvas.drawRoundRect(rect, r, r, bgPaint)
                val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accentColor
                    alpha = 90
                    style = Paint.Style.STROKE
                    strokeWidth = 1.6f * scale
                }
                canvas.drawRoundRect(rect, r, r, strokePaint)
            }

            InfoBoxStyle.EDITORIAL_COLUMN -> {
                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.BLACK
                    alpha = 46
                    style = Paint.Style.FILL
                }
                canvas.drawRect(rect, bgPaint)
                val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accentColor
                    alpha = 235
                    style = Paint.Style.FILL
                }
                canvas.drawRect(rect.left, rect.top, rect.left + 6f * scale, rect.bottom, barPaint)
            }
        }

        val padX = if (boxStyle == InfoBoxStyle.MINIMAL_HAIRLINE) 4f * scale else 18f * scale
        val maxValWidth = (rect.width() - padX * 2).coerceAtLeast(60f)

        // Draw crisp vector icon before the field label
        val iconSize = 18f * scale
        val labelBaselineY = rect.top + 31f * scale
        val iconCy = labelBaselineY - 6.5f * scale
        drawVectorIcon(
            canvas = canvas,
            iconType = iconType,
            cx = rect.left + padX + iconSize / 2f,
            cy = iconCy,
            size = iconSize,
            color = accentColor,
            scale = scale
        )

        val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = labelTypeface
            color = labelColor
            textSize = 14.5f * scale
            letterSpacing = 0.05f
        }
        val labelX = rect.left + padX + iconSize + 8f * scale
        val fittedLabel = fitAndEllipsizeText(
            text = label,
            paint = labelPaint,
            maxWidth = (rect.right - labelX - 8f * scale).coerceAtLeast(40f),
            minTextSize = 12f * scale
        )
        canvas.drawText(fittedLabel, labelX, labelBaselineY, labelPaint)

        val valPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = valueTypeface
            color = valueColor
            textSize = 27.5f * scale
        }
        val fittedVal = fitAndEllipsizeText(
            text = value,
            paint = valPaint,
            maxWidth = maxValWidth,
            minTextSize = 18f * scale
        )
        canvas.drawText(fittedVal, rect.left + padX, rect.bottom - 20f * scale, valPaint)
    }

    /**
     * Unified Vector Icon Renderer (Part 6 of V4.0 Spec):
     * Draws resolution-independent vector icons with uniform stroke thickness & high contrast.
     */
    private fun drawVectorIcon(
        canvas: Canvas,
        iconType: CardIconType,
        cx: Float,
        cy: Float,
        size: Float,
        color: Int,
        scale: Float
    ) {
        val r = size / 2f
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.STROKE
            strokeWidth = 2.2f * scale
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        when (iconType) {
            CardIconType.USER -> {
                // Person head + shoulders
                canvas.drawCircle(cx, cy - r * 0.34f, r * 0.38f, strokePaint)
                val arcRect = RectF(cx - r * 0.78f, cy + r * 0.12f, cx + r * 0.78f, cy + r * 1.15f)
                canvas.drawArc(arcRect, 180f, 180f, false, strokePaint)
            }

            CardIconType.GROUP -> {
                // Primary user + secondary user silhouette
                canvas.drawCircle(cx - r * 0.22f, cy - r * 0.32f, r * 0.34f, strokePaint)
                val primaryArc = RectF(cx - r * 0.85f, cy + r * 0.14f, cx + r * 0.40f, cy + r * 1.05f)
                canvas.drawArc(primaryArc, 180f, 180f, false, strokePaint)
                canvas.drawCircle(cx + r * 0.42f, cy - r * 0.22f, r * 0.26f, strokePaint)
                val secArc = RectF(cx + r * 0.05f, cy + r * 0.24f, cx + r * 0.92f, cy + r * 1.05f)
                canvas.drawArc(secArc, 200f, 140f, false, strokePaint)
            }

            CardIconType.PHONE -> {
                // Rounded smartphone frame with speaker & home dot
                val phoneRect = RectF(cx - r * 0.56f, cy - r * 0.86f, cx + r * 0.56f, cy + r * 0.86f)
                canvas.drawRoundRect(phoneRect, 3.5f * scale, 3.5f * scale, strokePaint)
                canvas.drawLine(cx - r * 0.20f, cy - r * 0.58f, cx + r * 0.20f, cy - r * 0.58f, strokePaint)
                canvas.drawPoint(cx, cy + r * 0.56f, strokePaint)
            }

            CardIconType.CALENDAR -> {
                // Calendar box + top rings + divider line
                val calRect = RectF(cx - r * 0.82f, cy - r * 0.68f, cx + r * 0.82f, cy + r * 0.82f)
                canvas.drawRoundRect(calRect, 3.5f * scale, 3.5f * scale, strokePaint)
                canvas.drawLine(calRect.left, cy - r * 0.22f, calRect.right, cy - r * 0.22f, strokePaint)
                canvas.drawLine(cx - r * 0.42f, cy - r * 0.92f, cx - r * 0.42f, cy - r * 0.48f, strokePaint)
                canvas.drawLine(cx + r * 0.42f, cy - r * 0.92f, cx + r * 0.42f, cy - r * 0.48f, strokePaint)
            }

            CardIconType.CALENDAR_CHECK -> {
                // Calendar box + checkmark inside
                val calRect = RectF(cx - r * 0.82f, cy - r * 0.68f, cx + r * 0.82f, cy + r * 0.82f)
                canvas.drawRoundRect(calRect, 3.5f * scale, 3.5f * scale, strokePaint)
                canvas.drawLine(calRect.left, cy - r * 0.22f, calRect.right, cy - r * 0.22f, strokePaint)
                canvas.drawLine(cx - r * 0.42f, cy - r * 0.92f, cx - r * 0.42f, cy - r * 0.48f, strokePaint)
                canvas.drawLine(cx + r * 0.42f, cy - r * 0.92f, cx + r * 0.42f, cy - r * 0.48f, strokePaint)
                val checkPath = Path().apply {
                    moveTo(cx - r * 0.36f, cy + r * 0.28f)
                    lineTo(cx - r * 0.08f, cy + r * 0.54f)
                    lineTo(cx + r * 0.42f, cy + r * 0.04f)
                }
                canvas.drawPath(checkPath, strokePaint)
            }

            CardIconType.CLOCK -> {
                // Clock circle + hour & minute hands
                canvas.drawCircle(cx, cy, r * 0.82f, strokePaint)
                canvas.drawLine(cx, cy, cx, cy - r * 0.46f, strokePaint)
                canvas.drawLine(cx, cy, cx + r * 0.38f, cy + r * 0.20f, strokePaint)
            }

            CardIconType.DUMBBELL -> {
                // Barbell / Dumbbell vector
                canvas.drawLine(cx - r * 0.88f, cy, cx + r * 0.88f, cy, strokePaint)
                canvas.drawLine(cx - r * 0.56f, cy - r * 0.58f, cx - r * 0.56f, cy + r * 0.58f, strokePaint)
                canvas.drawLine(cx - r * 0.82f, cy - r * 0.38f, cx - r * 0.82f, cy + r * 0.38f, strokePaint)
                canvas.drawLine(cx + r * 0.56f, cy - r * 0.58f, cx + r * 0.56f, cy + r * 0.58f, strokePaint)
                canvas.drawLine(cx + r * 0.82f, cy - r * 0.38f, cx + r * 0.82f, cy + r * 0.38f, strokePaint)
            }

            CardIconType.WALLET -> {
                // Wallet body + clasp flap
                val wRect = RectF(cx - r * 0.85f, cy - r * 0.62f, cx + r * 0.85f, cy + r * 0.68f)
                canvas.drawRoundRect(wRect, 3.5f * scale, 3.5f * scale, strokePaint)
                val claspRect = RectF(cx + r * 0.18f, cy - r * 0.22f, cx + r * 0.85f, cy + r * 0.26f)
                canvas.drawRoundRect(claspRect, 2.5f * scale, 2.5f * scale, strokePaint)
            }

            CardIconType.MEMBERSHIP_CARD -> {
                // Membership card outline + stripe + chip dot
                val cRect = RectF(cx - r * 0.88f, cy - r * 0.62f, cx + r * 0.88f, cy + r * 0.62f)
                canvas.drawRoundRect(cRect, 3.5f * scale, 3.5f * scale, strokePaint)
                canvas.drawLine(cRect.left, cy - r * 0.16f, cRect.right, cy - r * 0.16f, strokePaint)
                canvas.drawLine(cx - r * 0.52f, cy + r * 0.24f, cx - r * 0.10f, cy + r * 0.24f, strokePaint)
            }
        }
    }

    private fun drawFooterBar(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        footerTypeface: Typeface
    ) {
        val secondaryTextColor = parseHexColorSafe(template.textSecondaryHex, Color.LTGRAY)
        val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = footerTypeface
            textSize = 16.5f * scale
            color = secondaryTextColor
            alpha = 205
        }
        val startX = when {
            template.artworkPattern == ArtworkPatternStyle.G3_BOLD_SPORT_EDITORIAL -> 96f * scale
            template.artworkPattern == ArtworkPatternStyle.P3_BLACK_TITANIUM -> 78f * scale
            else -> 64f * scale
        }
        val contact = payload.brandContact.trim().ifEmpty { payload.brandName }
        val fittedContact = fitAndEllipsizeText(
            text = contact,
            paint = footerPaint,
            maxWidth = width - startX - 56f * scale,
            minTextSize = 13.5f * scale
        )
        canvas.drawText(fittedContact, startX, height - 34f * scale, footerPaint)
    }

    fun fitAndEllipsizeText(
        text: String,
        paint: TextPaint,
        maxWidth: Float,
        minTextSize: Float
    ): String {
        if (text.isEmpty() || maxWidth <= 0f) return text
        var currentSize = paint.textSize
        while (paint.measureText(text) > maxWidth && currentSize > minTextSize) {
            currentSize = (currentSize - 1.5f).coerceAtLeast(minTextSize)
            paint.textSize = currentSize
        }
        return if (paint.measureText(text) > maxWidth) {
            TextUtils.ellipsize(text, paint, maxWidth, TextUtils.TruncateAt.END).toString()
        } else {
            text
        }
    }

    private fun drawTransformedPhotoInRect(
        canvas: Canvas,
        photoBitmap: Bitmap,
        destRect: RectF,
        cropScale: Float,
        cropOffsetX: Float,
        cropOffsetY: Float
    ) {
        val bw = photoBitmap.width.toFloat().coerceAtLeast(1f)
        val bh = photoBitmap.height.toFloat().coerceAtLeast(1f)
        val baseScale = max(destRect.width() / bw, destRect.height() / bh)
        val userScale = cropScale.coerceIn(0.5f, 5.0f)
        val totalScale = baseScale * userScale

        val scaledW = bw * totalScale
        val scaledH = bh * totalScale

        val dx = destRect.centerX() - (scaledW / 2f) + (cropOffsetX * destRect.width())
        val dy = destRect.centerY() - (scaledH / 2f) + (cropOffsetY * destRect.height())

        val matrix = Matrix().apply {
            postScale(totalScale, totalScale)
            postTranslate(dx, dy)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(photoBitmap, matrix, paint)
    }

    fun decodeSampledBitmap(path: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        return try {
            val file = File(path)
            if (!file.exists()) return null
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, options)
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
            options.inJustDecodeBounds = false
            options.inPreferredConfig = Bitmap.Config.ARGB_8888
            BitmapFactory.decodeFile(path, options)
        } catch (_: Exception) {
            null
        }
    }

    private fun calculateInSampleSize(
        options: BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    fun parseHexColorSafe(hex: String, fallback: Int): Int {
        return try {
            Color.parseColor(hex.trim())
        } catch (_: Exception) {
            fallback
        }
    }
}
