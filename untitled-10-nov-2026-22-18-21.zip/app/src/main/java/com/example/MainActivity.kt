package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AddCard
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.CreateCardTabScreen
import com.example.ui.screens.SettingsTabScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.BottomNavTab
import com.example.ui.viewmodel.CardMakerViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: CardMakerViewModel = viewModel(
                factory = CardMakerViewModel.provideFactory(application)
            )
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

            MyApplicationTheme(themeMode = themeMode) {
                Fitness89CardMakerApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun Fitness89CardMakerApp(viewModel: CardMakerViewModel) {
    val context = LocalContext.current

    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val wizardStep by viewModel.wizardStep.collectAsStateWithLifecycle()
    val draft by viewModel.draft.collectAsStateWithLifecycle()
    val packages by viewModel.packages.collectAsStateWithLifecycle()
    val templates by viewModel.templates.collectAsStateWithLifecycle()
    val brandConfig by viewModel.brandConfig.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val exportResolution by viewModel.exportResolution.collectAsStateWithLifecycle()
    val hasUnsavedChanges by viewModel.hasUnsavedChanges.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val isStatusError by viewModel.isStatusError.collectAsStateWithLifecycle()

    var pendingTabSwitch by remember { mutableStateOf<BottomNavTab?>(null) }

    LaunchedEffect(statusMessage) {
        if (statusMessage != null) {
            delay(3600L)
            viewModel.clearStatusMessage()
        }
    }

    // BackHandler on Settings tab returns to Create Card tab
    BackHandler(enabled = currentTab != BottomNavTab.CREATE_CARD) {
        viewModel.selectBottomTab(BottomNavTab.CREATE_CARD)
    }

    val handleTabSelection = { targetTab: BottomNavTab ->
        if (targetTab != currentTab) {
            if (currentTab == BottomNavTab.CREATE_CARD &&
                wizardStep != null &&
                hasUnsavedChanges
            ) {
                pendingTabSwitch = targetTab
            } else {
                if (wizardStep != null) {
                    viewModel.exitWizard()
                }
                viewModel.selectBottomTab(targetTab)
            }
        } else if (targetTab == BottomNavTab.CREATE_CARD && wizardStep != null) {
            if (hasUnsavedChanges) {
                pendingTabSwitch = BottomNavTab.CREATE_CARD
            } else {
                viewModel.exitWizard()
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("main_bottom_navigation")
            ) {
                NavigationBarItem(
                    selected = currentTab == BottomNavTab.CREATE_CARD,
                    onClick = { handleTabSelection(BottomNavTab.CREATE_CARD) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == BottomNavTab.CREATE_CARD) Icons.Filled.AddCard else Icons.Outlined.AddCard,
                            contentDescription = "Tạo thẻ"
                        )
                    },
                    label = { Text("Tạo thẻ", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("bottom_nav_create_card")
                )

                NavigationBarItem(
                    selected = currentTab == BottomNavTab.SETTINGS,
                    onClick = { handleTabSelection(BottomNavTab.SETTINGS) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == BottomNavTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                            contentDescription = "Cài đặt"
                        )
                    },
                    label = { Text("Cài đặt", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("bottom_nav_settings")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                BottomNavTab.CREATE_CARD -> {
                    CreateCardTabScreen(
                        wizardStep = wizardStep,
                        draft = draft,
                        packages = packages,
                        templates = templates,
                        brandConfig = brandConfig,
                        hasUnsavedChanges = hasUnsavedChanges,
                        isBusy = isBusy,
                        onStartNewCard = { cardType -> viewModel.startNewCardWizard(cardType) },
                        onNavigateTab = { tab -> handleTabSelection(tab) },
                        onExitWizard = { viewModel.exitWizard() },
                        onGoToStep = { step -> viewModel.goToWizardStep(step) },
                        onSelectTemplate = { tplId -> viewModel.selectTemplateForDraft(tplId) },
                        onTargetGroupChanged = { group -> viewModel.onTargetGroupChanged(group) },
                        onPackageSelected = { pkg -> viewModel.onPackageSelected(pkg) },
                        onUpdateDraftFields = { fullName, phone, durationMonths, start, end, sessions, price ->
                            viewModel.updateDraftFields(
                                fullName = fullName,
                                phoneNumber = phone,
                                durationMonthsText = durationMonths,
                                startDate = start,
                                endDate = end,
                                totalPtSessions = sessions,
                                priceVndText = price
                            )
                        },
                        onPhotoPickedFromDevice = { uri -> viewModel.onPhotoPickedFromDeviceUri(uri) },
                        onPhotoCapturedFromCamera = { file -> viewModel.onPhotoCapturedFromCamera(file) },
                        onUpdateCropTransform = { scale, ox, oy ->
                            viewModel.updateCropTransform(scale, ox, oy)
                        },
                        onResetCropTransform = { viewModel.resetCropTransform() },
                        onBuildDraftPayload = { viewModel.buildRenderPayloadFromDraft() },
                        onExportPng = { payload -> viewModel.exportPayloadToPng(payload) },
                        onExportPdf = { payload ->
                            viewModel.exportPayloadToPdf(payload) { pdfUri ->
                                shareUriViaSharesheet(
                                    context = context,
                                    uri = pdfUri,
                                    mimeType = "application/pdf",
                                    chooserTitle = "Chia sẻ / Lưu tệp PDF thẻ hội viên"
                                )
                            }
                        },
                        onShareCard = { payload ->
                            viewModel.sharePayloadDirectPng(payload) { pngUri ->
                                shareUriViaSharesheet(
                                    context = context,
                                    uri = pngUri,
                                    mimeType = "image/png",
                                    chooserTitle = "Chia sẻ thẻ hội viên qua Zalo / Messenger / Gmail"
                                )
                            }
                        },
                        onPostError = { msg -> viewModel.postMessage(msg, isError = true) }
                    )
                }

                BottomNavTab.SETTINGS -> {
                    SettingsTabScreen(
                        brandConfig = brandConfig,
                        packages = packages,
                        templates = templates,
                        themeMode = themeMode,
                        exportResolution = exportResolution,
                        onSaveBrandSettings = { name, contact, logoUri, removeLogo ->
                            viewModel.saveBrandSettings(name, contact, logoUri, removeLogo)
                        },
                        onSavePackage = { pkg -> viewModel.savePackageConfig(pkg) },
                        onDeletePackage = { pkg -> viewModel.deletePackageConfig(pkg) },
                        onResetDefaultPackagesForCategory = { type ->
                            viewModel.resetDefaultPackagesForCategory(type)
                        },
                        onSetDefaultTemplate = { type, tplId ->
                            viewModel.setDefaultTemplateForCategory(type, tplId)
                        },
                        onSetDefaultTemplateForAll = { tplId ->
                            viewModel.setDefaultTemplateForAllCategories(tplId)
                        },
                        onToggleTemplateEnabled = { tpl, enabled ->
                            viewModel.toggleTemplateEnabled(tpl, enabled)
                        },
                        onRestoreAllTemplates = { viewModel.restoreAllBuiltInTemplates() },
                        onSelectThemeMode = { mode -> viewModel.setThemeMode(mode) },
                        onSelectExportResolution = { res -> viewModel.setExportResolution(res) }
                    )
                }
            }

            // Floating Status Notification Banner
            AnimatedVisibility(
                visible = statusMessage != null,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                val msg = statusMessage ?: ""
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (isStatusError) Color(0xFFB91C1C) else Color(0xFF065F46),
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("status_notification_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isStatusError) Icons.Default.ErrorOutline else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    // Unsaved changes guard when switching bottom tabs
    if (pendingTabSwitch != null) {
        val target = pendingTabSwitch!!
        AlertDialog(
            onDismissRequest = { pendingTabSwitch = null },
            title = { Text("Dữ liệu thẻ đang tạo chưa xuất") },
            text = {
                Text("Bạn đang tạo thẻ hội viên nhưng chưa xuất PNG/PDF. Bạn muốn tiếp tục chỉnh sửa hay hủy thẻ đang tạo để chuyển màn hình?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingTabSwitch = null
                        viewModel.exitWizard()
                        viewModel.selectBottomTab(target)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Hủy thẻ & Chuyển")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingTabSwitch = null }) {
                    Text("Tiếp tục chỉnh sửa")
                }
            }
        )
    }
}

private fun shareUriViaSharesheet(
    context: Context,
    uri: Uri,
    mimeType: String,
    chooserTitle: String
) {
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val chooser = Intent.createChooser(shareIntent, chooserTitle).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching {
        context.startActivity(chooser)
    }
}
