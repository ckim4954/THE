package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateCatalog

@Database(
    entities = [
        WorkoutPackageEntity::class,
        CardTemplateEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fitness_89_card_maker_v4.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }

        fun defaultGymMonthlyPackages(): List<WorkoutPackageEntity> = listOf(
            // Men: 1m 300k, 2m 550k, 3m 800k, 12m 3,000k
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NAM.code,
                packageName = "1 tháng",
                durationMonths = 1,
                totalSessions = null,
                priceVnd = 300_000L,
                isDefaultSeed = true,
                sortOrder = 1
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NAM.code,
                packageName = "2 tháng",
                durationMonths = 2,
                totalSessions = null,
                priceVnd = 550_000L,
                isDefaultSeed = true,
                sortOrder = 2
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NAM.code,
                packageName = "3 tháng",
                durationMonths = 3,
                totalSessions = null,
                priceVnd = 800_000L,
                isDefaultSeed = true,
                sortOrder = 3
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NAM.code,
                packageName = "12 tháng",
                durationMonths = 12,
                totalSessions = null,
                priceVnd = 3_000_000L,
                isDefaultSeed = true,
                sortOrder = 4
            ),
            // Women: 1m 250k, 2m 450k, 3m 700k, 12m 2,800k
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NU.code,
                packageName = "1 tháng",
                durationMonths = 1,
                totalSessions = null,
                priceVnd = 250_000L,
                isDefaultSeed = true,
                sortOrder = 1
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NU.code,
                packageName = "2 tháng",
                durationMonths = 2,
                totalSessions = null,
                priceVnd = 450_000L,
                isDefaultSeed = true,
                sortOrder = 2
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NU.code,
                packageName = "3 tháng",
                durationMonths = 3,
                totalSessions = null,
                priceVnd = 700_000L,
                isDefaultSeed = true,
                sortOrder = 3
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NU.code,
                packageName = "12 tháng",
                durationMonths = 12,
                totalSessions = null,
                priceVnd = 2_800_000L,
                isDefaultSeed = true,
                sortOrder = 4
            ),
            // Children: 1m 300k, 2m 500k, 3m 700k, 12m 2,500k
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.TRE_EM.code,
                packageName = "1 tháng",
                durationMonths = 1,
                totalSessions = null,
                priceVnd = 300_000L,
                isDefaultSeed = true,
                sortOrder = 1
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.TRE_EM.code,
                packageName = "2 tháng",
                durationMonths = 2,
                totalSessions = null,
                priceVnd = 500_000L,
                isDefaultSeed = true,
                sortOrder = 2
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.TRE_EM.code,
                packageName = "3 tháng",
                durationMonths = 3,
                totalSessions = null,
                priceVnd = 700_000L,
                isDefaultSeed = true,
                sortOrder = 3
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.TRE_EM.code,
                packageName = "12 tháng",
                durationMonths = 12,
                totalSessions = null,
                priceVnd = 2_500_000L,
                isDefaultSeed = true,
                sortOrder = 4
            )
        )

        fun defaultYogaMonthlyPackages(): List<WorkoutPackageEntity> = listOf(
            // Yoga Monthly Defaults: 1m 500k, 2m 1,000k, 3m 1,500k
            WorkoutPackageEntity(
                cardType = CardType.YOGA_MONTHLY.code,
                targetGroup = null,
                packageName = "1 tháng",
                durationMonths = 1,
                totalSessions = null,
                priceVnd = 500_000L,
                isDefaultSeed = true,
                sortOrder = 1
            ),
            WorkoutPackageEntity(
                cardType = CardType.YOGA_MONTHLY.code,
                targetGroup = null,
                packageName = "2 tháng",
                durationMonths = 2,
                totalSessions = null,
                priceVnd = 1_000_000L,
                isDefaultSeed = true,
                sortOrder = 2
            ),
            WorkoutPackageEntity(
                cardType = CardType.YOGA_MONTHLY.code,
                targetGroup = null,
                packageName = "3 tháng",
                durationMonths = 3,
                totalSessions = null,
                priceVnd = 1_500_000L,
                isDefaultSeed = true,
                sortOrder = 3
            )
        )

        fun defaultAllSeededPackages(): List<WorkoutPackageEntity> =
            defaultGymMonthlyPackages() + defaultYogaMonthlyPackages()

        fun defaultTemplates(): List<CardTemplateEntity> =
            TemplateCatalog.allBuiltInTemplates().mapIndexed { index, metadata ->
                CardTemplateEntity.fromDomainModel(metadata, sortOrder = index + 1)
            }
    }
}
