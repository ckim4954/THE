package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.BrandConfig
import com.example.domain.model.ExportResolution
import com.example.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "fitness_89_preferences"
)

class AppPreferencesRepository(private val context: Context) {

    private object Keys {
        val INITIAL_SEED_DONE = booleanPreferencesKey("initial_seed_done")
        val BRAND_NAME = stringPreferencesKey("brand_name")
        val BRAND_CONTACT = stringPreferencesKey("brand_contact")
        val BRAND_LOGO_PATH = stringPreferencesKey("brand_logo_path")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val EXPORT_RESOLUTION = stringPreferencesKey("export_resolution")
    }

    val brandConfigFlow: Flow<BrandConfig> = context.dataStore.data.map { prefs ->
        BrandConfig(
            brandName = prefs[Keys.BRAND_NAME] ?: "89 FITNESS & YOGA",
            contactInfo = prefs[Keys.BRAND_CONTACT] ?: "Hội viên chính thức • 89 FITNESS & YOGA",
            customLogoPath = prefs[Keys.BRAND_LOGO_PATH]?.takeIf { it.isNotBlank() }
        )
    }

    val themeModeFlow: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        ThemeMode.fromCode(prefs[Keys.THEME_MODE])
    }

    val exportResolutionFlow: Flow<ExportResolution> = context.dataStore.data.map { prefs ->
        ExportResolution.fromCode(prefs[Keys.EXPORT_RESOLUTION])
    }

    suspend fun isInitialSeedDone(): Boolean {
        return context.dataStore.data.first()[Keys.INITIAL_SEED_DONE] ?: false
    }

    suspend fun markInitialSeedDone() {
        context.dataStore.edit { prefs ->
            prefs[Keys.INITIAL_SEED_DONE] = true
        }
    }

    suspend fun saveBrandConfig(config: BrandConfig) {
        context.dataStore.edit { prefs ->
            prefs[Keys.BRAND_NAME] = config.brandName.trim().ifEmpty { "89 FITNESS & YOGA" }
            prefs[Keys.BRAND_CONTACT] = config.contactInfo.trim()
            if (config.customLogoPath.isNullOrBlank()) {
                prefs.remove(Keys.BRAND_LOGO_PATH)
            } else {
                prefs[Keys.BRAND_LOGO_PATH] = config.customLogoPath
            }
        }
    }

    suspend fun saveThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode.code
        }
    }

    suspend fun saveExportResolution(resolution: ExportResolution) {
        context.dataStore.edit { prefs ->
            prefs[Keys.EXPORT_RESOLUTION] = resolution.code
        }
    }

    suspend fun getBrandConfigSnapshot(): BrandConfig = brandConfigFlow.first()
    suspend fun getExportResolutionSnapshot(): ExportResolution = exportResolutionFlow.first()
}
