package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- Workout Packages ---
    @Query("SELECT * FROM workout_packages ORDER BY cardType ASC, targetGroup ASC, sortOrder ASC, id ASC")
    fun observeAllPackages(): Flow<List<WorkoutPackageEntity>>

    @Query("SELECT * FROM workout_packages ORDER BY id ASC")
    suspend fun getAllPackagesSnapshot(): List<WorkoutPackageEntity>

    @Query("SELECT COUNT(*) FROM workout_packages")
    suspend fun countPackages(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackages(packages: List<WorkoutPackageEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackage(pkg: WorkoutPackageEntity): Long

    @Update
    suspend fun updatePackage(pkg: WorkoutPackageEntity)

    @Query("DELETE FROM workout_packages WHERE id = :id")
    suspend fun deletePackageById(id: Long)

    // --- Card Templates (V4.0 12-Template System) ---
    @Query("SELECT * FROM card_templates ORDER BY sortOrder ASC, templateId ASC")
    fun observeAllTemplates(): Flow<List<CardTemplateEntity>>

    @Query("SELECT * FROM card_templates ORDER BY sortOrder ASC, templateId ASC")
    suspend fun getAllTemplatesSnapshot(): List<CardTemplateEntity>

    @Query("SELECT * FROM card_templates WHERE templateId = :templateId LIMIT 1")
    suspend fun getTemplateById(templateId: String): CardTemplateEntity?

    @Query("SELECT COUNT(*) FROM card_templates")
    suspend fun countTemplates(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplates(templates: List<CardTemplateEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: CardTemplateEntity)

    @Query("UPDATE card_templates SET isDefaultForGym = CASE WHEN templateId = :templateId THEN 1 ELSE 0 END")
    suspend fun setDefaultTemplateForGym(templateId: String)

    @Query("UPDATE card_templates SET isDefaultForYoga = CASE WHEN templateId = :templateId THEN 1 ELSE 0 END")
    suspend fun setDefaultTemplateForYoga(templateId: String)

    @Query("UPDATE card_templates SET isDefaultForPt = CASE WHEN templateId = :templateId THEN 1 ELSE 0 END")
    suspend fun setDefaultTemplateForPt(templateId: String)

    @Query("UPDATE card_templates SET isEnabled = :enabled WHERE templateId = :templateId")
    suspend fun setTemplateEnabled(templateId: String, enabled: Boolean)

    @Query("DELETE FROM card_templates")
    suspend fun clearAllTemplates()
}
