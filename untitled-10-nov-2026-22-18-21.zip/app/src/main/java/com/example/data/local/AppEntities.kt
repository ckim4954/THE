package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.ArtworkPatternStyle
import com.example.domain.model.CardType
import com.example.domain.model.HeaderLayoutStyle
import com.example.domain.model.ImageSlotSpec
import com.example.domain.model.InfoBoxStyle
import com.example.domain.model.PhotoFrameShape
import com.example.domain.model.TemplateCategory
import com.example.domain.model.TemplateMetadata

@Entity(tableName = "workout_packages")
data class WorkoutPackageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val cardType: String, // GYM_MONTHLY, GYM_PT, YOGA_MONTHLY
    val targetGroup: String?, // NAM, NU, TRE_EM for GYM_MONTHLY; null for PT & YOGA
    val packageName: String,
    val durationMonths: Int?, // For GYM_MONTHLY & YOGA_MONTHLY
    val totalSessions: Int?, // For GYM_PT
    val priceVnd: Long,
    val isDefaultSeed: Boolean = false,
    val sortOrder: Int = 0
)

@Entity(tableName = "card_templates")
data class CardTemplateEntity(
    @PrimaryKey val templateId: String,
    val templateVersion: Int = 4,
    val category: String, // UNIVERSAL, GYM, YOGA, PT
    val templateName: String,
    val styleName: String,
    val canvasWidth: Int = 1200,
    val canvasHeight: Int = 750,
    val backgroundColorHex: String,
    val secondaryColorHex: String,
    val accentColorHex: String,
    val textPrimaryHex: String,
    val textSecondaryHex: String,
    val priceHighlightHex: String,
    val headerStyle: String,
    val infoBoxStyle: String,
    val artworkPattern: String,
    val contentLeftRatio: Float,
    val contentRightRatio: Float,
    val contentTopRatio: Float,
    val slotXRatio: Float,
    val slotYRatio: Float,
    val slotWidthRatio: Float,
    val slotHeightRatio: Float,
    val slotCornerRadiusRatio: Float,
    val slotShape: String,
    val isEnabled: Boolean = true,
    val isDefaultForGym: Boolean = false,
    val isDefaultForYoga: Boolean = false,
    val isDefaultForPt: Boolean = false,
    val sortOrder: Int = 0
) {
    fun toDomainModel(): TemplateMetadata {
        val defaultTypes = buildSet {
            if (isDefaultForGym) add(CardType.GYM_MONTHLY)
            if (isDefaultForYoga) add(CardType.YOGA_MONTHLY)
            if (isDefaultForPt) add(CardType.GYM_PT)
        }
        return TemplateMetadata(
            templateId = templateId,
            templateVersion = templateVersion,
            category = TemplateCategory.fromCode(category),
            templateName = templateName,
            styleName = styleName,
            canvasWidth = canvasWidth,
            canvasHeight = canvasHeight,
            backgroundColorHex = backgroundColorHex,
            secondaryColorHex = secondaryColorHex,
            accentColorHex = accentColorHex,
            textPrimaryHex = textPrimaryHex,
            textSecondaryHex = textSecondaryHex,
            priceHighlightHex = priceHighlightHex,
            headerStyle = HeaderLayoutStyle.fromCode(headerStyle),
            infoBoxStyle = InfoBoxStyle.fromCode(infoBoxStyle),
            artworkPattern = ArtworkPatternStyle.fromCode(artworkPattern),
            contentLeftRatio = contentLeftRatio,
            contentRightRatio = contentRightRatio,
            contentTopRatio = contentTopRatio,
            imageSlot = ImageSlotSpec(
                xRatio = slotXRatio,
                yRatio = slotYRatio,
                widthRatio = slotWidthRatio,
                heightRatio = slotHeightRatio,
                cornerRadiusRatio = slotCornerRadiusRatio,
                shape = PhotoFrameShape.fromCode(slotShape)
            ),
            isEnabled = isEnabled,
            defaultForCardTypes = defaultTypes
        )
    }

    companion object {
        fun fromDomainModel(model: TemplateMetadata, sortOrder: Int): CardTemplateEntity =
            CardTemplateEntity(
                templateId = model.templateId,
                templateVersion = model.templateVersion,
                category = model.category.code,
                templateName = model.templateName,
                styleName = model.styleName,
                canvasWidth = model.canvasWidth,
                canvasHeight = model.canvasHeight,
                backgroundColorHex = model.backgroundColorHex,
                secondaryColorHex = model.secondaryColorHex,
                accentColorHex = model.accentColorHex,
                textPrimaryHex = model.textPrimaryHex,
                textSecondaryHex = model.textSecondaryHex,
                priceHighlightHex = model.priceHighlightHex,
                headerStyle = model.headerStyle.code,
                infoBoxStyle = model.infoBoxStyle.code,
                artworkPattern = model.artworkPattern.code,
                contentLeftRatio = model.contentLeftRatio,
                contentRightRatio = model.contentRightRatio,
                contentTopRatio = model.contentTopRatio,
                slotXRatio = model.imageSlot.xRatio,
                slotYRatio = model.imageSlot.yRatio,
                slotWidthRatio = model.imageSlot.widthRatio,
                slotHeightRatio = model.imageSlot.heightRatio,
                slotCornerRadiusRatio = model.imageSlot.cornerRadiusRatio,
                slotShape = model.imageSlot.shape.code,
                isEnabled = model.isEnabled,
                isDefaultForGym = model.isDefaultFor(CardType.GYM_MONTHLY),
                isDefaultForYoga = model.isDefaultFor(CardType.YOGA_MONTHLY),
                isDefaultForPt = model.isDefaultFor(CardType.GYM_PT),
                sortOrder = sortOrder
            )
    }
}
