package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.local.AppDao
import com.example.data.local.AppDatabase
import com.example.data.local.WorkoutPackageEntity
import com.example.data.preferences.AppPreferencesRepository
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardType
import com.example.domain.model.ExportResolution
import com.example.domain.model.TemplateCatalog
import com.example.domain.model.TemplateMetadata
import com.example.domain.model.ThemeMode
import com.example.render.CardRenderEngine
import com.example.render.CardRenderPayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SavedOriginalPhotoResult(
    val localWorkingPath: String,
    val sharedStoragePath: String
)

class CardMakerRepository(
    private val context: Context,
    private val dao: AppDao,
    private val prefs: AppPreferencesRepository
) {
    val packagesFlow: Flow<List<WorkoutPackageEntity>> = dao.observeAllPackages()
    val templatesFlow: Flow<List<TemplateMetadata>> = dao.observeAllTemplates().map { list ->
        if (list.isEmpty()) {
            TemplateCatalog.allBuiltInTemplates()
        } else {
            list.map { it.toDomainModel() }
        }
    }
    val brandConfigFlow: Flow<BrandConfig> = prefs.brandConfigFlow
    val themeModeFlow: Flow<ThemeMode> = prefs.themeModeFlow
    val exportResolutionFlow: Flow<ExportResolution> = prefs.exportResolutionFlow

    private val brandAssetsDir: File
        get() = File(context.filesDir, "brand_assets").apply { mkdirs() }

    private val workingPhotosCacheDir: File
        get() = File(context.cacheDir, "working_member_photos").apply { mkdirs() }

    private val sharedCardsCacheDir: File
        get() = File(context.cacheDir, "shared_cards").apply { mkdirs() }

    suspend fun ensureInitialDataSeeded() = withContext(Dispatchers.IO) {
        val currentTemplates = dao.getAllTemplatesSnapshot()
        if (currentTemplates.size != 12 || currentTemplates.any { it.templateVersion < 4 }) {
            dao.clearAllTemplates()
            dao.insertTemplates(AppDatabase.defaultTemplates())
        }
        if (!prefs.isInitialSeedDone() || dao.countPackages() == 0) {
            if (dao.countPackages() == 0) {
                dao.insertPackages(AppDatabase.defaultAllSeededPackages())
            }
            prefs.markInitialSeedDone()
        }
    }

    // --- Workout Package Operations ---
    suspend fun saveWorkoutPackage(pkg: WorkoutPackageEntity): Long = withContext(Dispatchers.IO) {
        if (pkg.id == 0L) {
            dao.insertPackage(pkg)
        } else {
            dao.updatePackage(pkg)
            pkg.id
        }
    }

    suspend fun deleteWorkoutPackage(id: Long) = withContext(Dispatchers.IO) {
        dao.deletePackageById(id)
    }

    suspend fun resetDefaultPackagesForCategory(cardType: CardType) = withContext(Dispatchers.IO) {
        val current = dao.getAllPackagesSnapshot()
        current.filter { it.cardType == cardType.code }.forEach {
            dao.deletePackageById(it.id)
        }
        when (cardType) {
            CardType.GYM_MONTHLY -> dao.insertPackages(AppDatabase.defaultGymMonthlyPackages())
            CardType.YOGA_MONTHLY -> dao.insertPackages(AppDatabase.defaultYogaMonthlyPackages())
            CardType.GYM_PT -> Unit
        }
    }

    // --- Original Member Photo Storage in Shared Device Storage ("Pictures/89FitnessYoga/MemberPhotos/") ---
    suspend fun saveOriginalMemberPhotoFromUri(
        sourceUri: Uri,
        memberName: String
    ): Result<SavedOriginalPhotoResult> = withContext(Dispatchers.IO) {
        runCatching {
            val timestamp = System.currentTimeMillis()
            val workFile = File(workingPhotosCacheDir, "WORK_${timestamp}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(workFile).use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            } ?: error("Không thể đọc tệp ảnh từ thiết bị.")

            validateAndExportOriginalToSharedStorage(workFile, memberName)
        }
    }

    suspend fun saveOriginalMemberPhotoFromCameraFile(
        cameraFile: File,
        memberName: String
    ): Result<SavedOriginalPhotoResult> = withContext(Dispatchers.IO) {
        runCatching {
            if (!cameraFile.exists() || cameraFile.length() == 0L) {
                error("Ảnh chụp không tồn tại hoặc bị lỗi.")
            }
            val timestamp = System.currentTimeMillis()
            val workFile = File(workingPhotosCacheDir, "WORK_CAM_${timestamp}.jpg")
            cameraFile.copyTo(workFile, overwrite = true)

            validateAndExportOriginalToSharedStorage(workFile, memberName)
        }
    }

    private fun validateAndExportOriginalToSharedStorage(
        workFile: File,
        memberName: String
    ): SavedOriginalPhotoResult {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(workFile.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            workFile.delete()
            error("Định dạng ảnh không hợp lệ hoặc tệp ảnh bị hỏng.")
        }

        val safeName = sanitizeFileName(memberName.ifBlank { "HoiVien" })
        val timeTag = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "89FY_MEMBER_${safeName}_$timeTag.jpg"
        val relativeDir = "${Environment.DIRECTORY_PICTURES}/89FitnessYoga/MemberPhotos"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, relativeDir)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(workFile).use { input ->
                        input.copyTo(out)
                        out.flush()
                    }
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
        } else {
            val extDir = File(
                context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                "89FitnessYoga/MemberPhotos"
            ).apply { mkdirs() }
            workFile.copyTo(File(extDir, fileName), overwrite = true)
        }

        return SavedOriginalPhotoResult(
            localWorkingPath = workFile.absolutePath,
            sharedStoragePath = "Pictures/89FitnessYoga/MemberPhotos/$fileName"
        )
    }

    // --- V4.0 Template Management Operations (12 Templates across 4 Groups) ---
    suspend fun getTemplateByIdOrDefault(
        templateId: String,
        cardType: CardType
    ): TemplateMetadata = withContext(Dispatchers.IO) {
        val byId = dao.getTemplateById(templateId)?.toDomainModel()
        if (byId != null && byId.isCompatibleWith(cardType)) {
            return@withContext byId
        }
        val allModels = dao.getAllTemplatesSnapshot().map { it.toDomainModel() }
        val compatibleEnabled = allModels.filter { it.isCompatibleWith(cardType) && it.isEnabled }
        val chosen = compatibleEnabled.firstOrNull { it.isDefaultFor(cardType) }
            ?: compatibleEnabled.firstOrNull()
        chosen ?: TemplateCatalog.allBuiltInTemplates().first { it.isCompatibleWith(cardType) }
    }

    suspend fun setDefaultTemplateForCategory(
        cardType: CardType,
        templateId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val target = dao.getTemplateById(templateId)?.toDomainModel()
                ?: error("Không tìm thấy phôi thẻ.")
            if (!target.isCompatibleWith(cardType)) {
                error("Phôi '${target.templateName}' không tương thích với loại thẻ ${cardType.displayTitle}.")
            }
            dao.setTemplateEnabled(templateId, true)
            when (cardType) {
                CardType.GYM_MONTHLY -> dao.setDefaultTemplateForGym(templateId)
                CardType.YOGA_MONTHLY -> dao.setDefaultTemplateForYoga(templateId)
                CardType.GYM_PT -> dao.setDefaultTemplateForPt(templateId)
            }
        }
    }

    suspend fun setDefaultTemplateForAllCategories(templateId: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val target = dao.getTemplateById(templateId)?.toDomainModel()
                    ?: error("Không tìm thấy phôi thẻ.")
                CardType.entries.forEach { type ->
                    if (!target.isCompatibleWith(type)) {
                        error("Chỉ các phôi Mặc định dùng chung (Nhóm A) mới có thể đặt mặc định cho cả 3 loại thẻ.")
                    }
                }
                dao.setTemplateEnabled(templateId, true)
                dao.setDefaultTemplateForGym(templateId)
                dao.setDefaultTemplateForYoga(templateId)
                dao.setDefaultTemplateForPt(templateId)
            }
        }

    suspend fun setTemplateEnabledState(
        templateId: String,
        enabled: Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val allModels = dao.getAllTemplatesSnapshot().map { it.toDomainModel() }
            val target = allModels.firstOrNull { it.templateId == templateId }
                ?: error("Không tìm thấy phôi thẻ.")

            if (!enabled) {
                CardType.entries.filter { target.isCompatibleWith(it) }.forEach { cardType ->
                    val enabledForType = allModels.filter {
                        it.isCompatibleWith(cardType) && it.isEnabled && it.templateId != templateId
                    }
                    if (enabledForType.isEmpty()) {
                        error("Không thể tắt phôi cuối cùng đang hoạt động của loại thẻ ${cardType.displayTitle}.")
                    }
                }
            }

            dao.setTemplateEnabled(templateId, enabled)

            // If user disabled a template that was the default for any card type, promote the first remaining enabled compatible template
            if (!enabled) {
                val updatedModels = dao.getAllTemplatesSnapshot().map { it.toDomainModel() }
                CardType.entries.forEach { cardType ->
                    val compatibleEnabled = updatedModels.filter { it.isCompatibleWith(cardType) && it.isEnabled }
                    if (compatibleEnabled.isNotEmpty() && compatibleEnabled.none { it.isDefaultFor(cardType) }) {
                        val fallbackId = compatibleEnabled.first().templateId
                        when (cardType) {
                            CardType.GYM_MONTHLY -> dao.setDefaultTemplateForGym(fallbackId)
                            CardType.YOGA_MONTHLY -> dao.setDefaultTemplateForYoga(fallbackId)
                            CardType.GYM_PT -> dao.setDefaultTemplateForPt(fallbackId)
                        }
                    }
                }
            }
        }
    }

    suspend fun restoreAllBuiltInTemplates() = withContext(Dispatchers.IO) {
        dao.clearAllTemplates()
        dao.insertTemplates(AppDatabase.defaultTemplates())
    }

    // --- Export PNG ("Pictures/89FitnessYoga/"), PDF ("Downloads/89FitnessYoga/") & Direct Share ---
    suspend fun renderCardBitmap(payload: CardRenderPayload): Bitmap =
        withContext(Dispatchers.Default) {
            val template = getTemplateByIdOrDefault(payload.templateId, payload.cardType)
            val resolution = prefs.getExportResolutionSnapshot()
            CardRenderEngine.renderCardBitmap(
                context = context,
                payload = payload,
                template = template,
                targetWidth = resolution.widthPx,
                targetHeight = resolution.heightPx
            )
        }

    suspend fun exportCardToGalleryPng(payload: CardRenderPayload): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = renderCardBitmap(payload)
                try {
                    val safeName = sanitizeFileName(payload.fullName)
                    val timeTag = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                    val fileName = "89FY_${payload.cardType.code}_${safeName}_$timeTag.png"

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                            put(
                                MediaStore.Images.Media.RELATIVE_PATH,
                                "${Environment.DIRECTORY_PICTURES}/89FitnessYoga"
                            )
                            put(MediaStore.Images.Media.IS_PENDING, 1)
                        }
                        val resolver = context.contentResolver
                        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                            ?: error("Không thể khởi tạo file PNG trong bộ nhớ thiết bị.")
                        resolver.openOutputStream(uri)?.use { out ->
                            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                                error("Không thể ghi dữ liệu ảnh PNG.")
                            }
                            out.flush()
                        } ?: error("Không thể mở luồng ghi PNG.")
                        values.clear()
                        values.put(MediaStore.Images.Media.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    } else {
                        val dir = File(
                            context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                            "89FitnessYoga"
                        ).apply { mkdirs() }
                        val file = File(dir, fileName)
                        FileOutputStream(file).use { out ->
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                            out.flush()
                        }
                    }
                    "Pictures/89FitnessYoga/$fileName"
                } finally {
                    if (!bitmap.isRecycled) {
                        bitmap.recycle()
                    }
                }
            }
        }

    suspend fun exportCardToSinglePagePdf(payload: CardRenderPayload): Result<Uri> =
        withContext(Dispatchers.IO) {
            runCatching {
                val resolution = prefs.getExportResolutionSnapshot()
                val bitmap = renderCardBitmap(payload)
                val safeName = sanitizeFileName(payload.fullName)
                val timeTag = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val fileName = "89FY_${payload.cardType.code}_${safeName}_$timeTag.pdf"

                val pageWidth = resolution.widthPx
                val pageHeight = resolution.heightPx
                val pdfDocument = PdfDocument()
                try {
                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    page.canvas.drawBitmap(
                        bitmap,
                        null,
                        RectF(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat()),
                        paint
                    )
                    pdfDocument.finishPage(page)

                    val cachePdfFile = File(sharedCardsCacheDir, fileName)
                    FileOutputStream(cachePdfFile).use { out ->
                        pdfDocument.writeTo(out)
                        out.flush()
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        runCatching {
                            val values = ContentValues().apply {
                                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                                put(
                                    MediaStore.Downloads.RELATIVE_PATH,
                                    "${Environment.DIRECTORY_DOWNLOADS}/89FitnessYoga"
                                )
                                put(MediaStore.Downloads.IS_PENDING, 1)
                            }
                            val resolver = context.contentResolver
                            val dlUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            if (dlUri != null) {
                                resolver.openOutputStream(dlUri)?.use { out ->
                                    cachePdfFile.inputStream().use { input -> input.copyTo(out) }
                                }
                                values.clear()
                                values.put(MediaStore.Downloads.IS_PENDING, 0)
                                resolver.update(dlUri, values, null, null)
                            }
                        }
                    }

                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        cachePdfFile
                    )
                } finally {
                    pdfDocument.close()
                    if (!bitmap.isRecycled) {
                        bitmap.recycle()
                    }
                }
            }
        }

    suspend fun prepareShareablePngUri(payload: CardRenderPayload): Result<Uri> =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = renderCardBitmap(payload)
                try {
                    val safeName = sanitizeFileName(payload.fullName)
                    val fileName = "89FY_SHARE_${safeName}_${System.currentTimeMillis()}.png"
                    val shareFile = File(sharedCardsCacheDir, fileName)
                    FileOutputStream(shareFile).use { out ->
                        if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                            error("Không thể tạo ảnh PNG để chia sẻ.")
                        }
                        out.flush()
                    }
                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        shareFile
                    )
                } finally {
                    if (!bitmap.isRecycled) {
                        bitmap.recycle()
                    }
                }
            }
        }

    // --- Brand & App Preferences ---
    suspend fun saveBrandSettings(
        brandName: String,
        contactInfo: String,
        newLogoUri: Uri?,
        removeLogo: Boolean
    ) = withContext(Dispatchers.IO) {
        val current = prefs.getBrandConfigSnapshot()
        val finalLogoPath = when {
            removeLogo -> null
            newLogoUri != null -> {
                val logoFile = File(brandAssetsDir, "brand_logo_${System.currentTimeMillis()}.png")
                context.contentResolver.openInputStream(newLogoUri)?.use { input ->
                    FileOutputStream(logoFile).use { out -> input.copyTo(out) }
                }
                logoFile.absolutePath
            }
            else -> current.customLogoPath
        }
        prefs.saveBrandConfig(
            BrandConfig(
                brandName = brandName,
                contactInfo = contactInfo,
                customLogoPath = finalLogoPath
            )
        )
    }

    suspend fun saveThemeMode(mode: ThemeMode) = prefs.saveThemeMode(mode)
    suspend fun saveExportResolution(res: ExportResolution) = prefs.saveExportResolution(res)

    private fun sanitizeFileName(raw: String): String {
        val normalized = java.text.Normalizer.normalize(raw.trim(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace('đ', 'd')
            .replace('Đ', 'D')
        return normalized.replace(Regex("[^a-zA-Z0-9]+"), "_").trim('_').ifEmpty { "HoiVien" }
    }
}
