package com.example.domain.util

import com.example.domain.model.CardDraft
import com.example.domain.model.CardType
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object FormattersAndValidators {

    private const val DATE_PATTERN = "dd/MM/yyyy"

    private val vndSymbols = DecimalFormatSymbols(Locale.forLanguageTag("vi-VN")).apply {
        groupingSeparator = '.'
        decimalSeparator = ','
    }

    private val vndNumberFormatter = DecimalFormat("#,###", vndSymbols)

    fun formatVnd(amount: Long): String {
        val safeAmount = if (amount < 0L) 0L else amount
        return "${vndNumberFormatter.format(safeAmount)}đ"
    }

    fun formatVndDigitsOnly(amount: Long): String {
        if (amount <= 0L) return ""
        return vndNumberFormatter.format(amount)
    }

    fun parseVndInput(rawText: String): Long? {
        val digits = rawText.filter { it.isDigit() }
        if (digits.isEmpty()) return null
        return digits.toLongOrNull()
    }

    fun todayFormatted(): String {
        val sdf = SimpleDateFormat(DATE_PATTERN, Locale.getDefault())
        return sdf.format(Date())
    }

    fun calculateEndDate(startDateStr: String, durationMonths: Int): String {
        val sdf = SimpleDateFormat(DATE_PATTERN, Locale.getDefault()).apply {
            isLenient = false
        }
        val baseDate = try {
            sdf.parse(startDateStr.trim()) ?: Date()
        } catch (_: Exception) {
            Date()
        }
        val calendar = Calendar.getInstance().apply {
            time = baseDate
            add(Calendar.MONTH, durationMonths.coerceAtLeast(1))
        }
        return sdf.format(calendar.time)
    }

    fun isValidDateDdMmYyyy(dateStr: String): Boolean {
        val trimmed = dateStr.trim()
        if (!Regex("""^\d{2}/\d{2}/\d{4}$""").matches(trimmed)) return false
        val sdf = SimpleDateFormat(DATE_PATTERN, Locale.getDefault()).apply {
            isLenient = false
        }
        return try {
            sdf.parse(trimmed) != null
        } catch (_: Exception) {
            false
        }
    }

    fun parseDdMmYyyyToUtcMillis(dateStr: String): Long? {
        val sdf = SimpleDateFormat(DATE_PATTERN, Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("UTC")
            isLenient = false
        }
        return try {
            sdf.parse(dateStr.trim())?.time
        } catch (_: Exception) {
            null
        }
    }

    fun formatUtcMillisToDdMmYyyy(utcMillis: Long): String {
        val sdf = SimpleDateFormat(DATE_PATTERN, Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        return sdf.format(Date(utcMillis))
    }

    fun validateMemberInfoStep(draft: CardDraft): String? {
        if (draft.fullName.isBlank()) {
            return "Vui lòng nhập họ và tên hội viên."
        }
        val cleanPhone = draft.phoneNumber.trim()
        if (cleanPhone.isBlank()) {
            return "Vui lòng nhập số điện thoại hội viên."
        }
        if (cleanPhone.count { it.isDigit() } < 8) {
            return "Số điện thoại phải có ít nhất 8 chữ số."
        }
        val price = parseVndInput(draft.priceVndText)
        if (price == null || price < 0L) {
            return "Vui lòng nhập giá tiền hợp lệ (VNĐ)."
        }

        when (draft.cardType) {
            CardType.GYM_MONTHLY, CardType.YOGA_MONTHLY -> {
                val months = draft.durationMonthsText.trim().toIntOrNull()
                if (months == null || months <= 0) {
                    return "Vui lòng nhập thời hạn số tháng lớn hơn 0."
                }
                if (!isValidDateDdMmYyyy(draft.startDate)) {
                    return "Ngày bắt đầu không hợp lệ (định dạng chuẩn DD/MM/YYYY)."
                }
                if (!isValidDateDdMmYyyy(draft.endDate)) {
                    return "Ngày hết hạn không hợp lệ (định dạng chuẩn DD/MM/YYYY)."
                }
                val startMillis = parseDdMmYyyyToUtcMillis(draft.startDate) ?: 0L
                val endMillis = parseDdMmYyyyToUtcMillis(draft.endDate) ?: 0L
                if (endMillis < startMillis) {
                    return "Ngày hết hạn phải lớn hơn hoặc bằng ngày bắt đầu."
                }
            }
            CardType.GYM_PT -> {
                val sessions = draft.totalPtSessions.trim().toIntOrNull()
                if (sessions == null || sessions <= 0) {
                    return "Vui lòng nhập tổng số buổi PT lớn hơn 0."
                }
            }
        }
        return null
    }

    fun validatePhotoStep(draft: CardDraft): String? {
        if (draft.originalPhotoPath.isNullOrBlank()) {
            return "Vui lòng chụp hoặc chọn ảnh hội viên trước khi xem trước thẻ."
        }
        return null
    }
}
