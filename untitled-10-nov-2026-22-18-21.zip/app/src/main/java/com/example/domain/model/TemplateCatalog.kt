package com.example.domain.model

object TemplateCatalog {

    fun allBuiltInTemplates(): List<TemplateMetadata> =
        universalTemplates() + gymTemplates() + yogaTemplates() + ptTemplates()

    fun getInitialDefaultTemplateIdForCategory(cardType: CardType): String = when (cardType) {
        CardType.GYM_MONTHLY -> "g1_athletic_performance"
        CardType.YOGA_MONTHLY -> "y1_zen_minimal"
        CardType.GYM_PT -> "p1_elite_personal_trainer"
    }

    fun getCompatibleTemplatesForCardType(
        allTemplates: List<TemplateMetadata>,
        cardType: CardType,
        onlyEnabled: Boolean = true
    ): List<TemplateMetadata> {
        val filtered = allTemplates.filter { tpl ->
            tpl.isCompatibleWith(cardType) && (!onlyEnabled || tpl.isEnabled)
        }
        return if (filtered.isNotEmpty()) {
            filtered
        } else {
            allBuiltInTemplates().filter { it.isCompatibleWith(cardType) }
        }
    }

    // =========================================================================
    // NHÓM A – 3 PHÔI MẶC ĐỊNH DÙNG CHUNG (UNIVERSAL: GYM • YOGA • PT)
    // =========================================================================
    fun universalTemplates(): List<TemplateMetadata> = listOf(
        // A1 – Universal Premium
        TemplateMetadata(
            templateId = "a1_universal_premium",
            category = TemplateCategory.UNIVERSAL,
            templateName = "A1 – Universal Premium",
            styleName = "Cao cấp • Hiện đại • Tinh tế (Dùng chung)",
            backgroundColorHex = "#0F141C",
            secondaryColorHex = "#1E2633",
            accentColorHex = "#D4AF37",
            textPrimaryHex = "#FAF8F5",
            textSecondaryHex = "#CBD5E1",
            priceHighlightHex = "#FDE047",
            headerStyle = HeaderLayoutStyle.STANDARD_SPLIT,
            infoBoxStyle = InfoBoxStyle.FILLED_GLASS,
            artworkPattern = ArtworkPatternStyle.A1_UNIVERSAL_PREMIUM,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.032f,
                shape = PhotoFrameShape.ROUNDED_RECT
            )
        ),

        // A2 – Universal Modern Minimal
        TemplateMetadata(
            templateId = "a2_universal_minimal",
            category = TemplateCategory.UNIVERSAL,
            templateName = "A2 – Universal Modern Minimal",
            styleName = "Tối giản hiện đại • Không gian thoáng (Dùng chung)",
            backgroundColorHex = "#F8FAFC",
            secondaryColorHex = "#E2E8F0",
            accentColorHex = "#2563EB",
            textPrimaryHex = "#0F172A",
            textSecondaryHex = "#475569",
            priceHighlightHex = "#DC2626",
            headerStyle = HeaderLayoutStyle.MINIMAL_CLEAN,
            infoBoxStyle = InfoBoxStyle.MINIMAL_HAIRLINE,
            artworkPattern = ArtworkPatternStyle.A2_UNIVERSAL_MINIMAL,
            contentLeftRatio = 0.055f,
            contentRightRatio = 0.635f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.675f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.025f,
                shape = PhotoFrameShape.ROUNDED_RECT
            )
        ),

        // A3 – Universal Futuristic
        TemplateMetadata(
            templateId = "a3_universal_futuristic",
            category = TemplateCategory.UNIVERSAL,
            templateName = "A3 – Universal Futuristic",
            styleName = "Công nghệ tương lai • Đường nét kỹ thuật (Dùng chung)",
            backgroundColorHex = "#080D1A",
            secondaryColorHex = "#111C33",
            accentColorHex = "#06B6D4",
            textPrimaryHex = "#F0F9FF",
            textSecondaryHex = "#94A3B8",
            priceHighlightHex = "#38BDF8",
            headerStyle = HeaderLayoutStyle.TECH_HUD,
            infoBoxStyle = InfoBoxStyle.OUTLINE_SHARP,
            artworkPattern = ArtworkPatternStyle.A3_UNIVERSAL_FUTURISTIC,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.03f,
                shape = PhotoFrameShape.CHAMFERED_OCTAGON
            )
        )
    )

    // =========================================================================
    // NHÓM B – 3 PHÔI GYM MONTHLY CHUYÊN BIỆT
    // =========================================================================
    fun gymTemplates(): List<TemplateMetadata> = listOf(
        // G1 – Athletic Performance
        TemplateMetadata(
            templateId = "g1_athletic_performance",
            category = TemplateCategory.GYM,
            templateName = "G1 – Athletic Performance",
            styleName = "Thể thao chuyên nghiệp • Năng lượng mạnh mẽ",
            backgroundColorHex = "#111318",
            secondaryColorHex = "#1E222D",
            accentColorHex = "#E11D48",
            textPrimaryHex = "#FFFFFF",
            textSecondaryHex = "#CBD5E1",
            priceHighlightHex = "#FBBF24",
            headerStyle = HeaderLayoutStyle.STANDARD_SPLIT,
            infoBoxStyle = InfoBoxStyle.FILLED_GLASS,
            artworkPattern = ArtworkPatternStyle.G1_ATHLETIC_PERFORMANCE,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.03f,
                shape = PhotoFrameShape.CUT_CORNER
            ),
            defaultForCardTypes = setOf(CardType.GYM_MONTHLY)
        ),

        // G2 – Luxury Black & Gold
        TemplateMetadata(
            templateId = "g2_luxury_black_gold",
            category = TemplateCategory.GYM,
            templateName = "G2 – Luxury Black & Gold",
            styleName = "Nền đen cao cấp • Điểm nhấn vàng kim sang trọng",
            backgroundColorHex = "#09090B",
            secondaryColorHex = "#1C1917",
            accentColorHex = "#EAB308",
            textPrimaryHex = "#FAF5E8",
            textSecondaryHex = "#D6D3D1",
            priceHighlightHex = "#FDE047",
            headerStyle = HeaderLayoutStyle.CENTERED_CREST,
            infoBoxStyle = InfoBoxStyle.OUTLINE_SHARP,
            artworkPattern = ArtworkPatternStyle.G2_LUXURY_BLACK_GOLD,
            contentLeftRatio = 0.055f,
            contentRightRatio = 0.635f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.675f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.135f,
                shape = PhotoFrameShape.ARCH_TOP
            )
        ),

        // G3 – Bold Sport Editorial
        TemplateMetadata(
            templateId = "g3_bold_sport_editorial",
            category = TemplateCategory.GYM,
            templateName = "G3 – Bold Sport Editorial",
            styleName = "Tạp chí thể thao hiện đại • Bố cục bất đối xứng",
            backgroundColorHex = "#18181B",
            secondaryColorHex = "#27272A",
            accentColorHex = "#F97316",
            textPrimaryHex = "#FAFAFA",
            textSecondaryHex = "#D4D4D8",
            priceHighlightHex = "#FB923C",
            headerStyle = HeaderLayoutStyle.EDITORIAL_SIDEBAR,
            infoBoxStyle = InfoBoxStyle.EDITORIAL_COLUMN,
            artworkPattern = ArtworkPatternStyle.G3_BOLD_SPORT_EDITORIAL,
            contentLeftRatio = 0.095f,
            contentRightRatio = 0.645f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.68f,
                yRatio = 0.215f,
                widthRatio = 0.265f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.03f,
                shape = PhotoFrameShape.CUT_CORNER
            )
        )
    )

    // =========================================================================
    // NHÓM C – 3 PHÔI YOGA MONTHLY CHUYÊN BIỆT
    // =========================================================================
    fun yogaTemplates(): List<TemplateMetadata> = listOf(
        // Y1 – Zen Minimal
        TemplateMetadata(
            templateId = "y1_zen_minimal",
            category = TemplateCategory.YOGA,
            templateName = "Y1 – Zen Minimal",
            styleName = "Tối giản thư giãn • Cân bằng & Khoảng trắng",
            backgroundColorHex = "#FAF7F2",
            secondaryColorHex = "#EFECE6",
            accentColorHex = "#2E6F40",
            textPrimaryHex = "#1C2E24",
            textSecondaryHex = "#4E6758",
            priceHighlightHex = "#1B4D2E",
            headerStyle = HeaderLayoutStyle.MINIMAL_CLEAN,
            infoBoxStyle = InfoBoxStyle.MINIMAL_HAIRLINE,
            artworkPattern = ArtworkPatternStyle.Y1_ZEN_MINIMAL,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.135f,
                shape = PhotoFrameShape.ARCH_TOP
            ),
            defaultForCardTypes = setOf(CardType.YOGA_MONTHLY)
        ),

        // Y2 – Botanical Elegance
        TemplateMetadata(
            templateId = "y2_botanical_elegance",
            category = TemplateCategory.YOGA,
            templateName = "Y2 – Botanical Elegance",
            styleName = "Cảm hứng thảo mộc • Đường cong hữu cơ thanh lịch",
            backgroundColorHex = "#0D2B22",
            secondaryColorHex = "#143D30",
            accentColorHex = "#6EE7B7",
            textPrimaryHex = "#F0FDF4",
            textSecondaryHex = "#A7F3D0",
            priceHighlightHex = "#FCD34D",
            headerStyle = HeaderLayoutStyle.STANDARD_SPLIT,
            infoBoxStyle = InfoBoxStyle.PILL_CARD,
            artworkPattern = ArtworkPatternStyle.Y2_BOTANICAL_ELEGANCE,
            contentLeftRatio = 0.055f,
            contentRightRatio = 0.635f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.675f,
                yRatio = 0.215f,
                widthRatio = 0.265f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.132f,
                shape = PhotoFrameShape.OVAL_PILL
            )
        ),

        // Y3 – Luxury Wellness
        TemplateMetadata(
            templateId = "y3_luxury_wellness",
            category = TemplateCategory.YOGA,
            templateName = "Y3 – Luxury Wellness",
            styleName = "Wellness cao cấp • Mềm mại & Tinh tế",
            backgroundColorHex = "#23192D",
            secondaryColorHex = "#352544",
            accentColorHex = "#F4B8C5",
            textPrimaryHex = "#FDF8FA",
            textSecondaryHex = "#E9D5FF",
            priceHighlightHex = "#FDE68A",
            headerStyle = HeaderLayoutStyle.CENTERED_CREST,
            infoBoxStyle = InfoBoxStyle.PILL_CARD,
            artworkPattern = ArtworkPatternStyle.Y3_LUXURY_WELLNESS,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.23f,
                widthRatio = 0.265f,
                heightRatio = 0.52f,
                cornerRadiusRatio = 0.13f,
                shape = PhotoFrameShape.CIRCLE
            )
        )
    )

    // =========================================================================
    // NHÓM D – 3 PHÔI GYM PT CHUYÊN BIỆT
    // =========================================================================
    fun ptTemplates(): List<TemplateMetadata> = listOf(
        // P1 – Elite Personal Trainer
        TemplateMetadata(
            templateId = "p1_elite_personal_trainer",
            category = TemplateCategory.PT,
            templateName = "P1 – Elite Personal Trainer",
            styleName = "Huấn luyện viên cá nhân cao cấp • Nhấn mạnh số buổi PT",
            backgroundColorHex = "#0F1115",
            secondaryColorHex = "#1C1F26",
            accentColorHex = "#F59E0B",
            textPrimaryHex = "#FFFFFF",
            textSecondaryHex = "#D1D5DB",
            priceHighlightHex = "#FDE047",
            headerStyle = HeaderLayoutStyle.STANDARD_SPLIT,
            infoBoxStyle = InfoBoxStyle.FILLED_GLASS,
            artworkPattern = ArtworkPatternStyle.P1_ELITE_PERSONAL_TRAINER,
            contentLeftRatio = 0.365f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.055f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.03f,
                shape = PhotoFrameShape.CUT_CORNER
            ),
            defaultForCardTypes = setOf(CardType.GYM_PT)
        ),

        // P2 – Performance Lab
        TemplateMetadata(
            templateId = "p2_performance_lab",
            category = TemplateCategory.PT,
            templateName = "P2 – Performance Lab",
            styleName = "Phòng nghiên cứu hiệu suất • Đường nét kỹ thuật chính xác",
            backgroundColorHex = "#091526",
            secondaryColorHex = "#102340",
            accentColorHex = "#38BDF8",
            textPrimaryHex = "#F8FAFC",
            textSecondaryHex = "#94A3B8",
            priceHighlightHex = "#4ADE80",
            headerStyle = HeaderLayoutStyle.TECH_HUD,
            infoBoxStyle = InfoBoxStyle.OUTLINE_SHARP,
            artworkPattern = ArtworkPatternStyle.P2_PERFORMANCE_LAB,
            contentLeftRatio = 0.055f,
            contentRightRatio = 0.635f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.675f,
                yRatio = 0.215f,
                widthRatio = 0.27f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.025f,
                shape = PhotoFrameShape.ROUNDED_RECT
            )
        ),

        // P3 – Black Titanium
        TemplateMetadata(
            templateId = "p3_black_titanium",
            category = TemplateCategory.PT,
            templateName = "P3 – Black Titanium",
            styleName = "Kim loại đen xước Titanium • Điểm nhấn Đỏ & Bạc độc quyền",
            backgroundColorHex = "#141619",
            secondaryColorHex = "#22262C",
            accentColorHex = "#EF4444",
            textPrimaryHex = "#F8FAFC",
            textSecondaryHex = "#CBD5E1",
            priceHighlightHex = "#F87171",
            headerStyle = HeaderLayoutStyle.EDITORIAL_SIDEBAR,
            infoBoxStyle = InfoBoxStyle.EDITORIAL_COLUMN,
            artworkPattern = ArtworkPatternStyle.P3_BLACK_TITANIUM,
            contentLeftRatio = 0.375f,
            contentRightRatio = 0.945f,
            contentTopRatio = 0.235f,
            imageSlot = ImageSlotSpec(
                xRatio = 0.085f,
                yRatio = 0.215f,
                widthRatio = 0.26f,
                heightRatio = 0.64f,
                cornerRadiusRatio = 0.02f,
                shape = PhotoFrameShape.CHAMFERED_OCTAGON
            )
        )
    )
}
