package com.example.domain.model

enum class CardType(
    val code: String,
    val displayTitle: String,
    val shortCardLabelVi: String,
    val subtitleVi: String
) {
    GYM_MONTHLY(
        code = "GYM_MONTHLY",
        displayTitle = "Gym tháng",
        shortCardLabelVi = "Thẻ Gym",
        subtitleVi = "Thẻ hội viên Gym theo tháng (Nam / Nữ / Trẻ em)"
    ),
    GYM_PT(
        code = "GYM_PT",
        displayTitle = "Gym PT",
        shortCardLabelVi = "Thẻ PT",
        subtitleVi = "Thẻ tập Huấn luyện viên cá nhân theo tổng số buổi"
    ),
    YOGA_MONTHLY(
        code = "YOGA_MONTHLY",
        displayTitle = "Yoga tháng",
        shortCardLabelVi = "Thẻ Yoga",
        subtitleVi = "Thẻ hội viên Yoga theo tháng"
    );

    companion object {
        fun fromCode(code: String?): CardType =
            entries.firstOrNull { it.code == code } ?: GYM_MONTHLY
    }
}

enum class TemplateCategory(
    val code: String,
    val tabLabelVi: String,
    val fullGroupTitleVi: String
) {
    UNIVERSAL(
        code = "UNIVERSAL",
        tabLabelVi = "Mặc định",
        fullGroupTitleVi = "Nhóm A – Phôi mặc định dùng chung (Gym • Yoga • PT)"
    ),
    GYM(
        code = "GYM",
        tabLabelVi = "Gym",
        fullGroupTitleVi = "Nhóm B – Phôi chuyên biệt Gym tháng"
    ),
    YOGA(
        code = "YOGA",
        tabLabelVi = "Yoga",
        fullGroupTitleVi = "Nhóm C – Phôi chuyên biệt Yoga tháng"
    ),
    PT(
        code = "PT",
        tabLabelVi = "PT",
        fullGroupTitleVi = "Nhóm D – Phôi chuyên biệt Gym PT"
    );

    fun isCompatibleWith(cardType: CardType): Boolean = when (this) {
        UNIVERSAL -> true
        GYM -> cardType == CardType.GYM_MONTHLY
        YOGA -> cardType == CardType.YOGA_MONTHLY
        PT -> cardType == CardType.GYM_PT
    }

    fun primaryPreviewCardType(): CardType = when (this) {
        UNIVERSAL -> CardType.GYM_MONTHLY
        GYM -> CardType.GYM_MONTHLY
        YOGA -> CardType.YOGA_MONTHLY
        PT -> CardType.GYM_PT
    }

    companion object {
        fun fromCode(code: String?): TemplateCategory =
            entries.firstOrNull { it.code == code } ?: UNIVERSAL

        fun specificCategoryFor(cardType: CardType): TemplateCategory = when (cardType) {
            CardType.GYM_MONTHLY -> GYM
            CardType.YOGA_MONTHLY -> YOGA
            CardType.GYM_PT -> PT
        }
    }
}

enum class TargetGroup(
    val code: String,
    val displayLabel: String
) {
    NAM("NAM", "Nam"),
    NU("NU", "Nữ"),
    TRE_EM("TRE_EM", "Trẻ em");

    companion object {
        fun fromCode(code: String?): TargetGroup? =
            entries.firstOrNull { it.code == code }
    }
}

enum class ThemeMode(
    val code: String,
    val displayLabel: String
) {
    LIGHT("LIGHT", "Light Mode (Sáng)"),
    DARK("DARK", "Dark Mode (Tối)"),
    SYSTEM("SYSTEM", "System Default (Mặc định hệ thống)");

    companion object {
        fun fromCode(code: String?): ThemeMode =
            entries.firstOrNull { it.code == code } ?: SYSTEM
    }
}

enum class ExportResolution(
    val code: String,
    val scaleLabel: String,
    val widthPx: Int,
    val heightPx: Int,
    val displayLabel: String
) {
    RES_1X("RES_1X", "1×", 1200, 750, "1× Tiêu chuẩn (1200 × 750 px • Tỷ lệ 8:5)"),
    RES_1_5X("RES_1_5X", "1.5×", 1800, 1125, "1.5× Sắc nét cao (1800 × 1125 px • Tỷ lệ 8:5)"),
    RES_2X("RES_2X", "2×", 2400, 1500, "2× Siêu nét 2X (2400 × 1500 px • Tỷ lệ 8:5)");

    companion object {
        fun fromCode(code: String?): ExportResolution = when (code) {
            "RES_1X", "STANDARD_HD" -> RES_1X
            "RES_1_5X" -> RES_1_5X
            "RES_2X", "ULTRA_HD" -> RES_2X
            else -> RES_1X
        }
    }
}

enum class PhotoFrameShape(val code: String, val labelVi: String) {
    ROUNDED_RECT("ROUNDED_RECT", "Chữ nhật bo góc"),
    ARCH_TOP("ARCH_TOP", "Khung vòm nghệ thuật"),
    CIRCLE("CIRCLE", "Khung tròn huy chương"),
    CHAMFERED_OCTAGON("CHAMFERED_OCTAGON", "Khung bát giác công nghệ"),
    OVAL_PILL("OVAL_PILL", "Khung viên nang Oval"),
    CUT_CORNER("CUT_CORNER", "Khung vát chéo thể thao");

    companion object {
        fun fromCode(code: String?): PhotoFrameShape =
            entries.firstOrNull { it.code == code } ?: ROUNDED_RECT
    }
}

enum class HeaderLayoutStyle(val code: String, val labelVi: String) {
    STANDARD_SPLIT("STANDARD_SPLIT", "Tiêu chuẩn cân đối"),
    CENTERED_CREST("CENTERED_CREST", "Huy hiệu trung tâm"),
    EDITORIAL_SIDEBAR("EDITORIAL_SIDEBAR", "Dải dọc tạp chí"),
    MINIMAL_CLEAN("MINIMAL_CLEAN", "Tối giản thanh lịch"),
    TECH_HUD("TECH_HUD", "Kỹ thuật hiện đại");

    companion object {
        fun fromCode(code: String?): HeaderLayoutStyle =
            entries.firstOrNull { it.code == code } ?: STANDARD_SPLIT
    }
}

enum class InfoBoxStyle(val code: String, val labelVi: String) {
    FILLED_GLASS("FILLED_GLASS", "Hộp kính mờ"),
    OUTLINE_SHARP("OUTLINE_SHARP", "Viền sắc cạnh"),
    MINIMAL_HAIRLINE("MINIMAL_HAIRLINE", "Đường mảnh tối giản"),
    PILL_CARD("PILL_CARD", "Thẻ bo tròn mềm mại"),
    EDITORIAL_COLUMN("EDITORIAL_COLUMN", "Thanh nhấn dọc tạp chí");

    companion object {
        fun fromCode(code: String?): InfoBoxStyle =
            entries.firstOrNull { it.code == code } ?: FILLED_GLASS
    }
}

enum class CardIconType(val code: String) {
    USER("USER"),
    GROUP("GROUP"),
    PHONE("PHONE"),
    CALENDAR("CALENDAR"),
    CALENDAR_CHECK("CALENDAR_CHECK"),
    CLOCK("CLOCK"),
    DUMBBELL("DUMBBELL"),
    WALLET("WALLET"),
    MEMBERSHIP_CARD("MEMBERSHIP_CARD")
}

enum class ArtworkPatternStyle(val code: String) {
    A1_UNIVERSAL_PREMIUM("A1_UNIVERSAL_PREMIUM"),
    A2_UNIVERSAL_MINIMAL("A2_UNIVERSAL_MINIMAL"),
    A3_UNIVERSAL_FUTURISTIC("A3_UNIVERSAL_FUTURISTIC"),
    G1_ATHLETIC_PERFORMANCE("G1_ATHLETIC_PERFORMANCE"),
    G2_LUXURY_BLACK_GOLD("G2_LUXURY_BLACK_GOLD"),
    G3_BOLD_SPORT_EDITORIAL("G3_BOLD_SPORT_EDITORIAL"),
    Y1_ZEN_MINIMAL("Y1_ZEN_MINIMAL"),
    Y2_BOTANICAL_ELEGANCE("Y2_BOTANICAL_ELEGANCE"),
    Y3_LUXURY_WELLNESS("Y3_LUXURY_WELLNESS"),
    P1_ELITE_PERSONAL_TRAINER("P1_ELITE_PERSONAL_TRAINER"),
    P2_PERFORMANCE_LAB("P2_PERFORMANCE_LAB"),
    P3_BLACK_TITANIUM("P3_BLACK_TITANIUM");

    companion object {
        fun fromCode(code: String?): ArtworkPatternStyle =
            entries.firstOrNull { it.code == code } ?: A1_UNIVERSAL_PREMIUM
    }
}

data class BrandConfig(
    val brandName: String = "89 FITNESS & YOGA",
    val contactInfo: String = "Hội viên chính thức • 89 FITNESS & YOGA",
    val customLogoPath: String? = null
)

data class ImageSlotSpec(
    val xRatio: Float = 0.055f,
    val yRatio: Float = 0.22f,
    val widthRatio: Float = 0.27f,
    val heightRatio: Float = 0.64f,
    val cornerRadiusRatio: Float = 0.03f,
    val shape: PhotoFrameShape = PhotoFrameShape.ROUNDED_RECT
) {
    val aspectRatio: Float
        get() = ((widthRatio * 1200f) / (heightRatio * 750f)).coerceIn(0.45f, 1.5f)
}

data class LogoPositionSpec(
    val xRatio: Float = 0.053f,
    val yRatio: Float = 0.050f,
    val sizeRatio: Float = 0.062f
)

data class IconPositionSpec(
    val fieldKey: String,
    val iconType: CardIconType,
    val sizePx: Float = 22f
)

data class TemplateColorPalette(
    val backgroundHex: String,
    val secondaryHex: String,
    val accentHex: String,
    val textPrimaryHex: String,
    val textSecondaryHex: String,
    val priceHighlightHex: String
)

data class TemplateTypographySpec(
    val headingFontFamily: String = "Montserrat",
    val bodyFontFamily: String = "BeVietnamPro",
    val memberNameSizePx: Float = 40f,
    val fieldLabelSizePx: Float = 15f,
    val fieldValueSizePx: Float = 27f
)

data class TextFieldSpec(
    val fieldKey: String,
    val labelVi: String,
    val iconType: CardIconType,
    val xRatio: Float,
    val yRatio: Float,
    val fontFamily: String = "Montserrat",
    val fontSizePx: Float = 32f,
    val minFontSizePx: Float = 20f,
    val textAlign: String = "LEFT",
    val textColorHex: String = "#FFFFFF",
    val maxWidthRatio: Float = 0.56f,
    val overflowBehavior: String = "AUTO_SHRINK_THEN_ELLIPSIZE",
    val isVisible: Boolean = true
)

data class TemplateMetadata(
    val templateId: String,
    val templateVersion: Int = 4,
    val category: TemplateCategory,
    val templateName: String,
    val styleName: String,
    val canvasWidth: Int = 1200,
    val canvasHeight: Int = 750,
    val aspectRatio: Float = 1.6f, // 8:5
    val backgroundColorHex: String,
    val secondaryColorHex: String,
    val accentColorHex: String,
    val textPrimaryHex: String,
    val textSecondaryHex: String,
    val priceHighlightHex: String,
    val headerStyle: HeaderLayoutStyle = HeaderLayoutStyle.STANDARD_SPLIT,
    val infoBoxStyle: InfoBoxStyle = InfoBoxStyle.FILLED_GLASS,
    val artworkPattern: ArtworkPatternStyle = ArtworkPatternStyle.A1_UNIVERSAL_PREMIUM,
    val contentLeftRatio: Float = 0.365f,
    val contentRightRatio: Float = 0.95f,
    val contentTopRatio: Float = 0.24f,
    val imageSlot: ImageSlotSpec = ImageSlotSpec(),
    val logoPosition: LogoPositionSpec = LogoPositionSpec(),
    val backgroundAsset: String = artworkPattern.code,
    val artworkAssets: List<String> = listOf(artworkPattern.code, headerStyle.code, infoBoxStyle.code),
    val alignment: String = "LEFT",
    val spacing: Float = 18f,
    val overflowRules: String = "AUTO_SHRINK_THEN_ELLIPSIZE",
    val previewThumbnail: String = "procedural_8x5_${templateId}",
    val textFields: List<TextFieldSpec> = buildDefaultTextFields(
        leftRatio = contentLeftRatio,
        maxWidthRatio = (contentRightRatio - contentLeftRatio).coerceAtLeast(0.4f),
        topRatio = contentTopRatio,
        primaryHex = textPrimaryHex,
        secondaryHex = textSecondaryHex,
        priceHex = priceHighlightHex
    ),
    val iconPositions: List<IconPositionSpec> = defaultIconPositions(),
    val typography: TemplateTypographySpec = TemplateTypographySpec(),
    val isEnabled: Boolean = true,
    val defaultForCardTypes: Set<CardType> = emptySet()
) {
    val styleLabel: String
        get() = styleName

    val photoFrame: ImageSlotSpec
        get() = imageSlot

    val textFieldPositions: List<TextFieldSpec>
        get() = textFields

    val colorPalette: TemplateColorPalette
        get() = TemplateColorPalette(
            backgroundHex = backgroundColorHex,
            secondaryHex = secondaryColorHex,
            accentHex = accentColorHex,
            textPrimaryHex = textPrimaryHex,
            textSecondaryHex = textSecondaryHex,
            priceHighlightHex = priceHighlightHex
        )

    fun isCompatibleWith(cardType: CardType): Boolean = category.isCompatibleWith(cardType)

    fun isDefaultFor(cardType: CardType): Boolean = cardType in defaultForCardTypes

    val isDefault: Boolean
        get() = defaultForCardTypes.isNotEmpty()
}

fun defaultIconPositions(): List<IconPositionSpec> = listOf(
    IconPositionSpec("cardType", CardIconType.MEMBERSHIP_CARD, 20f),
    IconPositionSpec("fullName", CardIconType.USER, 22f),
    IconPositionSpec("targetGroup", CardIconType.GROUP, 20f),
    IconPositionSpec("phoneNumber", CardIconType.PHONE, 20f),
    IconPositionSpec("startDate", CardIconType.CALENDAR, 20f),
    IconPositionSpec("endDate", CardIconType.CALENDAR_CHECK, 20f),
    IconPositionSpec("durationMonths", CardIconType.CLOCK, 20f),
    IconPositionSpec("totalPtSessions", CardIconType.DUMBBELL, 22f),
    IconPositionSpec("priceVnd", CardIconType.WALLET, 22f)
)

fun buildDefaultTextFields(
    leftRatio: Float,
    maxWidthRatio: Float,
    topRatio: Float,
    primaryHex: String,
    secondaryHex: String,
    priceHex: String
): List<TextFieldSpec> = listOf(
    TextFieldSpec(
        fieldKey = "fullName",
        labelVi = "Họ và tên hội viên",
        iconType = CardIconType.USER,
        xRatio = leftRatio,
        yRatio = topRatio,
        fontFamily = "Montserrat",
        fontSizePx = 40f,
        minFontSizePx = 22f,
        textColorHex = primaryHex,
        maxWidthRatio = maxWidthRatio
    ),
    TextFieldSpec(
        fieldKey = "phoneNumber",
        labelVi = "Số điện thoại",
        iconType = CardIconType.PHONE,
        xRatio = leftRatio,
        yRatio = topRatio + 0.14f,
        fontFamily = "BeVietnamPro",
        fontSizePx = 28f,
        minFontSizePx = 19f,
        textColorHex = secondaryHex,
        maxWidthRatio = maxWidthRatio
    ),
    TextFieldSpec(
        fieldKey = "targetGroup",
        labelVi = "Giới tính / Nhóm",
        iconType = CardIconType.GROUP,
        xRatio = leftRatio,
        yRatio = topRatio + 0.25f,
        fontFamily = "BeVietnamPro",
        fontSizePx = 27f,
        minFontSizePx = 19f,
        textColorHex = primaryHex,
        maxWidthRatio = maxWidthRatio
    ),
    TextFieldSpec(
        fieldKey = "validityDates",
        labelVi = "Ngày bắt đầu & hết hạn",
        iconType = CardIconType.CALENDAR,
        xRatio = leftRatio,
        yRatio = topRatio + 0.36f,
        fontFamily = "BeVietnamPro",
        fontSizePx = 27f,
        minFontSizePx = 19f,
        textColorHex = primaryHex,
        maxWidthRatio = maxWidthRatio
    ),
    TextFieldSpec(
        fieldKey = "totalPtSessions",
        labelVi = "Tổng số buổi PT",
        iconType = CardIconType.DUMBBELL,
        xRatio = leftRatio,
        yRatio = topRatio + 0.36f,
        fontFamily = "Montserrat",
        fontSizePx = 32f,
        minFontSizePx = 20f,
        textColorHex = primaryHex,
        maxWidthRatio = maxWidthRatio
    ),
    TextFieldSpec(
        fieldKey = "priceVnd",
        labelVi = "Giá tiền",
        iconType = CardIconType.WALLET,
        xRatio = leftRatio,
        yRatio = topRatio + 0.50f,
        fontFamily = "Montserrat",
        fontSizePx = 34f,
        minFontSizePx = 21f,
        textColorHex = priceHex,
        maxWidthRatio = maxWidthRatio
    )
)

data class CardDraft(
    val cardType: CardType = CardType.GYM_MONTHLY,
    val selectedTemplateId: String = "g1_athletic_performance",
    val targetGroup: TargetGroup = TargetGroup.NAM,
    val selectedPackageId: Long? = null,
    val packageName: String = "1 tháng",
    val durationMonthsText: String = "1",
    val fullName: String = "",
    val phoneNumber: String = "",
    val startDate: String = "",
    val endDate: String = "",
    val totalPtSessions: String = "",
    val priceVndText: String = "",
    val originalPhotoPath: String? = null,
    val sharedMediaStorePath: String? = null,
    val cropScale: Float = 1f,
    val cropOffsetX: Float = 0f,
    val cropOffsetY: Float = 0f
)
