package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.WorkoutPackageEntity
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardType
import com.example.domain.model.ExportResolution
import com.example.domain.model.TemplateMetadata
import com.example.domain.model.ThemeMode
import java.io.File

private enum class SettingsSubPage {
    MAIN_LIST,
    PACKAGE_CONFIG,
    TEMPLATE_CONFIG
}

@Composable
fun SettingsTabScreen(
    brandConfig: BrandConfig,
    packages: List<WorkoutPackageEntity>,
    templates: List<TemplateMetadata>,
    themeMode: ThemeMode,
    exportResolution: ExportResolution,
    onSaveBrandSettings: (String, String, Uri?, Boolean) -> Unit,
    onSavePackage: (WorkoutPackageEntity) -> Unit,
    onDeletePackage: (WorkoutPackageEntity) -> Unit,
    onResetDefaultPackagesForCategory: (CardType) -> Unit,
    onSetDefaultTemplate: (CardType, String) -> Unit,
    onSetDefaultTemplateForAll: (String) -> Unit,
    onToggleTemplateEnabled: (TemplateMetadata, Boolean) -> Unit,
    onRestoreAllTemplates: () -> Unit,
    onSelectThemeMode: (ThemeMode) -> Unit,
    onSelectExportResolution: (ExportResolution) -> Unit
) {
    var subPage by remember { mutableStateOf(SettingsSubPage.MAIN_LIST) }

    var showBrandDialog by remember { mutableStateOf(false) }
    var showExportConfigDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    when (subPage) {
        SettingsSubPage.PACKAGE_CONFIG -> {
            PackageConfigSubScreen(
                packages = packages,
                onBack = { subPage = SettingsSubPage.MAIN_LIST },
                onSavePackage = onSavePackage,
                onDeletePackage = onDeletePackage,
                onResetDefaultPackagesForCategory = onResetDefaultPackagesForCategory
            )
        }
        SettingsSubPage.TEMPLATE_CONFIG -> {
            TemplateConfigSubScreen(
                templates = templates,
                brandConfig = brandConfig,
                onBack = { subPage = SettingsSubPage.MAIN_LIST },
                onSetDefaultTemplate = onSetDefaultTemplate,
                onSetDefaultTemplateForAll = onSetDefaultTemplateForAll,
                onToggleTemplateEnabled = onToggleTemplateEnabled,
                onRestoreAllTemplates = onRestoreAllTemplates
            )
        }
        SettingsSubPage.MAIN_LIST -> {
            val enabledTemplatesCount = templates.count { it.isEnabled }
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "CÀI ĐẶT HỆ THỐNG V4.0",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Quản lý thương hiệu, gói tập, hệ thống 12 phôi thẻ và cấu hình xuất",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // 1. Nhận diện phòng tập
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.Business,
                        title = "1. Nhận diện phòng tập",
                        subtitle = "${brandConfig.brandName} • Logo & Liên hệ",
                        testTag = "settings_group_brand",
                        onClick = { showBrandDialog = true }
                    )
                }

                // 2. Cấu hình gói tập
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.Inventory2,
                        title = "2. Cấu hình gói tập",
                        subtitle = "Gym tháng (Nam/Nữ/Trẻ em), Gym PT, Yoga tháng (${packages.size} gói)",
                        testTag = "settings_group_packages",
                        onClick = { subPage = SettingsSubPage.PACKAGE_CONFIG }
                    )
                }

                // 3. Quản lý bộ sưu tập 12 phôi thẻ V4.0
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.ColorLens,
                        title = "3. Quản lý bộ sưu tập phôi thẻ",
                        subtitle = "$enabledTemplatesCount/${templates.size} phôi đang bật • 3 Mặc định, 3 Gym, 3 Yoga, 3 PT",
                        testTag = "settings_group_templates",
                        onClick = { subPage = SettingsSubPage.TEMPLATE_CONFIG }
                    )
                }

                // 4. Cài đặt xuất ảnh và PDF (3 mức: 1x, 1.5x, 2x)
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.HighQuality,
                        title = "4. Cài đặt xuất ảnh PNG & PDF",
                        subtitle = "${exportResolution.displayLabel}",
                        testTag = "settings_group_export",
                        onClick = { showExportConfigDialog = true }
                    )
                }

                // 5. Giao diện
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.DarkMode,
                        title = "5. Giao diện (Light / Dark Mode)",
                        subtitle = "Đang dùng: ${themeMode.displayLabel}",
                        testTag = "settings_group_theme",
                        onClick = { showThemeDialog = true }
                    )
                }

                // 6. Hệ thống và giới thiệu
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.Info,
                        title = "6. Hệ thống và giới thiệu",
                        subtitle = "89 FITNESS & YOGA V4.0 • 12-Template Card System",
                        testTag = "settings_group_about",
                        onClick = { showAboutDialog = true }
                    )
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }

    // 1. Brand Configuration Dialog
    if (showBrandDialog) {
        var name by remember(brandConfig) { mutableStateOf(brandConfig.brandName) }
        var contact by remember(brandConfig) { mutableStateOf(brandConfig.contactInfo) }
        var pickedLogoUri by remember { mutableStateOf<Uri?>(null) }
        var removeLogo by remember { mutableStateOf(false) }

        val logoPicker = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickVisualMedia()
        ) { uri ->
            if (uri != null) {
                pickedLogoUri = uri
                removeLogo = false
            }
        }

        AlertDialog(
            onDismissRequest = { showBrandDialog = false },
            title = { Text("Nhận diện phòng tập") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val existingLogo = brandConfig.customLogoPath?.takeIf { File(it).exists() }
                        when {
                            pickedLogoUri != null -> {
                                AsyncImage(
                                    model = pickedLogoUri,
                                    contentDescription = "Logo mới",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            existingLogo != null && !removeLogo -> {
                                AsyncImage(
                                    model = File(existingLogo),
                                    contentDescription = "Logo hiện tại",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            else -> {
                                Image(
                                    painter = painterResource(id = R.drawable.img_app_logo_fg_1794306459132),
                                    contentDescription = "Logo mặc định",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            OutlinedButton(
                                onClick = {
                                    logoPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Đổi Logo")
                            }
                            if (brandConfig.customLogoPath != null || pickedLogoUri != null) {
                                TextButton(
                                    onClick = {
                                        pickedLogoUri = null
                                        removeLogo = true
                                    }
                                ) {
                                    Text("Dùng logo mặc định")
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Tên thương hiệu (Mặc định: 89 FITNESS & YOGA)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = contact,
                        onValueChange = { contact = it },
                        label = { Text("Thông tin chân thẻ / Liên hệ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveBrandSettings(name, contact, pickedLogoUri, removeLogo)
                        showBrandDialog = false
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBrandDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    // 4. Export PNG & PDF Settings Dialog (1x, 1.5x, 2x)
    if (showExportConfigDialog) {
        var selectedRes by remember(exportResolution) { mutableStateOf(exportResolution) }
        AlertDialog(
            onDismissRequest = { showExportConfigDialog = false },
            title = { Text("Cài đặt độ phân giải xuất PNG & PDF") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Chọn 1 trong 3 mức độ phân giải chuẩn tỷ lệ 8:5 (áp dụng cho cả PNG và PDF):",
                        style = MaterialTheme.typography.bodySmall
                    )
                    ExportResolution.entries.forEach { res ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRes = res }
                                .padding(vertical = 6.dp)
                                .testTag("export_res_option_${res.code}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedRes == res,
                                onClick = { selectedRes = res }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = res.displayLabel, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Text(
                        text = "• Ảnh gốc hội viên: Pictures/89FitnessYoga/MemberPhotos/\n" +
                            "• Ảnh thẻ PNG: Pictures/89FitnessYoga/\n" +
                            "• Tệp thẻ PDF: Downloads/89FitnessYoga/",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSelectExportResolution(selectedRes)
                        showExportConfigDialog = false
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportConfigDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    // 5. Theme Mode Dialog (Immediate Preview + Confirm Save)
    if (showThemeDialog) {
        val initialMode = remember { themeMode }
        var chosenMode by remember { mutableStateOf(themeMode) }

        AlertDialog(
            onDismissRequest = {
                onSelectThemeMode(initialMode)
                showThemeDialog = false
            },
            title = { Text("Chế độ Giao diện (Light / Dark Mode)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    chosenMode = mode
                                    onSelectThemeMode(mode)
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = chosenMode == mode,
                                onClick = {
                                    chosenMode = mode
                                    onSelectThemeMode(mode)
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = mode.displayLabel, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                    Text(
                        text = "Lưu ý: Chế độ Dark Mode chỉ áp dụng cho giao diện ứng dụng, tuyệt đối không làm biến đổi màu sắc của 12 phôi thẻ khi xuất.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSelectThemeMode(chosenMode)
                        showThemeDialog = false
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        onSelectThemeMode(initialMode)
                        showThemeDialog = false
                    }
                ) {
                    Text("Hủy")
                }
            }
        )
    }

    // 6. System & About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("89 FITNESS & YOGA V4.0") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "METADATA-DRIVEN MEMBERSHIP CARD DESIGN SYSTEM",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text("• Phiên bản: 4.0 (Application ID: vn.thehoivien89gy.app)")
                    Text("• Hệ thống 12 phôi chuẩn: 3 phôi Mặc định dùng chung (A1–A3), 3 phôi Gym (G1–G3), 3 phôi Yoga (Y1–Y3), 3 phôi PT (P1–P3)")
                    Text("• Độ phân giải xuất 8:5: 1× (1200×750), 1.5× (1800×1125), 2× (2400×1500)")
                    Text("• Lưu trữ thiết bị: Ảnh gốc tại Pictures/89FitnessYoga/MemberPhotos/, PNG tại Pictures/89FitnessYoga/, PDF tại Downloads/89FitnessYoga/")
                }
            },
            confirmButton = {
                Button(onClick = { showAboutDialog = false }) {
                    Text("Đóng")
                }
            }
        )
    }
}

@Composable
private fun SettingsGroupRowCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
