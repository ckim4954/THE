package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.WorkoutPackageEntity
import com.example.data.preferences.AppPreferencesRepository
import com.example.data.repository.CardMakerRepository
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardDraft
import com.example.domain.model.CardType
import com.example.domain.model.ExportResolution
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateCatalog
import com.example.domain.model.TemplateMetadata
import com.example.domain.model.ThemeMode
import com.example.domain.util.FormattersAndValidators
import com.example.render.CardRenderPayload
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

enum class BottomNavTab {
    CREATE_CARD,
    SETTINGS
}

class CardMakerViewModel(
    application: Application,
    private val repository: CardMakerRepository
) : AndroidViewModel(application) {

    val packages: StateFlow<List<WorkoutPackageEntity>> = repository.packagesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val templates: StateFlow<List<TemplateMetadata>> = repository.templatesFlow
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            TemplateCatalog.allBuiltInTemplates()
        )

    val brandConfig: StateFlow<BrandConfig> = repository.brandConfigFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BrandConfig())

    val themeMode: StateFlow<ThemeMode> = repository.themeModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    val exportResolution: StateFlow<ExportResolution> = repository.exportResolutionFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ExportResolution.RES_1X)

    private val _currentTab = MutableStateFlow(BottomNavTab.CREATE_CARD)
    val currentTab: StateFlow<BottomNavTab> = _currentTab.asStateFlow()

    // null = Home category selector
    // 1 = Select Template Design (6 compatible templates: 3 Universal + 3 Category-Specific)
    // 2 = Enter Member Information
    // 3 = Photo & Fixed-Frame Crop
    // 4 = Preview, Quick Template Switch & Export
    private val _wizardStep = MutableStateFlow<Int?>(null)
    val wizardStep: StateFlow<Int?> = _wizardStep.asStateFlow()

    private val _draft = MutableStateFlow(CardDraft())
    val draft: StateFlow<CardDraft> = _draft.asStateFlow()

    private val _hasUnsavedChanges = MutableStateFlow(false)
    val hasUnsavedChanges: StateFlow<Boolean> = _hasUnsavedChanges.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isStatusError = MutableStateFlow(false)
    val isStatusError: StateFlow<Boolean> = _isStatusError.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureInitialDataSeeded()
        }
    }

    fun selectBottomTab(tab: BottomNavTab) {
        _currentTab.value = tab
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun postMessage(message: String, isError: Boolean = false) {
        _statusMessage.value = message
        _isStatusError.value = isError
    }

    fun getEnabledCompatibleTemplatesForCategory(cardType: CardType): List<TemplateMetadata> {
        return TemplateCatalog.getCompatibleTemplatesForCardType(
            allTemplates = templates.value,
            cardType = cardType,
            onlyEnabled = true
        )
    }

    fun getDefaultTemplateForCategory(cardType: CardType): TemplateMetadata {
        val enabledCompatible = getEnabledCompatibleTemplatesForCategory(cardType)
        return enabledCompatible.firstOrNull { it.isDefaultFor(cardType) }
            ?: enabledCompatible.first()
    }

    // --- Start Card Creation Flow (Tạo thẻ -> Chọn loại thẻ -> Chọn phôi trong 6 phôi tương thích) ---
    fun startNewCardWizard(cardType: CardType) {
        val today = FormattersAndValidators.todayFormatted()
        val defaultTemplate = getDefaultTemplateForCategory(cardType)
        val matchingPackages = getPackagesForSelection(cardType, TargetGroup.NAM)
        val defaultPkg = matchingPackages.firstOrNull()

        val initialDurationMonths = defaultPkg?.durationMonths ?: 1
        val initialEndDate = if (cardType != CardType.GYM_PT) {
            FormattersAndValidators.calculateEndDate(today, initialDurationMonths)
        } else {
            ""
        }
        val initialSessions = if (cardType == CardType.GYM_PT) {
            defaultPkg?.totalSessions?.toString() ?: "12"
        } else {
            ""
        }
        val initialPrice = defaultPkg?.priceVnd?.let {
            FormattersAndValidators.formatVndDigitsOnly(it)
        } ?: ""

        _draft.value = CardDraft(
            cardType = cardType,
            selectedTemplateId = defaultTemplate.templateId,
            targetGroup = TargetGroup.NAM,
            selectedPackageId = defaultPkg?.id,
            packageName = defaultPkg?.packageName ?: "${initialDurationMonths} tháng",
            durationMonthsText = if (cardType != CardType.GYM_PT) initialDurationMonths.toString() else "",
            fullName = "",
            phoneNumber = "",
            startDate = if (cardType != CardType.GYM_PT) today else "",
            endDate = initialEndDate,
            totalPtSessions = initialSessions,
            priceVndText = initialPrice,
            originalPhotoPath = null,
            sharedMediaStorePath = null,
            cropScale = 1f,
            cropOffsetX = 0f,
            cropOffsetY = 0f
        )
        _hasUnsavedChanges.value = false
        _currentTab.value = BottomNavTab.CREATE_CARD
        _wizardStep.value = 1 // Step 1: Template Selection (6 compatible templates)
    }

    fun exitWizard() {
        _wizardStep.value = null
        _hasUnsavedChanges.value = false
    }

    // Part 10: Switching templates preserves 100% of entered member info and original photo!
    fun selectTemplateForDraft(templateId: String) {
        _draft.update { curr ->
            curr.copy(selectedTemplateId = templateId)
        }
    }

    fun getPackagesForSelection(
        cardType: CardType,
        targetGroup: TargetGroup
    ): List<WorkoutPackageEntity> {
        return packages.value.filter { pkg ->
            if (pkg.cardType != cardType.code) return@filter false
            if (cardType == CardType.GYM_MONTHLY) {
                pkg.targetGroup == targetGroup.code
            } else {
                true
            }
        }
    }

    fun onTargetGroupChanged(newGroup: TargetGroup) {
        val current = _draft.value
        val matching = getPackagesForSelection(current.cardType, newGroup)
        val firstPkg = matching.firstOrNull()
        val months = firstPkg?.durationMonths ?: current.durationMonthsText.toIntOrNull() ?: 1
        val start = current.startDate.ifBlank { FormattersAndValidators.todayFormatted() }
        val newEnd = FormattersAndValidators.calculateEndDate(start, months)
        val newPrice = firstPkg?.priceVnd?.let { FormattersAndValidators.formatVndDigitsOnly(it) }
            ?: current.priceVndText

        _draft.update {
            it.copy(
                targetGroup = newGroup,
                selectedPackageId = firstPkg?.id,
                packageName = firstPkg?.packageName ?: "$months tháng",
                durationMonthsText = months.toString(),
                endDate = newEnd,
                priceVndText = newPrice
            )
        }
        _hasUnsavedChanges.value = true
    }

    fun onPackageSelected(pkg: WorkoutPackageEntity) {
        val current = _draft.value
        val start = current.startDate.ifBlank { FormattersAndValidators.todayFormatted() }
        val months = pkg.durationMonths ?: 1
        val newEnd = if (current.cardType != CardType.GYM_PT) {
            FormattersAndValidators.calculateEndDate(start, months)
        } else {
            ""
        }
        val newSessions = if (current.cardType == CardType.GYM_PT && pkg.totalSessions != null) {
            pkg.totalSessions.toString()
        } else {
            current.totalPtSessions
        }
        _draft.update {
            it.copy(
                selectedPackageId = pkg.id,
                packageName = pkg.packageName,
                durationMonthsText = if (current.cardType != CardType.GYM_PT) months.toString() else "",
                startDate = if (current.cardType != CardType.GYM_PT) start else "",
                endDate = newEnd,
                totalPtSessions = newSessions,
                priceVndText = FormattersAndValidators.formatVndDigitsOnly(pkg.priceVnd)
            )
        }
        _hasUnsavedChanges.value = true
    }

    fun updateDraftFields(
        fullName: String? = null,
        phoneNumber: String? = null,
        durationMonthsText: String? = null,
        startDate: String? = null,
        endDate: String? = null,
        totalPtSessions: String? = null,
        priceVndText: String? = null
    ) {
        _draft.update { curr ->
            var updatedStart = startDate ?: curr.startDate
            var updatedEnd = endDate ?: curr.endDate
            val updatedMonthsStr = durationMonthsText ?: curr.durationMonthsText
            val monthsInt = updatedMonthsStr.trim().toIntOrNull()

            if ((startDate != null || durationMonthsText != null) &&
                endDate == null &&
                monthsInt != null &&
                monthsInt > 0 &&
                FormattersAndValidators.isValidDateDdMmYyyy(updatedStart)
            ) {
                updatedEnd = FormattersAndValidators.calculateEndDate(updatedStart, monthsInt)
            }

            curr.copy(
                fullName = fullName ?: curr.fullName,
                phoneNumber = phoneNumber ?: curr.phoneNumber,
                packageName = if (monthsInt != null && monthsInt > 0 && curr.cardType != CardType.GYM_PT) {
                    "$monthsInt tháng"
                } else {
                    curr.packageName
                },
                durationMonthsText = updatedMonthsStr,
                startDate = updatedStart,
                endDate = updatedEnd,
                totalPtSessions = totalPtSessions ?: curr.totalPtSessions,
                priceVndText = priceVndText ?: curr.priceVndText
            )
        }
        _hasUnsavedChanges.value = true
    }

    fun updateCropTransform(scale: Float, offsetX: Float, offsetY: Float) {
        _draft.update {
            it.copy(
                cropScale = scale.coerceIn(0.6f, 4.5f),
                cropOffsetX = offsetX.coerceIn(-0.85f, 0.85f),
                cropOffsetY = offsetY.coerceIn(-0.85f, 0.85f)
            )
        }
        _hasUnsavedChanges.value = true
    }

    fun resetCropTransform() {
        updateCropTransform(1f, 0f, 0f)
    }

    fun onPhotoPickedFromDeviceUri(uri: Uri) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val curr = _draft.value
            val res = repository.saveOriginalMemberPhotoFromUri(uri, curr.fullName)
            _isBusy.value = false
            res.onSuccess { saved ->
                _draft.update {
                    it.copy(
                        originalPhotoPath = saved.localWorkingPath,
                        sharedMediaStorePath = saved.sharedStoragePath,
                        cropScale = 1f,
                        cropOffsetX = 0f,
                        cropOffsetY = 0f
                    )
                }
                _hasUnsavedChanges.value = true
                postMessage("Đã lưu ảnh gốc hội viên vào: ${saved.sharedStoragePath}")
            }.onFailure { err ->
                postMessage(err.message ?: "Không thể lưu ảnh gốc.", isError = true)
            }
        }
    }

    fun onPhotoCapturedFromCamera(tempFile: File) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val curr = _draft.value
            val res = repository.saveOriginalMemberPhotoFromCameraFile(tempFile, curr.fullName)
            _isBusy.value = false
            res.onSuccess { saved ->
                _draft.update {
                    it.copy(
                        originalPhotoPath = saved.localWorkingPath,
                        sharedMediaStorePath = saved.sharedStoragePath,
                        cropScale = 1f,
                        cropOffsetX = 0f,
                        cropOffsetY = 0f
                    )
                }
                _hasUnsavedChanges.value = true
                postMessage("Đã chụp và lưu ảnh gốc tại: ${saved.sharedStoragePath}")
            }.onFailure { err ->
                postMessage(err.message ?: "Lỗi khi lưu ảnh chụp.", isError = true)
            }
        }
    }

    fun goToWizardStep(targetStep: Int) {
        if (targetStep >= 3) {
            val infoErr = FormattersAndValidators.validateMemberInfoStep(_draft.value)
            if (infoErr != null) {
                postMessage(infoErr, isError = true)
                return
            }
        }
        if (targetStep == 4) {
            val photoErr = FormattersAndValidators.validatePhotoStep(_draft.value)
            if (photoErr != null) {
                postMessage(photoErr, isError = true)
                return
            }
        }
        _wizardStep.value = targetStep
    }

    fun buildRenderPayloadFromDraft(): CardRenderPayload {
        val d = _draft.value
        val b = brandConfig.value
        val price = FormattersAndValidators.parseVndInput(d.priceVndText) ?: 0L
        val months = d.durationMonthsText.trim().toIntOrNull() ?: 1
        return CardRenderPayload(
            cardType = d.cardType,
            templateId = d.selectedTemplateId,
            fullName = d.fullName.trim(),
            phoneNumber = d.phoneNumber.trim(),
            targetGroup = if (d.cardType == CardType.GYM_MONTHLY) d.targetGroup else null,
            packageName = d.packageName,
            durationMonths = if (d.cardType != CardType.GYM_PT) months else null,
            startDateFormatted = if (d.cardType != CardType.GYM_PT) d.startDate.trim() else null,
            endDateFormatted = if (d.cardType != CardType.GYM_PT) d.endDate.trim() else null,
            totalPtSessions = if (d.cardType == CardType.GYM_PT) d.totalPtSessions.trim().toIntOrNull() ?: 1 else null,
            priceVnd = price,
            photoPath = d.originalPhotoPath,
            cropScale = d.cropScale,
            cropOffsetX = d.cropOffsetX,
            cropOffsetY = d.cropOffsetY,
            brandName = b.brandName,
            brandContact = b.contactInfo,
            brandLogoPath = b.customLogoPath
        )
    }

    fun exportPayloadToPng(payload: CardRenderPayload) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.exportCardToGalleryPng(payload)
            _isBusy.value = false
            res.onSuccess { path ->
                _hasUnsavedChanges.value = false
                postMessage("Đã xuất thẻ PNG (${exportResolution.value.scaleLabel}) tại: $path")
            }.onFailure { err ->
                postMessage(err.message ?: "Xuất ảnh PNG thất bại.", isError = true)
            }
        }
    }

    fun exportPayloadToPdf(payload: CardRenderPayload, onPdfUriReady: (Uri) -> Unit) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.exportCardToSinglePagePdf(payload)
            _isBusy.value = false
            res.onSuccess { uri ->
                _hasUnsavedChanges.value = false
                postMessage("Đã xuất PDF (${exportResolution.value.scaleLabel}) tại: Downloads/89FitnessYoga/")
                onPdfUriReady(uri)
            }.onFailure { err ->
                postMessage(err.message ?: "Xuất PDF thất bại.", isError = true)
            }
        }
    }

    fun sharePayloadDirectPng(payload: CardRenderPayload, onShareUriReady: (Uri) -> Unit) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.prepareShareablePngUri(payload)
            _isBusy.value = false
            res.onSuccess { uri ->
                onShareUriReady(uri)
            }.onFailure { err ->
                postMessage(err.message ?: "Không thể chuẩn bị ảnh để chia sẻ.", isError = true)
            }
        }
    }

    // --- Settings: Package & V4.0 Template Management ---
    fun savePackageConfig(pkg: WorkoutPackageEntity) {
        viewModelScope.launch {
            repository.saveWorkoutPackage(pkg)
            postMessage("Đã lưu cấu hình gói tập '${pkg.packageName}'.")
        }
    }

    fun deletePackageConfig(pkg: WorkoutPackageEntity) {
        viewModelScope.launch {
            repository.deleteWorkoutPackage(pkg.id)
            postMessage("Đã xóa gói '${pkg.packageName}'.")
        }
    }

    fun resetDefaultPackagesForCategory(cardType: CardType) {
        viewModelScope.launch {
            repository.resetDefaultPackagesForCategory(cardType)
            postMessage("Đã khôi phục bảng giá mặc định cho ${cardType.displayTitle}.")
        }
    }

    fun setDefaultTemplateForCategory(cardType: CardType, templateId: String) {
        viewModelScope.launch {
            val res = repository.setDefaultTemplateForCategory(cardType, templateId)
            res.onSuccess {
                val tpl = templates.value.firstOrNull { it.templateId == templateId }
                postMessage("Đã đặt '${tpl?.templateName ?: templateId}' làm phôi mặc định cho ${cardType.displayTitle}.")
            }.onFailure { err ->
                postMessage(err.message ?: "Không thể đặt phôi mặc định.", isError = true)
            }
        }
    }

    fun setDefaultTemplateForAllCategories(templateId: String) {
        viewModelScope.launch {
            val res = repository.setDefaultTemplateForAllCategories(templateId)
            res.onSuccess {
                val tpl = templates.value.firstOrNull { it.templateId == templateId }
                postMessage("Đã đặt '${tpl?.templateName ?: templateId}' làm phôi mặc định cho cả 3 loại thẻ (Gym, Yoga, PT).")
            }.onFailure { err ->
                postMessage(err.message ?: "Không thể đặt phôi mặc định.", isError = true)
            }
        }
    }

    fun toggleTemplateEnabled(template: TemplateMetadata, enabled: Boolean) {
        viewModelScope.launch {
            val res = repository.setTemplateEnabledState(
                templateId = template.templateId,
                enabled = enabled
            )
            res.onSuccess {
                val stateLabel = if (enabled) "Đã bật" else "Đã tắt"
                postMessage("$stateLabel phôi '${template.templateName}'.")
            }.onFailure { err ->
                postMessage(err.message ?: "Không thể tắt phôi cuối cùng.", isError = true)
            }
        }
    }

    fun restoreAllBuiltInTemplates() {
        viewModelScope.launch {
            repository.restoreAllBuiltInTemplates()
            postMessage("Đã khôi phục toàn bộ 12 phôi thiết kế chuẩn V4.0.")
        }
    }

    fun saveBrandSettings(
        brandName: String,
        contactInfo: String,
        newLogoUri: Uri?,
        removeLogo: Boolean
    ) {
        viewModelScope.launch {
            repository.saveBrandSettings(brandName, contactInfo, newLogoUri, removeLogo)
            postMessage("Đã lưu cấu hình thương hiệu 89 FITNESS & YOGA.")
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.saveThemeMode(mode)
            postMessage("Đã lưu chế độ giao diện: ${mode.displayLabel}")
        }
    }

    fun setExportResolution(resolution: ExportResolution) {
        viewModelScope.launch {
            repository.saveExportResolution(resolution)
            postMessage("Đã lưu độ phân giải xuất thẻ: ${resolution.displayLabel}")
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AppDatabase.getInstance(application)
                    val prefs = AppPreferencesRepository(application)
                    val repo = CardMakerRepository(application, db.appDao(), prefs)
                    return CardMakerViewModel(application, repo) as T
                }
            }
    }
}
