package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.CardType
import com.example.domain.model.ImageSlotSpec
import com.example.domain.model.TemplateMetadata
import com.example.render.CardRenderEngine
import com.example.render.CardRenderPayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

@Composable
fun FixedFrameCropper(
    photoPath: String,
    imageSlot: ImageSlotSpec,
    accentColorHex: String,
    cropScale: Float,
    cropOffsetX: Float,
    cropOffsetY: Float,
    onTransformChanged: (scale: Float, offsetX: Float, offsetY: Float) -> Unit,
    onResetTransform: () -> Unit,
    modifier: Modifier = Modifier
) {
    var loadedBitmap by remember(photoPath) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(photoPath) {
        loadedBitmap = withContext(Dispatchers.IO) {
            CardRenderEngine.decodeSampledBitmap(photoPath, 1000, 1000)
        }
    }

    val accentInt = CardRenderEngine.parseHexColorSafe(
        accentColorHex,
        android.graphics.Color.parseColor("#E11D48")
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Khung ảnh cố định: ${imageSlot.shape.labelVi}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Vị trí: X=${(imageSlot.xRatio * 100).toInt()}%, Y=${(imageSlot.yRatio * 100).toInt()}% • W=${(imageSlot.widthRatio * 100).toInt()}%, H=${(imageSlot.heightRatio * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(
                    onClick = onResetTransform,
                    modifier = Modifier.testTag("reset_crop_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.CenterFocusStrong,
                        contentDescription = "Đặt lại vị trí ảnh"
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Căn giữa")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .width(220.dp)
                    .aspectRatio(imageSlot.aspectRatio)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF090D16))
                    .pointerInput(photoPath, imageSlot) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (cropScale * zoom).coerceIn(0.6f, 4.5f)
                            val boxW = size.width.toFloat().coerceAtLeast(1f)
                            val boxH = size.height.toFloat().coerceAtLeast(1f)
                            val newOffsetX = (cropOffsetX + pan.x / boxW).coerceIn(-0.85f, 0.85f)
                            val newOffsetY = (cropOffsetY + pan.y / boxH).coerceIn(-0.85f, 0.85f)
                            onTransformChanged(newScale, newOffsetX, newOffsetY)
                        }
                    }
                    .testTag("fixed_crop_viewport"),
                contentAlignment = Alignment.Center
            ) {
                val bmp = loadedBitmap
                if (bmp != null) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val rect = RectF(4f, 4f, size.width - 4f, size.height - 4f)
                        val shapePath = CardRenderEngine.createFrameShapePath(
                            rect = rect,
                            shape = imageSlot.shape,
                            cornerRadius = size.width * (imageSlot.cornerRadiusRatio / imageSlot.widthRatio)
                        )

                        drawIntoCanvas { canvas ->
                            val nativeCanvas = canvas.nativeCanvas
                            nativeCanvas.save()
                            nativeCanvas.clipPath(shapePath)

                            val bw = bmp.width.toFloat().coerceAtLeast(1f)
                            val bh = bmp.height.toFloat().coerceAtLeast(1f)
                            val baseScale = max(rect.width() / bw, rect.height() / bh)
                            val totalScale = baseScale * cropScale
                            val scaledW = bw * totalScale
                            val scaledH = bh * totalScale
                            val dx = rect.centerX() - (scaledW / 2f) + cropOffsetX * rect.width()
                            val dy = rect.centerY() - (scaledH / 2f) + cropOffsetY * rect.height()

                            val matrix = android.graphics.Matrix().apply {
                                postScale(totalScale, totalScale)
                                postTranslate(dx, dy)
                            }
                            val paint = android.graphics.Paint(
                                android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG
                            )
                            nativeCanvas.drawBitmap(bmp, matrix, paint)

                            // Subtle alignment crosshairs inside clipped shape
                            val gridPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                                color = android.graphics.Color.argb(65, 255, 255, 255)
                                strokeWidth = 1.5f
                            }
                            nativeCanvas.drawLine(rect.width() / 3f, 0f, rect.width() / 3f, rect.height(), gridPaint)
                            nativeCanvas.drawLine(rect.width() * 2f / 3f, 0f, rect.width() * 2f / 3f, rect.height(), gridPaint)
                            nativeCanvas.drawLine(0f, rect.height() / 3f, rect.width(), rect.height() / 3f, gridPaint)
                            nativeCanvas.drawLine(0f, rect.height() * 2f / 3f, rect.width(), rect.height() * 2f / 3f, gridPaint)
                            nativeCanvas.restore()

                            val borderPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                                color = accentInt
                                style = android.graphics.Paint.Style.STROKE
                                strokeWidth = 6f
                            }
                            nativeCanvas.drawPath(shapePath, borderPaint)
                        }
                    }
                } else {
                    Text(
                        text = "Đang tải ảnh gốc...",
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Kéo trong khung để di chuyển • Dùng thanh trượt để phóng to/thu nhỏ",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        onTransformChanged((cropScale - 0.15f).coerceAtLeast(0.6f), cropOffsetX, cropOffsetY)
                    }
                ) {
                    Icon(Icons.Default.ZoomOut, contentDescription = "Thu nhỏ")
                }
                Slider(
                    value = cropScale,
                    onValueChange = { newScale ->
                        onTransformChanged(newScale, cropOffsetX, cropOffsetY)
                    },
                    valueRange = 0.6f..4.0f,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("crop_zoom_slider")
                )
                IconButton(
                    onClick = {
                        onTransformChanged((cropScale + 0.15f).coerceAtMost(4.0f), cropOffsetX, cropOffsetY)
                    }
                ) {
                    Icon(Icons.Default.ZoomIn, contentDescription = "Phóng to")
                }
            }
        }
    }
}

@Composable
fun CardCanvasPreviewBox(
    payload: CardRenderPayload,
    template: TemplateMetadata,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var renderedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(payload, template) {
        renderedBitmap = withContext(Dispatchers.Default) {
            CardRenderEngine.renderCardBitmap(
                context = context,
                payload = payload,
                template = template,
                targetWidth = 1200,
                targetHeight = 750
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1200f / 750f)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF121316)),
        contentAlignment = Alignment.Center
    ) {
        val bmp = renderedBitmap
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Xem trước phôi ${template.templateName}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        } else {
            Text(
                text = "Đang dựng phôi ${template.templateName}...",
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

/**
 * Large 8:5 Aspect-Ratio Preview Thumbnail Box for 1-Column Template Selection & Management (Part 9.4 & 9.5).
 * Never crops or distorts the 8:5 card preview.
 */
@Composable
fun TemplateLargePreviewBanner(
    template: TemplateMetadata,
    brandName: String,
    previewCardType: CardType = template.category.primaryPreviewCardType(),
    isSelected: Boolean = false,
    defaultBadgeText: String? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var thumbBitmap by remember(template.templateId, template.templateVersion, brandName, previewCardType) {
        mutableStateOf<Bitmap?>(null)
    }

    LaunchedEffect(template.templateId, template.templateVersion, brandName, previewCardType) {
        thumbBitmap = withContext(Dispatchers.Default) {
            CardRenderEngine.getOrRenderSampleThumbnail(
                context = context,
                template = template,
                brandName = brandName,
                previewCardType = previewCardType
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1200f / 750f)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F172A))
            .border(
                width = if (isSelected) 2.5.dp else 1.dp,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.28f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .testTag("template_preview_banner_${template.templateId}"),
        contentAlignment = Alignment.Center
    ) {
        val bmp = thumbBitmap
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = template.templateName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        } else {
            Text(
                text = "Đang dựng ${template.templateName}...",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White
            )
        }

        if (!defaultBadgeText.isNullOrBlank()) {
            Surface(
                color = Color(0xD90F172A),
                shape = RoundedCornerShape(bottomEnd = 10.dp),
                modifier = Modifier.align(Alignment.TopStart)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = defaultBadgeText,
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = defaultBadgeText,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        if (isSelected) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(bottomStart = 10.dp),
                modifier = Modifier.align(Alignment.TopEnd)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Đang chọn",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Đang chọn",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
