package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Mode Tokens (High-contrast Cashier Minimal UI)
val CrimsonPrimaryLight = Color(0xFFDC2626)
val OnCrimsonPrimaryLight = Color(0xFFFFFFFF)
val CrimsonContainerLight = Color(0xFFFEE2E2)
val OnCrimsonContainerLight = Color(0xFF7F1D1D)

val AmberSecondaryLight = Color(0xFFD97706)
val OnAmberSecondaryLight = Color(0xFFFFFFFF)
val AmberContainerLight = Color(0xFFFEF3C7)
val OnAmberContainerLight = Color(0xFF78350F)

val EmeraldTertiaryLight = Color(0xFF059669)
val OnEmeraldTertiaryLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFD1FAE5)
val OnEmeraldContainerLight = Color(0xFF064E3B)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Mode Tokens
val CrimsonPrimaryDark = Color(0xFFF87171)
val OnCrimsonPrimaryDark = Color(0xFF450A0A)
val CrimsonContainerDark = Color(0xFF991B1B)
val OnCrimsonContainerDark = Color(0xFFFEE2E2)

val AmberSecondaryDark = Color(0xFFFBBF24)
val OnAmberSecondaryDark = Color(0xFF451A03)
val AmberContainerDark = Color(0xFF92400E)
val OnAmberContainerDark = Color(0xFFFEF3C7)

val EmeraldTertiaryDark = Color(0xFF34D399)
val OnEmeraldTertiaryDark = Color(0xFF022C22)
val EmeraldContainerDark = Color(0xFF065F46)
val OnEmeraldContainerDark = Color(0xFFD1FAE5)

val BackgroundDark = Color(0xFF0B0F17)
val SurfaceDark = Color(0xFF161C28)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF334155)
