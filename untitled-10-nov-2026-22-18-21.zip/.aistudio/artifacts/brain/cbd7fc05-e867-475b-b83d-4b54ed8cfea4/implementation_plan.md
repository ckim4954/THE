# 89 FITNESS & YOGA V4.0 – Nâng cấp Hệ thống Phôi Thẻ & Giao diện Quản lý Phôi

Bản nâng cấp chuyên biệt **V4.0** tập trung hoàn toàn vào việc tái cấu trúc **Hệ thống 12 Phôi Thẻ Metadata-Driven** (chia làm 4 nhóm: Mặc định dùng chung, Gym, Yoga, PT), tích hợp **hệ thống Vector Icon đồng bộ**, loại bỏ hoàn toàn nhãn loại thẻ tiếng Anh bị lặp ở góc phôi, bổ sung **3 mức phân giải xuất file chuẩn (1×, 1.5×, 2×)** và tối ưu hóa **giao diện Quản lý / Chọn phôi dạng danh sách 1 cột với hình xem trước lớn tỷ lệ 8:5**, trong khi giữ nguyên 100% nghiệp vụ tạo thẻ hiện có.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Các quyết định thiết kế và trải nghiệm người dùng dưới đây đã được xác nhận trực tiếp để đảm bảo tính rõ ràng, dễ quan sát và đồng nhất trên toàn bộ 12 phôi thẻ V4.0:

- ** Quyết định 1 – Bố cục màn hình Chọn phôi & Quản lý phôi**: Sử dụng **Danh sách 1 cột (Single-Column List)** với hình xem trước (`Preview Thumbnail`) lớn đúng tỷ lệ `8:5` chiếm vị trí nổi bật nhất, loại bỏ hoàn toàn lưới nhiều cột khiến phôi bị thu nhỏ và loại bỏ khoảng trống thừa phía dưới thanh tab phân loại.
- ** Quyết định 2 – Vị trí duy nhất hiển thị loại thẻ tiếng Việt**: Loại bỏ hoàn toàn nhãn pill tiếng Anh ở góc trên bên phải (`GYM MONTHLY`, `YOGA MONTHLY`, `PERSONAL TRAINING`) và mọi nhãn tiếng Anh trang trí thừa. Tên loại thẻ bằng tiếng Việt (**Thẻ Gym**, **Thẻ Yoga**, **Thẻ PT**) chỉ hiển thị **một lần duy nhất** kèm icon vector gọn gàng ngay dưới tên thương hiệu ở phần đầu thẻ.
- ** Quyết định 3 – Cơ chế đặt phôi mặc định linh hoạt cho từng loại thẻ**: Cho phép thu ngân chọn **bất kỳ phôi nào trong 6 phôi tương thích** (bao gồm 3 phôi Mặc định dùng chung `A1–A3` + 3 phôi chuyên biệt của loại thẻ đó) làm phôi mặc định cho từng hạng mục **Gym tháng**, **Yoga tháng** hoặc **Gym PT**.

---

## 1. Overview & Core Concept

- **Mục tiêu cốt lõi**: Nâng cấp hệ thống phôi thẻ lên chuẩn thiết kế đồ họa chuyên nghiệp gồm **12 phôi thực sự khác biệt** về bố cục, khung ảnh, họa tiết, màu sắc và cách trình bày thông tin; đồng thời khắc phục triệt để các bất cập UI/UX trên màn hình quản lý và chọn phôi.
- **Giữ nguyên 100% nghiệp vụ hiện tại**:
  - Giữ nguyên `applicationId = "vn.thehoivien89gy.app"`, cấu hình Gradle Wrapper và GitHub Actions.
  - Giữ nguyên cấu trúc 2 mục điều hướng chính (**Tạo thẻ** và **Cài đặt**) và quy trình tạo thẻ 4 bước.
  - Giữ nguyên bảng giá mặc định (12 gói Gym tháng Nam/Nữ/Trẻ em, 3 gói Yoga tháng, gói PT), công thức tính ngày bắt đầu/kết thúc, cơ chế chụp/chọn ảnh, lưu ảnh gốc (`Pictures/89FitnessYoga/MemberPhotos/`), căn chỉnh ảnh trong khung và xuất PNG/PDF/Sharesheet.

---

## 2. User Experience & Visual Design

### 2.1. Cấu trúc 12 Phôi Thẻ V4.0 (4 Nhóm × 3 Thiết kế = 12 Phôi)

Khi tạo thẻ cho bất kỳ hạng mục nào, hệ thống tự động lọc và hiển thị **đúng 6 phôi tương thích** (**3 phôi Nhóm A dùng chung + 3 phôi chuyên biệt của hạng mục đó**):

#### Nhóm A – 3 Phôi Mặc Định Dùng Chung (`UNIVERSAL` – Tương thích với cả Gym, Yoga và PT)
1. **`A1 – Universal Premium`**:
   - *Phong cách*: Cao cấp, hiện đại, chiều sâu sang trọng.
   - *Màu sắc & Họa tiết*: Nền Midnight Obsidian (`#0F141C`) chuyển sắc Charcoal (`#1E2633`), đường viền kim loại Champagne Gold (`#D4AF37`) tinh tế và họa tiết sóng ánh sáng mảnh ở góc.
   - *Bố cục & Khung ảnh*: Khung ảnh chữ nhật bo góc (`ROUNDED_RECT`) đặt bên trái, Header đối xứng trái, các trường thông tin đặt trong hộp kính mờ (`FILLED_GLASS`) kèm hệ thống icon vàng kim.
2. **`A2 – Universal Modern Minimal`**:
   - *Phong cách*: Tối giản hiện đại (Swiss Minimalist), không gian thoáng đãng, phân cấp thị giác sắc nét.
   - *Màu sắc & Họa tiết*: Nền sáng Alabaster (`#F8FAFC`), điểm nhấn Slate Navy (`#0F172A`) và Cobalt (`#2563EB`), phân tách bằng đường mảnh tinh gọn (`MINIMAL_HAIRLINE`).
   - *Bố cục & Khung ảnh*: Khung ảnh bo góc thanh lịch đặt bên phải, thông tin hội viên căn trái rõ ràng trên nền sáng, cực kỳ dễ đọc và trang nhã.
3. **`A3 – Universal Futuristic`**:
   - *Phong cách*: Công nghệ tương lai, hình khối kỹ thuật và ánh sáng kiểm soát tốt.
   - *Màu sắc & Họa tiết*: Nền Deep Space (`#080D1A`), điểm nhấn Electric Cyan (`#06B6D4`) & Neon Blue (`#3B82F6`), lưới tọa độ kỹ thuật số góc thẻ.
   - *Bố cục & Khung ảnh*: Khung ảnh vát góc 8 cạnh (`CHAMFERED_OCTAGON`) bên trái, hộp dữ liệu viền kỹ thuật sắc nét (`TECH_FRAME`).

#### Nhóm B – 3 Phôi Gym Monthly (`GYM` – Chỉ hiển thị cho Gym tháng)
4. **`G1 – Athletic Performance`**:
   - *Phong cách*: Thể thao chuyên nghiệp, năng lượng và hiệu suất cao.
   - *Màu sắc & Họa tiết*: Nền Carbon (`#111318`), dải chéo động lực học Crimson Red (`#E11D48`), khung ảnh vát chéo thể thao (`CUT_CORNER`) bên trái.
5. **`G2 – Luxury Black & Gold`**:
   - *Phong cách*: Câu lạc bộ thể hình thượng lưu, nền đen tuyền và vàng kim.
   - *Màu sắc & Họa tiết*: Nền Onyx (`#09090B`), viền kép Royal Gold (`#EAB308`), khung ảnh vòm nghệ thuật (`ARCH_TOP`) đặt bên phải, Header huy hiệu trang trọng.
6. **`G3 – Bold Sport Editorial`**:
   - *Phong cách*: Tạp chí thể thao hiện đại, bố cục bất đối xứng cá tính.
   - *Màu sắc & Họa tiết*: Dải băng dọc bên trái màu Volt Flame (`#F97316`) trên nền Graphite (`#18181B`), khung ảnh đặt bên phải, các trường dữ liệu trình bày theo cột Editorial (`EDITORIAL_COLUMN`).

#### Nhóm C – 3 Phôi Yoga Monthly (`YOGA` – Chỉ hiển thị cho Yoga tháng)
7. **`Y1 – Zen Minimal`**:
   - *Phong cách*: Tối giản, thư giãn, cân bằng và nhiều khoảng thở.
   - *Màu sắc & Họa tiết*: Nền kem Warm Ivory (`#FAF7F2`), điểm nhấn Sage Green (`#2E6F40`), vòng tròn thiền Enso thanh thoát, khung ảnh vòm (`ARCH_TOP`) bên trái.
8. **`Y2 – Botanical Elegance`**:
   - *Phong cách*: Thiên nhiên hữu cơ, thanh lịch.
   - *Màu sắc & Họa tiết*: Nền Deep Botanical (`#0D2B22`), họa tiết lá và đường cong hữu cơ màu Mint Gold (`#6EE7B7` & `#D4AF37`), khung ảnh viên nang (`OVAL_PILL`) đặt bên phải.
9. **`Y3 – Luxury Wellness`**:
   - *Phong cách*: Studio chăm sóc sức khỏe cao cấp, mềm mại.
   - *Màu sắc & Họa tiết*: Nền Velvet Plum & Warm Taupe (`#23192D` -> `#382644`), dải lụa Rose Champagne (`#F4B8C5`), khung ảnh tròn huy chương (`CIRCLE`) cân đối.

#### Nhóm D – 3 Phôi Gym PT (`PT` – Chỉ hiển thị cho Gym PT)
10. **`P1 – Elite Personal Trainer`**:
    - *Phong cách*: Huấn luyện viên cá nhân cao cấp, nhấn mạnh chương trình 1-kèm-1 và tổng số buổi tập.
    - *Màu sắc & Họa tiết*: Nền Obsidian (`#0F1115`), điểm nhấn Amber Gold (`#F59E0B`), khung ảnh vát chéo (`CUT_CORNER`) bên trái, ô Tổng số buổi PT được đóng khung nổi bật.
11. **`P2 – Performance Lab`**:
    - *Phong cách*: Phòng nghiên cứu hiệu suất thể thao, chính xác và hiện đại.
    - *Màu sắc & Họa tiết*: Nền Cobalt Tech (`#091526`), lưới đo lường Ice Cyan (`#38BDF8`), khung ảnh đặt bên phải, bố cục thông số kỹ thuật rõ ràng.
12. **`P3 – Black Titanium`**:
    - *Phong cách*: Kim loại đen xước cao cấp, độc quyền.
    - *Màu sắc & Họa tiết*: Nền Brushed Titanium (`#141619`), viền kim loại Bạc Platinum (`#E2E8F0`) & điểm nhấn Đỏ Ruby (`#EF4444`), khung ảnh bát giác (`CHAMFERED_OCTAGON`) bên trái.

---

### 2.2. Hệ Thống Vector Icon Đồng Bộ & Quy Tắc Loại Bỏ Thông Tin Thừa

- **Loại bỏ hoàn toàn nhãn lặp & tiếng Anh thừa**:
  - Xóa bỏ hoàn toàn nhãn pill ở góc trên bên phải (`GYM MONTHLY`, `YOGA MONTHLY`, `PERSONAL TRAINING`) và xóa nhãn `"MEMBER VERIFIED"` dưới khung ảnh tròn.
  - Không lặp lại trường `LOẠI THẺ` trong lưới thông tin bên dưới.
  - Ngay dưới tên thương hiệu `89 FITNESS & YOGA` ở Header, vẽ **icon Loại thẻ (`credit-card / membership`)** đi kèm nhãn tiếng Việt ngắn gọn tương ứng với thẻ đang tạo: **`Thẻ Gym`**, **`Thẻ Yoga`**, hoặc **`Thẻ PT`** (kèm tên phong cách phôi tinh tế).
- **Hệ thống Vector Icon chuyên nghiệp trên từng trường dữ liệu** (vẽ trực tiếp bằng đường nét Vector `Path` sắc nét ở mọi độ phân giải 1×, 1.5×, 2×):
  - **Họ và tên hội viên**: Icon `person/user` đồng bộ màu nhấn.
  - **Nhóm đối tượng (Nam / Nữ / Trẻ em)**: Icon `user-group / badge`.
  - **Số điện thoại**: Icon `phone`.
  - **Ngày bắt đầu**: Icon `calendar`.
  - **Ngày hết hạn**: Icon `calendar-check`.
  - **Thời hạn gói**: Icon `clock / calendar-range`.
  - **Tổng số buổi PT**: Icon `dumbbell`.
  - **Giá tiền**: Icon `wallet / coins`.

---

### 2.3. Thiết Kế Lại Giao Diện Quản Lý Phôi & Chọn Phôi (Sửa Lỗi UI/UX)

- **Khắc phục triệt để các lỗi bố cục cũ**:
  - Thu gọn phần Header màn hình quản lý phôi và đặt 4 tab lọc (**`Mặc định (3)`**, **`Gym (3)`**, **`Yoga (3)`**, **`PT (3)`**) nằm sát ngay dưới tiêu đề, loại bỏ hoàn toàn khoảng trống thừa bên dưới thanh tab.
  - Thay thế Grid nhiều cột hoặc thẻ ngang nhỏ bằng **Danh sách 1 cột (`LazyColumn`) với thẻ hiển thị dọc có hình Thumbnail lớn**:
    1. **Hình xem trước phôi (`Preview Thumbnail`) rộng toàn chiều ngang thẻ (`fillMaxWidth`) giữ chuẩn tỷ lệ `8:5`**, giúp thu ngân nhìn rõ từng đường nét thiết kế, khung ảnh, icon và chữ trên cả màn hình `360dp`.
    2. **Tên phôi đầy đủ** (không bị cắt ngắn vô lý) + **Nhãn phong cách & Nhóm phôi** (`Mặc định dùng chung`, `Chuyên biệt Gym`, `Chuyên biệt Yoga`, `Chuyên biệt PT`).
    3. **Trạng thái Mặc định & Bật/Tắt** gọn gàng trên cùng một hàng điều khiển cùng nút **Xem thử** và **Đặt mặc định**.
- **Màn hình Chọn phôi khi tạo thẻ (Bước 1)**:
  - Chỉ hiển thị đúng **6 phôi tương thích** với loại thẻ đang tạo (3 phôi Mặc định dùng chung + 3 phôi chuyên biệt của loại thẻ đó).
  - Cho phép lọc nhanh (`Tất cả (6)`, `Mặc định (3)`, `Chuyên biệt (3)`) và cuộn xem danh sách **1 cột với hình Thumbnail lớn tỷ lệ `8:5`**, chạm để chọn ngay hoặc nhấn **Xem thử** phóng to toàn màn hình.

---

## 3. Key Product Decisions & Trade-Offs

- **Quyết định 1: Kiến trúc Phôi Metadata-Driven kết hợp Vector Icon Renderer**
  - *Giải pháp*: Mở rộng `TemplateMetadata` để lưu trữ đầy đủ cấu hình V4.0 (`category: TemplateCategory`, `styleName`, `photoFrame`, `logoPosition`, `textFieldPositions`, `iconPositions`, `colorPalette`, `typography`, `overflowRules`) và sử dụng duy nhất `CardRenderEngine` để đọc cấu hình và render.
  - *Lý do*: Đảm bảo 3 phôi `UNIVERSAL` tự động thích ứng mượt mà với dữ liệu của cả 3 loại thẻ (Gym tháng, Yoga tháng, Gym PT) mà không bao giờ bị thiếu trường hay thừa trường.
- **Quyết định 2: Hỗ trợ đầy đủ 3 mức phân giải xuất file (1×, 1.5×, 2×)**
  - *Giải pháp*: Cập nhật `ExportResolution` gồm đúng 3 mức:
    - **`1×`**: `1200 × 750 px` (Tiêu chuẩn)
    - **`1.5×`**: `1800 × 1125 px` (Sắc nét trung bình cao)
    - **`2×`**: `2400 × 1500 px` (Sắc nét cao 2×)
  - *Lý do*: Khi xuất PNG hoặc PDF, `CardRenderEngine` nhân tỷ lệ trực tiếp trên hệ trục vector (`scale = targetWidth / 1200f`) và giải mã ảnh hội viên từ **ảnh gốc độ phân giải cao** (tuyệt đối không phóng to từ thumbnail `600 × 375`), sau đó giải phóng bộ nhớ tạm ngay khi ghi file xong.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### 4.1. Sơ Đồ Kiến Trúc Hệ Thống Phôi V4.0

```
┌────────────────────────────────────────────────────────────────────────────┐
│                   UI LAYER (JETPACK COMPOSE - 360dp READY)                 │
├──────────────────────────────────────┬─────────────────────────────────────┤
│        TẠO THẺ (4-STEP WIZARD)       │       CÀI ĐẶT & QUẢN LÝ PHÔI        │
│  ┌────────────────────────────────┐  │  ┌───────────────────────────────┐  │
│  │ B1: Chọn Phôi (6 Phôi Hợp Lệ)  │  │  │ Quản lý 12 Phôi (4 Tab Lọc)   │  │
│  │ • 3 Mặc định (A1, A2, A3)      │  │  │ • Mặc định (3) | Gym (3)      │  │
│  │ • 3 Chuyên biệt (G/Y/P 1..3)   │  │  │ • Yoga (3)     | PT (3)       │  │
│  │ • Danh sách 1 cột Thumbnail 8:5│  │  │ • Danh sách 1 cột Thumbnail   │  │
│  ├────────────────────────────────┤  │  │   lớn 8:5, Bật/Tắt, Mặc định  │  │
│  │ B2: Nhập Thông Tin Động        │  │  ├───────────────────────────────┤  │
│  │ B3: Ảnh Gốc & Crop Đa Hình Dạng│  │  │ Cấu hình Độ phân giải Xuất:   │  │
│  │ B4: Xem Trước & Đổi Nhanh Phôi │  │  │ • 1x (1200×750)               │  │
│  │     (Giữ nguyên 100% dữ liệu)  │  │  │ • 1.5x (1800×1125)            │  │
│  └───────────────┬────────────────┘  │  │ • 2x (2400×1500)              │  │
└──────────────────┼───────────────────┴──┴───────────────┬───────────────┘
                   │                                      │
                   ▼                                      ▼
┌────────────────────────────────────────────────────────────────────────────┐
│             METADATA-DRIVEN RENDER ENGINE (CardRenderEngine)               │
│  • 12 Built-in Templates (TemplateCatalog V4.0: A1–A3, G1–G3, Y1–Y3, P1–P3)│
│  • Vector Icon Canvas Drawer (User, Group, Phone, Calendar, Check,         │
│    Clock, Dumbbell, Wallet, Card Badge)                                    │
│  • Dynamic Field Layout (Auto-shrink & Ellipsize, No Hardcoded Duration)   │
│  • Original Photo High-Res Decoder + Multi-Shape Path Clipping             │
└────────────────────────────────────────────────────────────────────────────┘
```

### 4.2. Mô Hình Dữ Liệu & Luồng Tương Tác Chính

1. **Phân nhóm Phôi (`TemplateCategory`)**:
   - `UNIVERSAL` ("Mặc định"): Gồm `A1`, `A2`, `A3` — tương thích với cả `GYM_MONTHLY`, `YOGA_MONTHLY`, `GYM_PT`.
   - `GYM` ("Gym"): Gồm `G1`, `G2`, `G3` — chỉ tương thích với `GYM_MONTHLY`.
   - `YOGA` ("Yoga"): Gồm `Y1`, `Y2`, `Y3` — chỉ tương thích với `YOGA_MONTHLY`.
   - `PT` ("PT"): Gồm `P1`, `P2`, `P3` — chỉ tương thích với `GYM_PT`.
2. **Cơ chế lưu Phôi mặc định theo từng loại thẻ**:
   - Vì phôi nhóm `UNIVERSAL` (`A1–A3`) có thể được đặt làm mặc định cho bất kỳ loại thẻ nào (`Gym tháng`, `Yoga tháng`, hoặc `Gym PT`), hệ thống lưu ID phôi mặc định riêng cho từng loại thẻ (`defaultTemplateIdForGym`, `defaultTemplateIdForYoga`, `defaultTemplateIdForPt`) kết hợp trạng thái bật/tắt của 12 phôi trong cơ sở dữ liệu Room (`v4`).
3. **Chuyển đổi phôi không mất dữ liệu**:
   - Khi thu ngân đổi giữa 6 phôi tương thích ở Bước 1 hoặc Bước 4 (Xem trước), toàn bộ dữ liệu hội viên (`fullName`, `phoneNumber`, `targetGroup`, `packageName`, `durationMonthsText`, `startDate`, `endDate`, `totalPtSessions`, `priceVndText`, `originalPhotoPath`) được giữ nguyên tuyệt đối; khung ảnh tự động áp dụng hình dáng (`PhotoFrameShape`) và vị trí (`imageSlot`) của phôi mới.
