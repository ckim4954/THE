# 89 FITNESS & YOGA – Virtual Membership Card Maker

Ứng dụng Android native, hoạt động hoàn toàn độc lập (offline-first), chuyên tạo, lưu trữ và xuất thẻ hội viên kỹ thuật số chất lượng cao (PNG & PDF) tại quầy thu ngân cho phòng tập **89 FITNESS & YOGA**. Hệ thống đảm bảo thao tác cực nhanh theo 3 bước, lưu giữ nguyên bản ảnh gốc của hội viên tách biệt khỏi thẻ đã tạo, và cho phép chỉnh sửa linh hoạt mọi thông tin tự động điền.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Dưới đây là các quyết định thiết kế cốt lõi đã được xác nhận và chuẩn hóa cho Giai đoạn 1 trước khi bắt đầu lập trình:

- **Confirmed Decision 1 – Định hướng màu sắc 3 phôi thẻ mặc định**: Phân biệt rõ màu sắc nhận diện theo từng loại thẻ trên cùng hệ lưới bố cục và thương hiệu **89 FITNESS & YOGA**:
  - **GYM MONTHLY**: Tông Đen Carbon kết hợp Đỏ Crimson mạnh mẽ (`#121316` & `#E11D48`).
  - **GYM PERSONAL TRAINING**: Tông Đen Obsidian kết hợp Vàng Gold cao cấp (`#111113` & `#F59E0B`).
  - **YOGA MONTHLY**: Tông Xanh Ngọc Lục Bảo trầm kết hợp Kem ấm thanh lịch (`#064E3B` & `#34D399` / `#FDFBF7`).
- **Confirmed Decision 2 – Cơ chế Sao lưu & Khôi phục toàn diện**: Xuất và nhập một tệp nén `.zip` duy nhất chứa toàn bộ bản ghi cơ sở dữ liệu (thẻ đã tạo, gói tập, cấu hình thương hiệu, metadata phôi) cùng toàn bộ thư mục ảnh gốc hội viên và logo tùy chỉnh.
- **Confirmed Decision 3 – Bố cục xuất PDF**: Tập trung tối đa cho thao tác tại quầy bằng cách xuất mỗi thẻ trên một trang PDF độc lập theo đúng tỷ lệ chuẩn `8:5` (`1200 × 750 pt`), giữ nguyên độ sắc nét để gửi chứng từ hoặc in nhanh mà không làm méo thẻ.
- **Kiểm tra mâu thuẫn & Ràng buộc phạm vi**:
  - Tuyệt đối không có tính năng điểm danh (check-in), đếm số buổi PT còn lại, theo dõi hạn thẻ tự động hay bắt buộc đăng nhập tài khoản.
  - Xóa thẻ trong Thư viện Thẻ **không** xóa ảnh gốc trong Thư viện Ảnh Hội Viên; xóa gói tập trong Cài đặt **không** làm thay đổi lịch sử giá hay thời hạn trên các thẻ đã phát hành trước đó.

---

### 1. Overview & Core Concept

- **What It Does**: Cung cấp công cụ chuyên dụng tại bàn thu ngân giúp nhân viên phát hành 3 loại thẻ kỹ thuật số (**Gym Tháng**, **Gym PT**, **Yoga Tháng**) chỉ trong vài giây. Nhân viên chọn gói tập để tự động điền giá/thời hạn, chụp hoặc chọn ảnh hội viên (tự động lưu bản gốc chất lượng cao), căn chỉnh ảnh trong khung cố định của phôi, xem trước bản render thực tế và xuất ngay ra ảnh PNG, tệp PDF hoặc chia sẻ trực tiếp qua Zalo/Messenger.
- **Target Audience / Persona**: Thu ngân và lễ tân tại quầy **89 FITNESS & YOGA** thao tác trên điện thoại Android trong môi trường cần tốc độ, độ chính xác cao và không phụ thuộc kết nối mạng.
- **Key Value**: Tách biệt hoàn toàn dữ liệu cấu hình mặc định, dữ liệu bản ghi từng thẻ và kho ảnh gốc của khách hàng; giúp tái sử dụng ảnh hội viên cũ để làm thẻ mới chỉ bằng một chạm mà không cần xây dựng hệ thống quản lý CRM phức tạp.

---

### 2. User Experience & Visual Design

#### Key User Flows

1. **Luồng Tạo Thẻ 3 Bước (Tạo thẻ -> Chọn loại thẻ -> Biểu mẫu 3 bước)**:
   - **Bước 1 – Thông tin**: Chọn nhóm đối tượng (Nam / Nữ / Trẻ em nếu là Gym Tháng) và chọn gói tập từ danh sách cấu hình. Hệ thống tự động điền Ngày bắt đầu (hôm nay), Ngày hết hạn (cộng theo số tháng của gói) hoặc Số buổi PT, và Giá tiền (định dạng VND). Thu ngân có thể sửa trực tiếp bất kỳ ô nào cho thẻ hiện tại mà không ảnh hưởng cấu hình gốc.
   - **Bước 2 – Ảnh hội viên**: Chụp ảnh mới bằng CameraX, chọn từ Android Photo Picker, hoặc chọn lại từ **Thư viện Ảnh Hội Viên** sẵn có. Ngay khi xác nhận ảnh nguồn, bản gốc được lưu độc lập vào bộ nhớ. Người dùng dùng cử chỉ chạm (kéo, phóng to/thu nhỏ) để căn chỉnh ảnh vừa vặn trong khung tỷ lệ cố định của phôi thẻ.
   - **Bước 3 – Xem trước & Xuất**: Hiển thị bản render thật `1200 × 750 px` từ `CardRenderEngine`. Hỗ trợ quay lại Bước 1/Bước 2 mà không mất dữ liệu đang nhập, hoặc nhấn **Lưu vào Thư viện**, **Xuất PNG**, **Xuất PDF**, **Chia sẻ ngay** (Android Sharesheet qua `FileProvider`).
2. **Luồng Thư Viện Kép (2 Phân khu tách biệt bằng Segmented Tabs)**:
   - **Tab A – Thẻ đã tạo**: Tìm kiếm theo họ tên/số điện thoại, lọc theo 3 loại thẻ (`Tất cả`, `Gym Tháng`, `Gym PT`, `Yoga Tháng`). Cho phép xem chi tiết thẻ lớn, chỉnh sửa thông tin (có hộp thoại xác nhận lưu và tạo bản render mới), xuất lại PNG/PDF, chia sẻ lại hoặc xóa bản ghi thẻ.
   - **Tab B – Ảnh hội viên**: Hiển thị lưới ảnh gốc chất lượng cao kèm tên, số điện thoại và ngày chụp. Tìm kiếm nhanh theo tên hoặc SĐT, xem ảnh toàn màn hình, nhấn **"Dùng ảnh này tạo thẻ"** để chuyển thẳng sang luồng tạo thẻ với ảnh và họ tên/SĐT điền sẵn, hoặc xóa riêng ảnh gốc (có cảnh báo xác nhận).
3. **Luồng Cài Đặt (7 Nhóm chức năng)**:
   - Nhận diện thương hiệu (Logo, Tên thương hiệu mặc định `89 FITNESS & YOGA`, SĐT/Địa chỉ liên hệ).
   - Cấu hình gói tập (3 tab riêng: **Gym Tháng** với bảng giá mặc định Nam/Nữ/Trẻ em được khởi tạo sẵn; **Gym PT** quản lý gói theo số buổi; **Yoga Tháng** quản lý gói theo tháng).
   - Quản lý phôi thẻ (Xem thông số metadata 3 phôi mặc định, tùy chỉnh màu nhấn/hiển thị hoặc tải ảnh nền phôi tùy chỉnh theo chuẩn `1200 × 750`).
   - Cài đặt chất lượng xuất ảnh PNG và trang đơn PDF.
   - Sao lưu & Khôi phục dữ liệu (`.zip` qua Storage Access Framework).
   - Giao diện (`Light Mode`, `Dark Mode`, `System Default` chuyển đổi tức thì).
   - Hệ thống & Giới thiệu ứng dụng.

#### Visual Identity & Theme

- **Aesthetic Direction**: **Minimal UI – Functional Cashier UX**. Giao diện sắc gọn, độ tương phản cao, khoảng trắng hợp lý, không chứa biểu đồ rườm rà hay mô tả thừa.
- **Color Palette & Mood**:
  - **Light Mode**: Nền chính `--background: #F8FAFC`, bề mặt thẻ `--surface: #FFFFFF`, chữ chính `--on-surface: #0F172A`, chữ phụ `--on-surface-variant: #475569`, màu thương hiệu chủ đạo `--primary: #DC2626` (Crimson Athletic), màu nhấn phụ `--secondary: #D97706` (Amber Gold).
  - **Dark Mode**: Nền chính `--background: #0B0F17`, bề mặt `--surface: #161C28`, chữ chính `--on-surface: #F8FAFC`, chữ phụ `--on-surface-variant: #94A3B8`, màu chủ đạo `--primary: #F87171`.
  - **Độc lập màu phôi thẻ**: Chế độ Sáng/Tối của ứng dụng chỉ đổi giao diện điều khiển, tuyệt đối không làm biến đổi màu sắc của 3 phôi thẻ khi render.
- **Typography & Hierarchy**:
  - Cài đặt bộ font Google Fonts cục bộ (qua `font-util`) hỗ trợ trọn vẹn dấu tiếng Việt: **Montserrat** (Bold/ExtraBold cho tiêu đề thẻ, tên hội viên in hoa, loại thẻ) kết hợp **Be Vietnam Pro** (Regular/Medium/SemiBold cho nhãn trường, số điện thoại, ngày tháng, giá tiền và toàn bộ giao diện thu ngân).
- **Component Styling & Layout (Chuẩn màn hình cơ sở 360dp)**:
  - Lề ngang tiêu chuẩn `16.dp`, khoảng cách giữa các khối `12.dp – 16.dp`, chiều cao ô nhập liệu `56.dp`, nút hành động chính cao `52.dp` (đảm bảo vùng chạm tối thiểu `48.dp`).
  - Mọi biểu mẫu đều bọc trong vùng cuộn kết hợp `imePadding()` để bàn phím ảo không bao giờ che khuất ô đang nhập hay nút xác nhận.
- **Interactive Feedback & Motion**:
  - Chặn nhấn đúp (debounce/loading lock) trên các nút **Lưu thẻ**, **Xuất PNG**, **Xuất PDF**, **Chia sẻ** để không sinh bản ghi trùng lặp.
  - Cảnh báo `BackHandler` + `AlertDialog` mỗi khi người dùng thoát màn hình biểu mẫu hoặc cài đặt có thay đổi chưa lưu.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 – Lưu trữ bản chụp độc lập (Snapshot Immutability) cho Thẻ Đã Tạo**:
  - *Chosen Approach*: Mỗi bản ghi thẻ trong Room Database lưu trực tiếp giá trị chuỗi/số đã chốt tại thời điểm phát hành (Tên gói, Giá tiền VND, Ngày bắt đầu, Ngày hết hạn, Số buổi PT, Tên thương hiệu lúc tạo, Đường dẫn ảnh đã crop và ID ảnh gốc tham chiếu mềm).
  - *Why*: Đảm bảo khi thu ngân xóa/sửa giá gói tập trong Cài đặt hoặc xóa ảnh gốc trong Thư viện Ảnh, các thẻ lịch sử đã phát hành vẫn giữ nguyên thông tin và hình ảnh chính xác.
  - *Alternatives Considered*: Liên kết khóa ngoại cứng (`FOREIGN KEY CASCADE`) tới bảng Gói tập và Ảnh gốc — bị loại bỏ vì sẽ làm hỏng dữ liệu lịch sử khi chỉnh sửa bảng giá.
- **Decision 2 – Render Thẻ bằng Native Android Canvas (`Bitmap` `1200 × 750` ARGB_8888)**:
  - *Chosen Approach*: Xây dựng `CardRenderEngine` vẽ trực tiếp lên `Bitmap` độ phân giải cố định `1200 × 750 px` (tỷ lệ `8:5`) bằng `android.graphics.Canvas`, `Paint`, `Typeface` tiếng Việt và `StaticLayout` thay vì chụp ảnh màn hình Composable (`View.drawToBitmap`).
  - *Why*: Kết quả xuất PNG và PDF đạt độ nét đồng nhất tuyệt đối trên mọi điện thoại Android, không phụ thuộc kích thước hay mật độ điểm ảnh (DPI) của màn hình thiết bị.
  - *Alternatives Considered*: Chụp lại khung nhìn hiển thị trên màn hình — bị loại bỏ vì dễ vỡ nét trên máy màn hình nhỏ hoặc bị cắt chữ khi người dùng tăng kích thước font hệ thống.
- **Decision 3 – Tách biệt 3 vùng lưu trữ Ảnh (Ảnh gốc, Ảnh crop cho thẻ, Ảnh xuất PNG/PDF)**:
  - *Chosen Approach*:
    1. **Ảnh gốc hội viên (`original_photos/`)**: Lưu nguyên bản ngay khi chụp/chọn trong bộ nhớ riêng của ứng dụng, quản lý qua bảng `MemberPhotoEntity`.
    2. **Ảnh đã căn chỉnh (`card_crops/`)**: Lưu bản cắt đúng tỷ lệ khung ảnh cố định của từng thẻ để phục vụ render nhanh.
    3. **Ảnh xuất ra (`MediaStore` `Pictures/89FitnessYoga` & `Documents/`)**: Chỉ tạo khi thu ngân bấm Xuất PNG hoặc Xuất PDF, đồng thời hỗ trợ chia sẻ tức thì từ bộ nhớ đệm `cache/shared_cards/` qua `FileProvider`.
  - *Why*: Tuân thủ nghiêm ngặt quy tắc không ghi đè ảnh gốc bằng ảnh đã crop và không ép người dùng phải lưu ảnh vào máy trước khi chia sẻ Zalo.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

#### Architecture & Component Diagram

Ứng dụng được tổ chức thành 4 tầng rõ ràng: **Presentation Layer** (Jetpack Compose + ViewModel), **Domain Layer** (Use Cases + Validation + Định dạng VND/Ngày tháng), **Data Layer** (Room Database + Preferences DataStore + File/MediaStore Manager) và **Rendering Layer** (Template Metadata + Fixed-Slot Image Cropper + Native Canvas Card Renderer + PNG/PDF/ZIP Exporters).

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                        PRESENTATION LAYER (Jetpack Compose)                  │
│                                                                              │
│  ┌─────────────────────────┐  ┌─────────────────────────┐  ┌──────────────┐  │
│  │   Tab 1: Tạo Thẻ        │  │   Tab 2: Thư Viện       │  │ Tab 3: CàiĐặt│  │
│  │  • Chọn Loại Thẻ (3)    │  │  • Khu A: Thẻ Đã Tạo    │  │ • Thương Hiệu│  │
│  │  • Bước 1: Thông Tin    │  │    (Tìm, Lọc, Sửa, Xóa) │  │ • Gói Tập (3)│  │
│  │  • Bước 2: Khung Ảnh    │  │  • Khu B: Ảnh Hội Viên  │  │ • Phôi Thẻ   │  │
│  │  • Bước 3: Xem Trước    │  │    (Xem gốc, Tái sử dụng│  │ • Xuất & ZIP │  │
│  └────────────┬────────────┘  └────────────┬────────────┘  └──────┬───────┘  │
│               └────────────────────────────┼──────────────────────┘          │
│                                            ▼                                 │
│                    ┌──────────────────────────────────────┐                  │
│                    │   ViewModels & UnsavedChangeGuard    │                  │
│                    └───────────────────┬──────────────────┘                  │
└────────────────────────────────────────┼─────────────────────────────────────┘
                                         ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                     DOMAIN & RENDERING LAYER (Pure Kotlin / Canvas)          │
│                                                                              │
│  ┌──────────────────────────────────┐  ┌──────────────────────────────────┐  │
│  │   Business Rules & Validators    │  │       Card Render Engine         │  │
│  │  • Khởi tạo 12 gói Gym mặc định  │  │  • Canvas 1200x750px (8:5 sRGB)  │  │
│  │  • Tự tính ngày hết hạn & VND    │  │  • TemplateMetadata & Slot Clip  │  │
│  │  • Kiểm tra trường theo loại thẻ │  │  • Text Auto-Fit & Ellipsize VN  │  │
│  └─────────────────┬────────────────┘  │  • PNG / Single-Page PDF Export  │  │
│                    │                   └─────────────────┬────────────────┘  │
└────────────────────┼─────────────────────────────────────┼───────────────────┘
                     ▼                                     ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                          DATA & STORAGE LAYER (Offline-First)                │
│                                                                              │
│  ┌─────────────────────────┐  ┌─────────────────────────┐  ┌──────────────┐  │
│  │     Room Database       │  │  Preferences DataStore  │  │ File Storage │  │
│  │  • membership_cards     │  │  • BrandConfig          │  │ • original/  │  │
│  │  • workout_packages     │  │  • ThemeMode (3 chế độ) │  │ • crops/     │  │
│  │  • member_photos        │  │  • ExportQualityConfig  │  │ • templates/ │  │
│  │  • card_templates       │  │  • FirstLaunchSeedFlag  │  │ • backup.zip │  │
│  └─────────────────────────┘  └─────────────────────────┘  └──────────────┘  │
└──────────────────────────────────────────────────────────────────────────────┘
```

#### Danh sách Màn hình & Luồng Điều hướng

Hệ thống sử dụng thanh `NavigationBar` 3 mục cố định ở đáy màn hình chính và điều hướng phân cấp rõ ràng cho các màn hình con (tất cả màn hình nhập liệu/chỉnh sửa đều gắn `BackHandler` kiểm tra dữ liệu chưa lưu):

1. **Màn hình Trang chủ / Tạo thẻ (`CreateCardHome`)**: Hiển thị thương hiệu `89 FITNESS & YOGA`, 3 thẻ chọn nhanh (**Gym Tháng**, **Gym PT**, **Yoga Tháng**), lối tắt tới Thư viện/Cài đặt và danh sách các thẻ vừa tạo gần đây.
2. **Màn hình Biểu mẫu Tạo/Sửa Thẻ 3 Bước (`CardWizardScreen`)**:
   - Chế độ Bước 1 (`StepInfo`): Hiển thị đúng các trường thuộc loại thẻ đã chọn, bộ chọn Gói tập tự điền, bộ chọn Ngày (`DatePickerDialog` chuẩn `DD/MM/YYYY`), và ô nhập giá VND có định dạng dấu chấm phân cách hàng nghìn.
   - Chế độ Bước 2 (`StepPhotoCrop`): Tích hợp chụp ảnh CameraX, chọn ảnh `PickVisualMedia`, hoặc chọn từ Thư viện Ảnh Hội Viên; kèm khung căn chỉnh cố định (`FixedFrameCropper`) cho phép zoom/kéo ảnh bên trong khung quy định của phôi.
   - Chế độ Bước 3 (`StepPreviewExport`): Hiển thị thẻ đã render, các nút Lưu Thư Viện, Xuất PNG, Xuất PDF, Chia sẻ qua Sharesheet.
3. **Màn hình Thư viện (`LibraryScreen`)**:
   - Phân khu **Thẻ đã tạo**: Thanh tìm kiếm Tên/SĐT, chip lọc 3 loại thẻ, danh sách thẻ và hộp thoại xem chi tiết / chỉnh sửa / xuất lại / xóa thẻ.
   - Phân khu **Ảnh hội viên**: Thanh tìm kiếm Tên/SĐT, lưới ảnh gốc lớn, màn hình xem ảnh gốc toàn kích thước, nút **"Tạo thẻ mới từ ảnh này"** và nút xóa riêng ảnh gốc.
4. **Màn hình Cài đặt (`SettingsScreen`) & 7 màn hình/hộp thoại chuyên biệt**:
   - **Nhận diện phòng tập (`BrandSettingsScreen`)**: Đổi logo, tên thương hiệu, thông tin liên hệ.
   - **Cấu hình gói tập (`PackageSettingsScreen`)**: Quản lý thêm/sửa/xóa gói cho Gym Tháng (Nam/Nữ/Trẻ em), Gym PT và Yoga Tháng.
   - **Quản lý phôi thẻ (`TemplateSettingsScreen`)**: Xem trước 3 phôi mặc định (`1200 × 750`), kiểm tra khung ảnh cố định, thay đổi ảnh nền phôi hoặc khôi phục phôi gốc.
   - **Cài đặt xuất ảnh & PDF (`ExportSettingsScreen`)**: Tùy chọn độ phân giải PNG (`1200 × 750` chuẩn hoặc `2400 × 1500` Ultra HD) và khổ trang đơn PDF.
   - **Quản lý dữ liệu & Sao lưu (`BackupSettingsScreen`)**: Xuất toàn bộ dữ liệu + ảnh gốc ra file `.zip` và khôi phục từ file `.zip`.
   - **Giao diện (`ThemeSettingsDialog`)**: Chọn Sáng / Tối / Theo hệ thống.
   - **Hệ thống & Giới thiệu (`AboutSettingsDialog`)**: Thông tin phiên bản và trạng thái bộ nhớ.

#### Thiết kế Cơ sở dữ liệu (Room Database Schema & DataStore)

1. **Bảng `workout_packages` (`WorkoutPackageEntity`)**:
   - `id` (PrimaryKey), `cardType` (`GYM_MONTHLY`, `GYM_PT`, `YOGA_MONTHLY`), `targetGroup` (`NAM`, `NU`, `TRE_EM`, hoặc `null` cho PT/Yoga), `packageName` (VD: `"1 tháng"`, `"Gói 12 buổi"`), `durationMonths` (`Int?`), `totalSessions` (`Int?`), `priceVnd` (`Long`), `isDefaultSeed` (`Boolean`), `sortOrder` (`Int`).
   - **Khởi tạo mặc định lần đầu (`RoomDatabase.Callback` kết hợp cờ DataStore)**: Tự động nạp 12 gói Gym Tháng mặc định:
     - **Nam**: 1 tháng (`300.000đ`), 2 tháng (`550.000đ`), 3 tháng (`800.000đ`), 12 tháng (`3.000.000đ`).
     - **Nữ**: 1 tháng (`250.000đ`), 2 tháng (`450.000đ`), 3 tháng (`700.000đ`), 12 tháng (`2.800.000đ`).
     - **Trẻ em**: 1 tháng (`300.000đ`), 2 tháng (`500.000đ`), 3 tháng (`700.000đ`), 12 tháng (`2.500.000đ`).
     - **Yoga Tháng** và **Gym PT**: Để trống danh sách ban đầu (không tự suy đoán giá), hỗ trợ người dùng thêm mới trong Cài đặt hoặc nhập trực tiếp khi tạo thẻ.
2. **Bảng `member_photos` (`MemberPhotoEntity`)**:
   - `id` (PrimaryKey), `originalFilePath` (Đường dẫn file ảnh gốc nguyên bản trong `files/original_photos/`), `memberName` (Họ tên liên kết), `phoneNumber` (SĐT liên kết), `widthPx` (`Int`), `heightPx` (`Int`), `fileSizeBytes` (`Long`), `createdAtMillis` (`Long`).
3. **Bảng `membership_cards` (`MembershipCardEntity`)**:
   - `id` (PrimaryKey), `cardType` (`GYM_MONTHLY`, `GYM_PT`, `YOGA_MONTHLY`), `fullName` (`String`), `phoneNumber` (`String`), `targetGroup` (`String?` — chỉ có giá trị với `GYM_MONTHLY`), `packageNameSnapshot` (`String`), `startDateFormatted` (`String?` — `DD/MM/YYYY` cho Gym Tháng & Yoga Tháng, `null` cho Gym PT), `endDateFormatted` (`String?` — `DD/MM/YYYY` cho Gym Tháng & Yoga Tháng, `null` cho Gym PT), `totalPtSessions` (`Int?` — chỉ có giá trị với `GYM_PT`), `priceVnd` (`Long`), `originalPhotoId` (`Long?` — tham chiếu mềm, không Cascade Delete), `croppedPhotoPath` (`String`), `cropScale` (`Float`), `cropOffsetX` (`Float`), `cropOffsetY` (`Float`), `templateId` (`String`), `templateVersion` (`Int`), `brandNameSnapshot` (`String`), `brandContactSnapshot` (`String`), `brandLogoPathSnapshot` (`String?`), `createdAtMillis` (`Long`), `updatedAtMillis` (`Long`).
4. **Bảng `card_templates` (`CardTemplateEntity`)**:
   - Lưu thông số `TemplateMetadata` cho 3 phôi mặc định (`tpl_gym_monthly`, `tpl_gym_pt`, `tpl_yoga_monthly`): kích thước chuẩn `1200 × 750`, tọa độ tương đối (`0.0f..1.0f`) của khung ảnh hội viên (`slotX`, `slotY`, `slotWidth`, `slotHeight`, `cornerRadiusRatio`), tọa độ/màu sắc/cỡ chữ/độ rộng tối đa của từng trường văn bản, và đường dẫn ảnh nền tùy chỉnh nếu có.

#### Chiến lược Lưu trữ Ảnh Gốc & Khung Căn Chỉnh Cố Định

- **Bảo toàn ảnh gốc**: Khi thu ngân chụp ảnh từ CameraX hoặc chọn ảnh qua `PickVisualMedia`, hệ thống sao chép luồng byte gốc (`InputStream`) trực tiếp vào `context.filesDir/original_photos/IMG_<timestamp>.jpg` mà không nén lại hay cắt cúp, đồng thời tạo ngay bản ghi `MemberPhotoEntity`. Ngay cả khi người dùng hủy biểu mẫu tạo thẻ sau bước lưu ảnh gốc, bức ảnh vẫn tồn tại an toàn trong Thư viện Ảnh Hội Viên.
- **Khung căn chỉnh cố định (`Fixed-Slot Crop`)**: Khung ảnh hội viên được khóa theo đúng tỷ lệ `slotWidth / slotHeight` quy định trong `TemplateMetadata` (ví dụ khung chân dung bo góc `340 × 440 px` bên trái phôi `1200 × 750 px`). Người dùng chỉ phóng to và di chuyển bức ảnh bên trong cửa sổ cắt này; không thể kéo khung ảnh ra vị trí khác hoặc làm xô lệch bố cục phôi.

#### Kiến trúc Card Render Engine (`1200 × 750 px`)

1. Khởi tạo `Bitmap.createBitmap(1200, 750, Bitmap.Config.ARGB_8888)` độc lập với mật độ màn hình thiết bị.
2. Vẽ lớp nền phôi thẻ (nền đồ họa vector/gradient sắc nét của từng loại thẻ **Gym Monthly**, **Gym PT**, **Yoga Monthly** hoặc ảnh phôi tùy chỉnh) kèm hoa văn nhận diện, huy hiệu loại thẻ, Logo và tên thương hiệu **89 FITNESS & YOGA**.
3. Cắt vùng hiển thị (`Canvas.clipPath` với bo góc `cornerRadius`) tại đúng tọa độ khung ảnh cố định, áp dụng ma trận biến đổi (`cropScale`, `cropOffsetX`, `cropOffsetY`) lên ảnh gốc để vẽ ảnh chân dung hội viên sắc nét cùng viền khung trang trí.
4. Vẽ các trường văn bản thật bằng `TextPaint` chống răng cưa (`isAntiAlias = true`, `isSubpixelText = true`) với font tiếng Việt đầy đủ dấu:
   - Tự động kiểm tra quy tắc loại thẻ: **Gym Monthly** vẽ đủ Họ tên, Nhóm (Nam/Nữ/Trẻ em), SĐT, Loại thẻ, Ngày bắt đầu, Ngày hết hạn, Giá tiền; **Gym PT** chỉ vẽ Họ tên, SĐT, PERSONAL TRAINING, Tổng số buổi, Giá tiền (ẩn hoàn toàn ngày tháng); **Yoga Monthly** vẽ Họ tên, SĐT, YOGA MONTHLY, Ngày bắt đầu, Ngày hết hạn, Giá tiền (không có nhóm Nam/Nữ/Trẻ em).
   - Xử lý tên tiếng Việt dài vượt `maxTextWidth`: Tự động giảm nhẹ cỡ chữ trong ngưỡng đọc rõ (ví dụ từ `38px` xuống tối đa `28px`) hoặc xuống dòng/cắt dấu `…` an toàn để chữ không bao giờ tràn khỏi phôi.
5. Xuất `Bitmap` hoàn chỉnh thành file PNG chất lượng `100` vào `MediaStore.Images.Media` (`Pictures/89FitnessYoga`), hoặc vẽ trực tiếp lên trang `PdfDocument` (`1200 × 750`) để lưu PDF trang đơn sắc nét.

#### Chiến lược Xử lý Lỗi, Sao lưu & Migration

- **Xử lý lỗi lưu trữ & quyền truy cập**: Kiểm tra dung lượng trống trước khi lưu ảnh gốc/xuất ZIP; nếu ảnh gốc bị xóa hoặc hỏng file vật lý, hiển thị trạng thái báo lỗi rõ ràng trên thẻ và cho phép chọn lại ảnh mới mà không gây văng ứng dụng (crash). Nếu người dùng từ chối quyền Camera, tự động hướng dẫn chuyển sang chọn ảnh từ Thư viện thiết bị (`PickVisualMedia` không cần cấp quyền bộ nhớ).
- **An toàn Migration & Sao lưu**: Sử dụng lược đồ phiên bản Room rõ ràng kết hợp kiểm tra tính hợp lệ của tệp `backup.zip` (kiểm tra file manifest JSON và cấu trúc bảng trước khi khôi phục) để không bao giờ làm hỏng dữ liệu hiện có của quầy thu ngân.
