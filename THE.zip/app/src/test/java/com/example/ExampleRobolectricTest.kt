package com.example

import com.example.data.local.AppDatabase
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

    @Test
    fun `default templates preserve all 3 card types and 8_to_5 canvas`() {
        val templates = AppDatabase.defaultTemplates()
        assertEquals(3, templates.size)

        val gymMonthly = templates.first { it.cardType == CardType.GYM_MONTHLY.code }
        assertEquals(1200, gymMonthly.canvasWidth)
        assertEquals(750, gymMonthly.canvasHeight)
        assertEquals("#121316", gymMonthly.backgroundColorHex)
        assertEquals("#E11D48", gymMonthly.accentColorHex)

        val gymPt = templates.first { it.cardType == CardType.GYM_PT.code }
        assertEquals(1200, gymPt.canvasWidth)
        assertEquals(750, gymPt.canvasHeight)
        assertEquals("#111113", gymPt.backgroundColorHex)
        assertEquals("#F59E0B", gymPt.accentColorHex)

        val yogaMonthly = templates.first { it.cardType == CardType.YOGA_MONTHLY.code }
        assertEquals(1200, yogaMonthly.canvasWidth)
        assertEquals(750, yogaMonthly.canvasHeight)
        assertEquals("#064E3B", yogaMonthly.backgroundColorHex)
        assertEquals("#34D399", yogaMonthly.accentColorHex)

        assertTrue(gymMonthly.slotWidthRatio > 0f && gymMonthly.slotHeightRatio > 0f)
        assertEquals("Nam", TargetGroup.NAM.displayLabel)
        assertEquals("Nữ", TargetGroup.NU.displayLabel)
        assertEquals("Trẻ em", TargetGroup.TRE_EM.displayLabel)
    }
}
