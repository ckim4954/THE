package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.domain.model.CardDraft
import com.example.domain.model.CardType
import com.example.domain.model.ExportResolution
import com.example.domain.model.PhotoFrameShape
import com.example.domain.model.TemplateCatalog
import com.example.domain.model.TemplateCategory
import com.example.domain.util.FormattersAndValidators
import com.example.render.CardRenderEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `v4 multi-style template collection has 12 distinct templates across 4 categories and 6 compatible per card type`() {
        val entities = AppDatabase.defaultTemplates()
        assertEquals(12, entities.size)

        val allTemplates = TemplateCatalog.allBuiltInTemplates()
        assertEquals(12, allTemplates.size)

        val universal = allTemplates.filter { it.category == TemplateCategory.UNIVERSAL }
        val gym = allTemplates.filter { it.category == TemplateCategory.GYM }
        val yoga = allTemplates.filter { it.category == TemplateCategory.YOGA }
        val pt = allTemplates.filter { it.category == TemplateCategory.PT }

        assertEquals(3, universal.size)
        assertEquals(3, gym.size)
        assertEquals(3, yoga.size)
        assertEquals(3, pt.size)

        // Verify each CardType has 6 compatible templates (3 Universal + 3 category-specific)
        val gymCompatible = TemplateCatalog.getCompatibleTemplatesForCardType(allTemplates, CardType.GYM_MONTHLY)
        val yogaCompatible = TemplateCatalog.getCompatibleTemplatesForCardType(allTemplates, CardType.YOGA_MONTHLY)
        val ptCompatible = TemplateCatalog.getCompatibleTemplatesForCardType(allTemplates, CardType.GYM_PT)

        assertEquals(6, gymCompatible.size)
        assertEquals(6, yogaCompatible.size)
        assertEquals(6, ptCompatible.size)

        // Verify each CardType has exactly 1 default template initially
        assertEquals(1, allTemplates.count { CardType.GYM_MONTHLY in it.defaultForCardTypes })
        assertEquals(1, allTemplates.count { CardType.YOGA_MONTHLY in it.defaultForCardTypes })
        assertEquals(1, allTemplates.count { CardType.GYM_PT in it.defaultForCardTypes })

        // Verify all 12 templates use 1200x750 (8:5) base canvas, templateVersion 5, and neutral "HỌ VÀ TÊN" sample placeholder
        allTemplates.forEach { tpl ->
            assertEquals(1200, tpl.canvasWidth)
            assertEquals(750, tpl.canvasHeight)
            assertEquals(5, tpl.templateVersion)
            assertTrue(tpl.imageSlot.widthRatio > 0.15f)
            assertTrue(tpl.imageSlot.heightRatio > 0.25f)
            assertTrue(tpl.textFields.isNotEmpty())

            val samplePayload = CardRenderEngine.buildSamplePayload(tpl)
            assertEquals("HỌ VÀ TÊN", samplePayload.fullName)
            assertNotEquals("NGUYỄN VĂN HỘI VIÊN", samplePayload.fullName)
        }

        // Verify placeholder "HỌ VÀ TÊN" is rejected by member info step validator
        val placeholderDraft = CardDraft(
            cardType = CardType.GYM_MONTHLY,
            fullName = "HỌ VÀ TÊN",
            phoneNumber = "0912345678",
            durationMonthsText = "1",
            startDate = "01/11/2026",
            endDate = "01/12/2026",
            priceVndText = "300.000"
        )
        assertNotNull(FormattersAndValidators.validateMemberInfoStep(placeholderDraft))

        val usedShapes = allTemplates.map { it.imageSlot.shape }.toSet()
        assertTrue(usedShapes.containsAll(PhotoFrameShape.entries))

        // Verify 3 ExportResolution levels (1x, 1.5x, 2x)
        assertEquals(3, ExportResolution.entries.size)
        assertEquals(1200, ExportResolution.RES_1X.widthPx)
        assertEquals(750, ExportResolution.RES_1X.heightPx)
        assertEquals(1800, ExportResolution.RES_1_5X.widthPx)
        assertEquals(1125, ExportResolution.RES_1_5X.heightPx)
        assertEquals(2400, ExportResolution.RES_2X.widthPx)
        assertEquals(1500, ExportResolution.RES_2X.heightPx)
    }

    @Test
    fun `all drawable resources exist and all 12 templates render valid 8x5 bitmaps without errors`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        val requiredDrawables = listOf(
            "bg_art_universal_luxury_1794349441347",
            "bg_art_gym_athletic_1794349441059",
            "bg_art_yoga_wellness_1794349442642",
            "bg_art_pt_titanium_1794349443945",
            "img_app_logo_fg_1794306459132"
        )
        requiredDrawables.forEach { drawableName ->
            val resId = CardRenderEngine.resolveDrawableResId(context, drawableName)
            assertTrue("Drawable $drawableName must resolve to a valid resource ID", resId != 0)
        }

        TemplateCatalog.allBuiltInTemplates().forEach { template ->
            val payload = CardRenderEngine.buildSamplePayload(template)
            val bitmap = CardRenderEngine.renderCardBitmap(
                context = context,
                payload = payload,
                template = template,
                targetWidth = 600,
                targetHeight = 375
            )
            assertNotNull("Rendered bitmap for ${template.templateId} must not be null", bitmap)
            assertEquals(600, bitmap.width)
            assertEquals(375, bitmap.height)
        }
    }
}
