package com.example

import com.example.data.local.AppDatabase
import com.example.domain.model.CardDraft
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import com.example.domain.util.FormattersAndValidators
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `default gym monthly packages match exact master prompt price table`() {
        val defaults = AppDatabase.defaultGymMonthlyPackages()
        assertEquals(12, defaults.size)

        val nam = defaults.filter { it.targetGroup == TargetGroup.NAM.code }
        assertEquals(listOf(300_000L, 550_000L, 800_000L, 3_000_000L), nam.map { it.priceVnd })

        val nu = defaults.filter { it.targetGroup == TargetGroup.NU.code }
        assertEquals(listOf(250_000L, 450_000L, 700_000L, 2_800_000L), nu.map { it.priceVnd })

        val treEm = defaults.filter { it.targetGroup == TargetGroup.TRE_EM.code }
        assertEquals(listOf(300_000L, 500_000L, 700_000L, 2_500_000L), treEm.map { it.priceVnd })
    }

    @Test
    fun `vnd currency and dd_mm_yyyy date calculations work accurately`() {
        assertEquals("300.000đ", FormattersAndValidators.formatVnd(300_000L))
        assertEquals("3.000.000đ", FormattersAndValidators.formatVnd(3_000_000L))
        assertEquals(280_000L, FormattersAndValidators.parseVndInput("280.000"))

        assertTrue(FormattersAndValidators.isValidDateDdMmYyyy("15/11/2026"))
        assertEquals("15/12/2026", FormattersAndValidators.calculateEndDate("15/11/2026", 1))
        assertEquals("15/11/2027", FormattersAndValidators.calculateEndDate("15/11/2026", 12))
    }

    @Test
    fun `validation enforces per-card-type rules including PT without dates`() {
        val validPtDraft = CardDraft(
            cardType = CardType.GYM_PT,
            fullName = "Trần Minh Đức",
            phoneNumber = "0912345678",
            startDate = "", // PT has no dates
            endDate = "",
            totalPtSessions = "24",
            priceVndText = "6.000.000"
        )
        assertNull(FormattersAndValidators.validateStep1Info(validPtDraft))

        val invalidPtDraft = validPtDraft.copy(totalPtSessions = "0")
        assertNotNull(FormattersAndValidators.validateStep1Info(invalidPtDraft))

        val validYogaDraft = CardDraft(
            cardType = CardType.YOGA_MONTHLY,
            fullName = "Lê Thị Ngọc Ánh",
            phoneNumber = "0988776655",
            startDate = "01/11/2026",
            endDate = "01/12/2026",
            priceVndText = "500.000"
        )
        assertNull(FormattersAndValidators.validateStep1Info(validYogaDraft))
    }
}
