package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import com.example.domain.model.TextFieldSpec

@Database(
    entities = [
        WorkoutPackageEntity::class,
        MemberPhotoEntity::class,
        MembershipCardEntity::class,
        CardTemplateEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fitness_89_card_maker.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }

        fun defaultGymMonthlyPackages(): List<WorkoutPackageEntity> = listOf(
            // Nhóm Nam (1 tháng: 300.000đ, 2 tháng: 550.000đ, 3 tháng: 800.000đ, 12 tháng: 3.000.000đ)
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NAM.code,
                packageName = "1 tháng",
                durationMonths = 1,
                totalSessions = null,
                priceVnd = 300_000L,
                isDefaultSeed = true,
                sortOrder = 1
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NAM.code,
                packageName = "2 tháng",
                durationMonths = 2,
                totalSessions = null,
                priceVnd = 550_000L,
                isDefaultSeed = true,
                sortOrder = 2
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NAM.code,
                packageName = "3 tháng",
                durationMonths = 3,
                totalSessions = null,
                priceVnd = 800_000L,
                isDefaultSeed = true,
                sortOrder = 3
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NAM.code,
                packageName = "12 tháng",
                durationMonths = 12,
                totalSessions = null,
                priceVnd = 3_000_000L,
                isDefaultSeed = true,
                sortOrder = 4
            ),
            // Nhóm Nữ (1 tháng: 250.000đ, 2 tháng: 450.000đ, 3 tháng: 700.000đ, 12 tháng: 2.800.000đ)
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NU.code,
                packageName = "1 tháng",
                durationMonths = 1,
                totalSessions = null,
                priceVnd = 250_000L,
                isDefaultSeed = true,
                sortOrder = 1
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NU.code,
                packageName = "2 tháng",
                durationMonths = 2,
                totalSessions = null,
                priceVnd = 450_000L,
                isDefaultSeed = true,
                sortOrder = 2
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NU.code,
                packageName = "3 tháng",
                durationMonths = 3,
                totalSessions = null,
                priceVnd = 700_000L,
                isDefaultSeed = true,
                sortOrder = 3
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.NU.code,
                packageName = "12 tháng",
                durationMonths = 12,
                totalSessions = null,
                priceVnd = 2_800_000L,
                isDefaultSeed = true,
                sortOrder = 4
            ),
            // Nhóm Trẻ em (1 tháng: 300.000đ, 2 tháng: 500.000đ, 3 tháng: 700.000đ, 12 tháng: 2.500.000đ)
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.TRE_EM.code,
                packageName = "1 tháng",
                durationMonths = 1,
                totalSessions = null,
                priceVnd = 300_000L,
                isDefaultSeed = true,
                sortOrder = 1
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.TRE_EM.code,
                packageName = "2 tháng",
                durationMonths = 2,
                totalSessions = null,
                priceVnd = 500_000L,
                isDefaultSeed = true,
                sortOrder = 2
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.TRE_EM.code,
                packageName = "3 tháng",
                durationMonths = 3,
                totalSessions = null,
                priceVnd = 700_000L,
                isDefaultSeed = true,
                sortOrder = 3
            ),
            WorkoutPackageEntity(
                cardType = CardType.GYM_MONTHLY.code,
                targetGroup = TargetGroup.TRE_EM.code,
                packageName = "12 tháng",
                durationMonths = 12,
                totalSessions = null,
                priceVnd = 2_500_000L,
                isDefaultSeed = true,
                sortOrder = 4
            )
        )

        fun defaultTemplates(): List<CardTemplateEntity> = listOf(
            // 1. GYM MONTHLY (Carbon Black & Crimson Athletic)
            CardTemplateEntity(
                templateId = "tpl_gym_monthly",
                templateVersion = 1,
                cardType = CardType.GYM_MONTHLY.code,
                templateName = "Phôi Gym Tháng (Carbon & Crimson)",
                canvasWidth = 1200,
                canvasHeight = 750,
                backgroundColorHex = "#121316",
                secondaryColorHex = "#1F242D",
                accentColorHex = "#E11D48",
                textPrimaryHex = "#FFFFFF",
                textSecondaryHex = "#CBD5E1",
                textFieldsJson = CardTemplateEntity.encodeTextFields(
                    listOf(
                        TextFieldSpec("fullName", "Họ và tên", 0.37f, 0.31f, "Montserrat", 40f, 24f, "LEFT", "#FFFFFF", 0.56f),
                        TextFieldSpec("targetGroup", "Nhóm đối tượng", 0.37f, 0.43f, "Be Vietnam Pro", 26f, 20f, "LEFT", "#FDA4AF", 0.27f),
                        TextFieldSpec("phoneNumber", "Số điện thoại", 0.66f, 0.43f, "Be Vietnam Pro", 26f, 20f, "LEFT", "#E2E8F0", 0.27f),
                        TextFieldSpec("startDate", "Ngày bắt đầu", 0.37f, 0.60f, "Be Vietnam Pro", 28f, 20f, "LEFT", "#FFFFFF", 0.27f),
                        TextFieldSpec("endDate", "Ngày hết hạn", 0.66f, 0.60f, "Be Vietnam Pro", 28f, 20f, "LEFT", "#FDA4AF", 0.27f),
                        TextFieldSpec("priceVnd", "Giá tiền", 0.37f, 0.78f, "Montserrat", 36f, 24f, "LEFT", "#FBBF24", 0.56f)
                    )
                )
            ),
            // 2. GYM PERSONAL TRAINING (Obsidian & Luxe Gold)
            CardTemplateEntity(
                templateId = "tpl_gym_pt",
                templateVersion = 1,
                cardType = CardType.GYM_PT.code,
                templateName = "Phôi Gym PT (Obsidian & Gold)",
                canvasWidth = 1200,
                canvasHeight = 750,
                backgroundColorHex = "#111113",
                secondaryColorHex = "#1C1917",
                accentColorHex = "#F59E0B",
                textPrimaryHex = "#FFFFFF",
                textSecondaryHex = "#D6D3D1",
                textFieldsJson = CardTemplateEntity.encodeTextFields(
                    listOf(
                        TextFieldSpec("fullName", "Họ và tên", 0.37f, 0.33f, "Montserrat", 40f, 24f, "LEFT", "#FFFFFF", 0.56f),
                        TextFieldSpec("phoneNumber", "Số điện thoại", 0.37f, 0.48f, "Be Vietnam Pro", 28f, 20f, "LEFT", "#FDE68A", 0.56f),
                        TextFieldSpec("totalPtSessions", "Tổng số buổi PT", 0.37f, 0.64f, "Montserrat", 34f, 22f, "LEFT", "#F59E0B", 0.56f),
                        TextFieldSpec("priceVnd", "Giá tiền", 0.37f, 0.79f, "Montserrat", 36f, 24f, "LEFT", "#FFFFFF", 0.56f)
                    )
                )
            ),
            // 3. YOGA MONTHLY (Deep Emerald & Warm Lotus Cream)
            CardTemplateEntity(
                templateId = "tpl_yoga_monthly",
                templateVersion = 1,
                cardType = CardType.YOGA_MONTHLY.code,
                templateName = "Phôi Yoga Tháng (Emerald & Lotus)",
                canvasWidth = 1200,
                canvasHeight = 750,
                backgroundColorHex = "#064E3B",
                secondaryColorHex = "#065F46",
                accentColorHex = "#34D399",
                textPrimaryHex = "#FDFBF7",
                textSecondaryHex = "#A7F3D0",
                textFieldsJson = CardTemplateEntity.encodeTextFields(
                    listOf(
                        TextFieldSpec("fullName", "Họ và tên", 0.37f, 0.32f, "Montserrat", 40f, 24f, "LEFT", "#FDFBF7", 0.56f),
                        TextFieldSpec("phoneNumber", "Số điện thoại", 0.37f, 0.45f, "Be Vietnam Pro", 28f, 20f, "LEFT", "#D1FAE5", 0.56f),
                        TextFieldSpec("startDate", "Ngày bắt đầu", 0.37f, 0.61f, "Be Vietnam Pro", 28f, 20f, "LEFT", "#FFFFFF", 0.27f),
                        TextFieldSpec("endDate", "Ngày hết hạn", 0.66f, 0.61f, "Be Vietnam Pro", 28f, 20f, "LEFT", "#6EE7B7", 0.27f),
                        TextFieldSpec("priceVnd", "Giá tiền", 0.37f, 0.78f, "Montserrat", 36f, 24f, "LEFT", "#FDE68A", 0.56f)
                    )
                )
            )
        )
    }
}
