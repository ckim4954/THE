package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.local.AppDao
import com.example.data.local.AppDatabase
import com.example.data.local.CardTemplateEntity
import com.example.data.local.MemberPhotoEntity
import com.example.data.local.MembershipCardEntity
import com.example.data.local.WorkoutPackageEntity
import com.example.data.preferences.AppPreferencesRepository
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardType
import com.example.domain.model.ExportResolution
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateMetadata
import com.example.domain.model.ThemeMode
import com.example.render.CardRenderEngine
import com.example.render.CardRenderPayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class CardMakerRepository(
    private val context: Context,
    private val dao: AppDao,
    private val prefs: AppPreferencesRepository
) {
    val packagesFlow: Flow<List<WorkoutPackageEntity>> = dao.observeAllPackages()
    val memberPhotosFlow: Flow<List<MemberPhotoEntity>> = dao.observeAllMemberPhotos()
    val cardsFlow: Flow<List<MembershipCardEntity>> = dao.observeAllCards()
    val templatesFlow: Flow<List<TemplateMetadata>> = dao.observeAllTemplates().map { list ->
        list.map { it.toDomainModel() }
    }
    val brandConfigFlow: Flow<BrandConfig> = prefs.brandConfigFlow
    val themeModeFlow: Flow<ThemeMode> = prefs.themeModeFlow
    val exportResolutionFlow: Flow<ExportResolution> = prefs.exportResolutionFlow

    private val originalPhotosDir: File
        get() = File(context.filesDir, "original_photos").apply { mkdirs() }

    private val croppedPhotosDir: File
        get() = File(context.filesDir, "card_crops").apply { mkdirs() }

    private val brandAssetsDir: File
        get() = File(context.filesDir, "brand_assets").apply { mkdirs() }

    private val sharedCardsCacheDir: File
        get() = File(context.cacheDir, "shared_cards").apply { mkdirs() }

    suspend fun ensureInitialDataSeeded() = withContext(Dispatchers.IO) {
        if (dao.countTemplates() == 0) {
            dao.insertTemplates(AppDatabase.defaultTemplates())
        }
        if (!prefs.isInitialSeedDone()) {
            if (dao.countPackages() == 0) {
                dao.insertPackages(AppDatabase.defaultGymMonthlyPackages())
            }
            prefs.markInitialSeedDone()
        }
    }

    // --- Workout Package Operations ---
    suspend fun saveWorkoutPackage(pkg: WorkoutPackageEntity): Long = withContext(Dispatchers.IO) {
        if (pkg.id == 0L) {
            dao.insertPackage(pkg)
        } else {
            dao.updatePackage(pkg)
            pkg.id
        }
    }

    suspend fun deleteWorkoutPackage(id: Long) = withContext(Dispatchers.IO) {
        dao.deletePackageById(id)
    }

    suspend fun resetDefaultGymPackages() = withContext(Dispatchers.IO) {
        val current = dao.getAllPackagesSnapshot()
        current.filter { it.cardType == CardType.GYM_MONTHLY.code }.forEach {
            dao.deletePackageById(it.id)
        }
        dao.insertPackages(AppDatabase.defaultGymMonthlyPackages())
    }

    // --- Independent Original Member Photo Operations ---
    suspend fun saveOriginalPhotoFromUri(
        sourceUri: Uri,
        memberName: String,
        phoneNumber: String
    ): Result<MemberPhotoEntity> = withContext(Dispatchers.IO) {
        runCatching {
            val timestamp = System.currentTimeMillis()
            val destFile = File(originalPhotosDir, "ORIG_${timestamp}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            } ?: error("Không thể đọc tệp ảnh từ thiết bị.")

            saveOriginalPhotoFromFileInternal(destFile, memberName, phoneNumber)
        }
    }

    suspend fun saveOriginalPhotoFromCameraFile(
        cameraFile: File,
        memberName: String,
        phoneNumber: String
    ): Result<MemberPhotoEntity> = withContext(Dispatchers.IO) {
        runCatching {
            if (!cameraFile.exists() || cameraFile.length() == 0L) {
                error("Ảnh chụp không tồn tại hoặc bị lỗi.")
            }
            val timestamp = System.currentTimeMillis()
            val destFile = File(originalPhotosDir, "ORIG_CAM_${timestamp}.jpg")
            cameraFile.copyTo(destFile, overwrite = true)
            saveOriginalPhotoFromFileInternal(destFile, memberName, phoneNumber)
        }
    }

    private suspend fun saveOriginalPhotoFromFileInternal(
        destFile: File,
        memberName: String,
        phoneNumber: String
    ): MemberPhotoEntity {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(destFile.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            destFile.delete()
            error("Định dạng ảnh không hợp lệ hoặc tệp ảnh bị hỏng.")
        }
        val entity = MemberPhotoEntity(
            originalFilePath = destFile.absolutePath,
            memberName = memberName.trim(),
            phoneNumber = phoneNumber.trim(),
            widthPx = bounds.outWidth,
            heightPx = bounds.outHeight,
            fileSizeBytes = destFile.length(),
            createdAtMillis = System.currentTimeMillis()
        )
        val id = dao.insertMemberPhoto(entity)
        return entity.copy(id = id)
    }

    suspend fun updateMemberPhotoMetadata(
        photoId: Long,
        memberName: String,
        phoneNumber: String
    ) = withContext(Dispatchers.IO) {
        val existing = dao.getMemberPhotoById(photoId) ?: return@withContext
        dao.updateMemberPhoto(
            existing.copy(
                memberName = memberName.trim().ifEmpty { existing.memberName },
                phoneNumber = phoneNumber.trim().ifEmpty { existing.phoneNumber }
            )
        )
    }

    suspend fun deleteOriginalMemberPhoto(photo: MemberPhotoEntity) = withContext(Dispatchers.IO) {
        // Deleting original photo is an explicit separate operation; does NOT delete cards
        dao.deleteMemberPhotoById(photo.id)
        runCatching {
            val file = File(photo.originalFilePath)
            if (file.exists()) file.delete()
        }
    }

    // --- Membership Card Operations ---
    suspend fun saveMembershipCard(
        editingCardId: Long?,
        payload: CardRenderPayload,
        originalPhotoId: Long?,
        originalPhotoPath: String
    ): Result<MembershipCardEntity> = withContext(Dispatchers.IO) {
        runCatching {
            val templateEntity = dao.getTemplateForCardType(payload.cardType.code)
                ?: AppDatabase.defaultTemplates().first { it.cardType == payload.cardType.code }

            val now = System.currentTimeMillis()
            val cropFile = File(croppedPhotosDir, "CROP_${now}.png")
            val cropSuccess = CardRenderEngine.generateCroppedPhotoFile(
                sourcePhotoPath = originalPhotoPath,
                cropScale = payload.cropScale,
                cropOffsetX = payload.cropOffsetX,
                cropOffsetY = payload.cropOffsetY,
                outputFile = cropFile
            )
            val finalCroppedPath = if (cropSuccess) cropFile.absolutePath else originalPhotoPath

            // Also link member name & phone to original photo record if present
            if (originalPhotoId != null) {
                updateMemberPhotoMetadata(originalPhotoId, payload.fullName, payload.phoneNumber)
            }

            val existing = editingCardId?.let { dao.getCardById(it) }
            val entity = MembershipCardEntity(
                id = existing?.id ?: 0L,
                cardType = payload.cardType.code,
                fullName = payload.fullName.trim(),
                phoneNumber = payload.phoneNumber.trim(),
                targetGroup = if (payload.cardType == CardType.GYM_MONTHLY) payload.targetGroup?.code else null,
                packageNameSnapshot = payload.packageName.trim(),
                startDateFormatted = if (payload.cardType != CardType.GYM_PT) payload.startDateFormatted?.trim() else null,
                endDateFormatted = if (payload.cardType != CardType.GYM_PT) payload.endDateFormatted?.trim() else null,
                totalPtSessions = if (payload.cardType == CardType.GYM_PT) payload.totalPtSessions else null,
                priceVnd = payload.priceVnd,
                originalPhotoId = originalPhotoId,
                originalPhotoPathSnapshot = originalPhotoPath,
                croppedPhotoPath = finalCroppedPath,
                cropScale = payload.cropScale,
                cropOffsetX = payload.cropOffsetX,
                cropOffsetY = payload.cropOffsetY,
                templateId = templateEntity.templateId,
                templateVersion = templateEntity.templateVersion,
                brandNameSnapshot = payload.brandName,
                brandContactSnapshot = payload.brandContact,
                brandLogoPathSnapshot = payload.brandLogoPath,
                createdAtMillis = existing?.createdAtMillis ?: now,
                updatedAtMillis = now
            )

            val savedId = if (entity.id == 0L) {
                dao.insertCard(entity)
            } else {
                dao.updateCard(entity)
                entity.id
            }
            entity.copy(id = savedId)
        }
    }

    suspend fun deleteMembershipCardOnly(card: MembershipCardEntity) = withContext(Dispatchers.IO) {
        // Strictly DO NOT delete original member photo when deleting a card!
        dao.deleteCardById(card.id)
        runCatching {
            val cropFile = File(card.croppedPhotoPath)
            if (cropFile.exists() && cropFile.parentFile?.name == "card_crops") {
                cropFile.delete()
            }
        }
    }

    // --- Export PNG, Single-Page PDF & Direct Share ---
    suspend fun renderCardBitmap(payload: CardRenderPayload): Bitmap = withContext(Dispatchers.Default) {
        val template = getTemplateMetadataForType(payload.cardType)
        val resolution = prefs.getExportResolutionSnapshot()
        CardRenderEngine.renderCardBitmap(
            context = context,
            payload = payload,
            template = template,
            targetWidth = resolution.widthPx,
            targetHeight = resolution.heightPx
        )
    }

    suspend fun exportCardToGalleryPng(payload: CardRenderPayload): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = renderCardBitmap(payload)
                val safeName = sanitizeFileName(payload.fullName)
                val timeTag = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val fileName = "89FY_${payload.cardType.code}_${safeName}_$timeTag.png"

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(
                            MediaStore.Images.Media.RELATIVE_PATH,
                            "${Environment.DIRECTORY_PICTURES}/89FitnessYoga"
                        )
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?: error("Không thể khởi tạo file PNG trong bộ nhớ thiết bị.")
                    resolver.openOutputStream(uri)?.use { out ->
                        if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                            error("Không thể ghi dữ liệu ảnh PNG.")
                        }
                        out.flush()
                    } ?: error("Không thể mở luồng ghi PNG.")
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } else {
                    val dir = File(
                        context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                        "89FitnessYoga"
                    ).apply { mkdirs() }
                    val file = File(dir, fileName)
                    FileOutputStream(file).use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                        out.flush()
                    }
                }
                "Pictures/89FitnessYoga/$fileName"
            }
        }

    suspend fun exportCardToSinglePagePdf(payload: CardRenderPayload): Result<Uri> =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = renderCardBitmap(payload)
                val safeName = sanitizeFileName(payload.fullName)
                val timeTag = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val fileName = "89FY_${payload.cardType.code}_${safeName}_$timeTag.pdf"

                // Create Single-Page PDF matching exact 8:5 card aspect ratio (1200 x 750 pt)
                val pageWidth = 1200
                val pageHeight = 750
                val pdfDocument = PdfDocument()
                try {
                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    page.canvas.drawBitmap(
                        bitmap,
                        null,
                        RectF(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat()),
                        paint
                    )
                    pdfDocument.finishPage(page)

                    // Save to cache for immediate share/open AND to MediaStore Downloads on Q+
                    val cachePdfFile = File(sharedCardsCacheDir, fileName)
                    FileOutputStream(cachePdfFile).use { out ->
                        pdfDocument.writeTo(out)
                        out.flush()
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        runCatching {
                            val values = ContentValues().apply {
                                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                                put(
                                    MediaStore.Downloads.RELATIVE_PATH,
                                    "${Environment.DIRECTORY_DOWNLOADS}/89FitnessYoga"
                                )
                                put(MediaStore.Downloads.IS_PENDING, 1)
                            }
                            val resolver = context.contentResolver
                            val dlUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            if (dlUri != null) {
                                resolver.openOutputStream(dlUri)?.use { out ->
                                    cachePdfFile.inputStream().use { input -> input.copyTo(out) }
                                }
                                values.clear()
                                values.put(MediaStore.Downloads.IS_PENDING, 0)
                                resolver.update(dlUri, values, null, null)
                            }
                        }
                    }

                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        cachePdfFile
                    )
                } finally {
                    pdfDocument.close()
                }
            }
        }

    suspend fun prepareShareablePngUri(payload: CardRenderPayload): Result<Uri> =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = renderCardBitmap(payload)
                val safeName = sanitizeFileName(payload.fullName)
                val fileName = "89FY_SHARE_${safeName}_${System.currentTimeMillis()}.png"
                val shareFile = File(sharedCardsCacheDir, fileName)
                FileOutputStream(shareFile).use { out ->
                    if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                        error("Không thể tạo ảnh PNG để chia sẻ.")
                    }
                    out.flush()
                }
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    shareFile
                )
            }
        }

    // --- Brand & Template Configuration ---
    suspend fun getTemplateMetadataForType(cardType: CardType): TemplateMetadata =
        withContext(Dispatchers.IO) {
            val entity = dao.getTemplateForCardType(cardType.code)
                ?: AppDatabase.defaultTemplates().first { it.cardType == cardType.code }
            entity.toDomainModel()
        }

    suspend fun updateTemplateColorsAndBackground(
        cardType: CardType,
        backgroundColorHex: String,
        secondaryColorHex: String,
        accentColorHex: String,
        customBackgroundUri: Uri?,
        clearCustomBackground: Boolean = false
    ) = withContext(Dispatchers.IO) {
        val current = dao.getTemplateForCardType(cardType.code)
            ?: AppDatabase.defaultTemplates().first { it.cardType == cardType.code }

        val newBgPath = when {
            clearCustomBackground -> null
            customBackgroundUri != null -> {
                val file = File(brandAssetsDir, "tpl_bg_${cardType.code}_${System.currentTimeMillis()}.jpg")
                context.contentResolver.openInputStream(customBackgroundUri)?.use { input ->
                    FileOutputStream(file).use { out -> input.copyTo(out) }
                }
                file.absolutePath
            }
            else -> current.customBackgroundPath
        }

        dao.insertTemplate(
            current.copy(
                templateVersion = current.templateVersion + 1,
                backgroundColorHex = backgroundColorHex.trim(),
                secondaryColorHex = secondaryColorHex.trim(),
                accentColorHex = accentColorHex.trim(),
                customBackgroundPath = newBgPath
            )
        )
    }

    suspend fun resetAllTemplatesToDefault() = withContext(Dispatchers.IO) {
        dao.insertTemplates(AppDatabase.defaultTemplates())
    }

    suspend fun saveBrandSettings(
        brandName: String,
        contactInfo: String,
        newLogoUri: Uri?,
        removeLogo: Boolean
    ) = withContext(Dispatchers.IO) {
        val current = prefs.getBrandConfigSnapshot()
        val finalLogoPath = when {
            removeLogo -> null
            newLogoUri != null -> {
                val logoFile = File(brandAssetsDir, "brand_logo_${System.currentTimeMillis()}.png")
                context.contentResolver.openInputStream(newLogoUri)?.use { input ->
                    FileOutputStream(logoFile).use { out -> input.copyTo(out) }
                }
                logoFile.absolutePath
            }
            else -> current.customLogoPath
        }
        prefs.saveBrandConfig(
            BrandConfig(
                brandName = brandName,
                contactInfo = contactInfo,
                customLogoPath = finalLogoPath
            )
        )
    }

    suspend fun saveThemeMode(mode: ThemeMode) = prefs.saveThemeMode(mode)
    suspend fun saveExportResolution(res: ExportResolution) = prefs.saveExportResolution(res)

    // --- Full ZIP Backup & Restore (Data + Original Photos + Cropped Photos + Brand Assets) ---
    suspend fun exportFullBackupZip(destinationUri: Uri): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val packages = dao.getAllPackagesSnapshot()
                val photos = dao.getAllMemberPhotosSnapshot()
                val cards = dao.getAllCardsSnapshot()
                val templates = dao.getAllTemplatesSnapshot()
                val brand = prefs.getBrandConfigSnapshot()

                val rootJson = JSONObject().apply {
                    put("backupVersion", 1)
                    put("exportedAtMillis", System.currentTimeMillis())
                    put("brandName", brand.brandName)
                    put("brandContact", brand.contactInfo)
                    put("brandLogoFileName", brand.customLogoPath?.let { File(it).name } ?: "")

                    put("packages", JSONArray().apply {
                        packages.forEach { pkg ->
                            put(JSONObject().apply {
                                put("id", pkg.id)
                                put("cardType", pkg.cardType)
                                put("targetGroup", pkg.targetGroup ?: "")
                                put("packageName", pkg.packageName)
                                put("durationMonths", pkg.durationMonths ?: -1)
                                put("totalSessions", pkg.totalSessions ?: -1)
                                put("priceVnd", pkg.priceVnd)
                                put("isDefaultSeed", pkg.isDefaultSeed)
                                put("sortOrder", pkg.sortOrder)
                            })
                        }
                    })

                    put("photos", JSONArray().apply {
                        photos.forEach { p ->
                            put(JSONObject().apply {
                                put("id", p.id)
                                put("fileName", File(p.originalFilePath).name)
                                put("memberName", p.memberName)
                                put("phoneNumber", p.phoneNumber)
                                put("widthPx", p.widthPx)
                                put("heightPx", p.heightPx)
                                put("fileSizeBytes", p.fileSizeBytes)
                                put("createdAtMillis", p.createdAtMillis)
                            })
                        }
                    })

                    put("cards", JSONArray().apply {
                        cards.forEach { c ->
                            put(JSONObject().apply {
                                put("id", c.id)
                                put("cardType", c.cardType)
                                put("fullName", c.fullName)
                                put("phoneNumber", c.phoneNumber)
                                put("targetGroup", c.targetGroup ?: "")
                                put("packageNameSnapshot", c.packageNameSnapshot)
                                put("startDateFormatted", c.startDateFormatted ?: "")
                                put("endDateFormatted", c.endDateFormatted ?: "")
                                put("totalPtSessions", c.totalPtSessions ?: -1)
                                put("priceVnd", c.priceVnd)
                                put("originalPhotoId", c.originalPhotoId ?: -1L)
                                put("originalPhotoFileName", File(c.originalPhotoPathSnapshot).name)
                                put("croppedPhotoFileName", File(c.croppedPhotoPath).name)
                                put("cropScale", c.cropScale.toDouble())
                                put("cropOffsetX", c.cropOffsetX.toDouble())
                                put("cropOffsetY", c.cropOffsetY.toDouble())
                                put("templateId", c.templateId)
                                put("templateVersion", c.templateVersion)
                                put("brandNameSnapshot", c.brandNameSnapshot)
                                put("brandContactSnapshot", c.brandContactSnapshot)
                                put("brandLogoFileName", c.brandLogoPathSnapshot?.let { File(it).name } ?: "")
                                put("createdAtMillis", c.createdAtMillis)
                                put("updatedAtMillis", c.updatedAtMillis)
                            })
                        }
                    })

                    put("templates", JSONArray().apply {
                        templates.forEach { t ->
                            put(JSONObject().apply {
                                put("templateId", t.templateId)
                                put("templateVersion", t.templateVersion)
                                put("cardType", t.cardType)
                                put("templateName", t.templateName)
                                put("backgroundColorHex", t.backgroundColorHex)
                                put("secondaryColorHex", t.secondaryColorHex)
                                put("accentColorHex", t.accentColorHex)
                                put("textPrimaryHex", t.textPrimaryHex)
                                put("textSecondaryHex", t.textSecondaryHex)
                                put("textFieldsJson", t.textFieldsJson)
                            })
                        }
                    })
                }

                context.contentResolver.openOutputStream(destinationUri)?.use { rawOut ->
                    ZipOutputStream(BufferedOutputStream(rawOut)).use { zos ->
                        // 1. Write manifest.json
                        zos.putNextEntry(ZipEntry("backup_manifest.json"))
                        zos.write(rootJson.toString(2).toByteArray(Charsets.UTF_8))
                        zos.closeEntry()

                        // 2. Write original photos
                        originalPhotosDir.listFiles()?.forEach { file ->
                            if (file.isFile) {
                                addFileToZip(zos, file, "original_photos/${file.name}")
                            }
                        }

                        // 3. Write cropped photos
                        croppedPhotosDir.listFiles()?.forEach { file ->
                            if (file.isFile) {
                                addFileToZip(zos, file, "card_crops/${file.name}")
                            }
                        }

                        // 4. Write brand assets
                        brandAssetsDir.listFiles()?.forEach { file ->
                            if (file.isFile) {
                                addFileToZip(zos, file, "brand_assets/${file.name}")
                            }
                        }
                    }
                } ?: error("Không thể ghi tệp sao lưu ZIP.")

                "Đã sao lưu ${cards.size} thẻ, ${photos.size} ảnh gốc và ${packages.size} gói tập."
            }
        }

    suspend fun restoreFullBackupZip(sourceUri: Uri): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                var manifestJsonStr: String? = null
                context.contentResolver.openInputStream(sourceUri)?.use { rawIn ->
                    ZipInputStream(BufferedInputStream(rawIn)).use { zis ->
                        var entry: ZipEntry? = zis.nextEntry
                        while (entry != null) {
                            val name = entry.name
                            if (!entry.isDirectory && !name.contains("..")) {
                                when {
                                    name == "backup_manifest.json" -> {
                                        manifestJsonStr = zis.readBytes().toString(Charsets.UTF_8)
                                    }
                                    name.startsWith("original_photos/") -> {
                                        val outFile = File(originalPhotosDir, File(name).name)
                                        FileOutputStream(outFile).use { zis.copyTo(it) }
                                    }
                                    name.startsWith("card_crops/") -> {
                                        val outFile = File(croppedPhotosDir, File(name).name)
                                        FileOutputStream(outFile).use { zis.copyTo(it) }
                                    }
                                    name.startsWith("brand_assets/") -> {
                                        val outFile = File(brandAssetsDir, File(name).name)
                                        FileOutputStream(outFile).use { zis.copyTo(it) }
                                    }
                                }
                            }
                            zis.closeEntry()
                            entry = zis.nextEntry
                        }
                    }
                } ?: error("Không thể mở tệp ZIP để khôi phục.")

                val jsonStr = manifestJsonStr
                    ?: error("Tệp ZIP không hợp lệ (thiếu backup_manifest.json).")
                val root = JSONObject(jsonStr)

                val logoFileName = root.optString("brandLogoFileName")
                val restoredLogoPath = logoFileName.takeIf { it.isNotBlank() }?.let {
                    File(brandAssetsDir, it).takeIf { f -> f.exists() }?.absolutePath
                }
                prefs.saveBrandConfig(
                    BrandConfig(
                        brandName = root.optString("brandName", "89 FITNESS & YOGA"),
                        contactInfo = root.optString("brandContact", "Hội viên chính thức • 89 FITNESS & YOGA"),
                        customLogoPath = restoredLogoPath
                    )
                )

                // Restore packages
                val pkgArr = root.optJSONArray("packages") ?: JSONArray()
                val restoredPackages = mutableListOf<WorkoutPackageEntity>()
                for (i in 0 until pkgArr.length()) {
                    val o = pkgArr.getJSONObject(i)
                    restoredPackages.add(
                        WorkoutPackageEntity(
                            id = o.optLong("id", 0L),
                            cardType = o.optString("cardType", CardType.GYM_MONTHLY.code),
                            targetGroup = o.optString("targetGroup").takeIf { it.isNotBlank() },
                            packageName = o.optString("packageName"),
                            durationMonths = o.optInt("durationMonths", -1).takeIf { it > 0 },
                            totalSessions = o.optInt("totalSessions", -1).takeIf { it > 0 },
                            priceVnd = o.optLong("priceVnd", 0L),
                            isDefaultSeed = o.optBoolean("isDefaultSeed", false),
                            sortOrder = o.optInt("sortOrder", i)
                        )
                    )
                }
                if (restoredPackages.isNotEmpty()) {
                    dao.clearAllPackages()
                    dao.insertPackages(restoredPackages)
                }

                // Restore member photos
                val photoArr = root.optJSONArray("photos") ?: JSONArray()
                dao.clearAllMemberPhotos()
                for (i in 0 until photoArr.length()) {
                    val o = photoArr.getJSONObject(i)
                    val file = File(originalPhotosDir, o.optString("fileName"))
                    dao.insertMemberPhoto(
                        MemberPhotoEntity(
                            id = o.optLong("id", 0L),
                            originalFilePath = file.absolutePath,
                            memberName = o.optString("memberName"),
                            phoneNumber = o.optString("phoneNumber"),
                            widthPx = o.optInt("widthPx", 800),
                            heightPx = o.optInt("heightPx", 800),
                            fileSizeBytes = o.optLong("fileSizeBytes", file.length()),
                            createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis())
                        )
                    )
                }

                // Restore cards
                val cardArr = root.optJSONArray("cards") ?: JSONArray()
                dao.clearAllCards()
                for (i in 0 until cardArr.length()) {
                    val o = cardArr.getJSONObject(i)
                    val origFile = File(originalPhotosDir, o.optString("originalPhotoFileName"))
                    val cropFile = File(croppedPhotosDir, o.optString("croppedPhotoFileName"))
                    val cardLogoName = o.optString("brandLogoFileName")
                    val cardLogoPath = cardLogoName.takeIf { it.isNotBlank() }?.let {
                        File(brandAssetsDir, it).absolutePath
                    }
                    dao.insertCard(
                        MembershipCardEntity(
                            id = o.optLong("id", 0L),
                            cardType = o.optString("cardType", CardType.GYM_MONTHLY.code),
                            fullName = o.optString("fullName"),
                            phoneNumber = o.optString("phoneNumber"),
                            targetGroup = o.optString("targetGroup").takeIf { it.isNotBlank() },
                            packageNameSnapshot = o.optString("packageNameSnapshot"),
                            startDateFormatted = o.optString("startDateFormatted").takeIf { it.isNotBlank() },
                            endDateFormatted = o.optString("endDateFormatted").takeIf { it.isNotBlank() },
                            totalPtSessions = o.optInt("totalPtSessions", -1).takeIf { it > 0 },
                            priceVnd = o.optLong("priceVnd", 0L),
                            originalPhotoId = o.optLong("originalPhotoId", -1L).takeIf { it > 0L },
                            originalPhotoPathSnapshot = origFile.absolutePath,
                            croppedPhotoPath = if (cropFile.exists()) cropFile.absolutePath else origFile.absolutePath,
                            cropScale = o.optDouble("cropScale", 1.0).toFloat(),
                            cropOffsetX = o.optDouble("cropOffsetX", 0.0).toFloat(),
                            cropOffsetY = o.optDouble("cropOffsetY", 0.0).toFloat(),
                            templateId = o.optString("templateId", "tpl_gym_monthly"),
                            templateVersion = o.optInt("templateVersion", 1),
                            brandNameSnapshot = o.optString("brandNameSnapshot", "89 FITNESS & YOGA"),
                            brandContactSnapshot = o.optString("brandContactSnapshot"),
                            brandLogoPathSnapshot = cardLogoPath,
                            createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis()),
                            updatedAtMillis = o.optLong("updatedAtMillis", System.currentTimeMillis())
                        )
                    )
                }

                "Khôi phục thành công ${cardArr.length()} thẻ và ${photoArr.length()} ảnh hội viên."
            }
        }

    private fun addFileToZip(zos: ZipOutputStream, file: File, entryPath: String) {
        FileInputStream(file).use { fis ->
            BufferedInputStream(fis).use { origin ->
                val entry = ZipEntry(entryPath)
                zos.putNextEntry(entry)
                origin.copyTo(zos)
                zos.closeEntry()
            }
        }
    }

    private fun sanitizeFileName(raw: String): String {
        val normalized = java.text.Normalizer.normalize(raw.trim(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace('đ', 'd')
            .replace('Đ', 'D')
        return normalized.replace(Regex("[^a-zA-Z0-9]+"), "_").trim('_').ifEmpty { "HoiVien" }
    }
}
