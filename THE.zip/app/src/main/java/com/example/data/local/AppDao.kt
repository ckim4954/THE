package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- Workout Packages ---
    @Query("SELECT * FROM workout_packages ORDER BY cardType ASC, targetGroup ASC, sortOrder ASC, id ASC")
    fun observeAllPackages(): Flow<List<WorkoutPackageEntity>>

    @Query("SELECT * FROM workout_packages ORDER BY id ASC")
    suspend fun getAllPackagesSnapshot(): List<WorkoutPackageEntity>

    @Query("SELECT COUNT(*) FROM workout_packages")
    suspend fun countPackages(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackages(packages: List<WorkoutPackageEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackage(pkg: WorkoutPackageEntity): Long

    @Update
    suspend fun updatePackage(pkg: WorkoutPackageEntity)

    @Query("DELETE FROM workout_packages WHERE id = :id")
    suspend fun deletePackageById(id: Long)

    @Query("DELETE FROM workout_packages")
    suspend fun clearAllPackages()

    // --- Member Original Photos ---
    @Query("SELECT * FROM member_photos ORDER BY createdAtMillis DESC, id DESC")
    fun observeAllMemberPhotos(): Flow<List<MemberPhotoEntity>>

    @Query("SELECT * FROM member_photos ORDER BY createdAtMillis DESC, id DESC")
    suspend fun getAllMemberPhotosSnapshot(): List<MemberPhotoEntity>

    @Query("SELECT * FROM member_photos WHERE id = :id LIMIT 1")
    suspend fun getMemberPhotoById(id: Long): MemberPhotoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemberPhoto(photo: MemberPhotoEntity): Long

    @Update
    suspend fun updateMemberPhoto(photo: MemberPhotoEntity)

    @Query("DELETE FROM member_photos WHERE id = :id")
    suspend fun deleteMemberPhotoById(id: Long)

    @Query("DELETE FROM member_photos")
    suspend fun clearAllMemberPhotos()

    // --- Membership Cards ---
    @Query("SELECT * FROM membership_cards ORDER BY createdAtMillis DESC, id DESC")
    fun observeAllCards(): Flow<List<MembershipCardEntity>>

    @Query("SELECT * FROM membership_cards ORDER BY createdAtMillis DESC, id DESC")
    suspend fun getAllCardsSnapshot(): List<MembershipCardEntity>

    @Query("SELECT * FROM membership_cards WHERE id = :id LIMIT 1")
    suspend fun getCardById(id: Long): MembershipCardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: MembershipCardEntity): Long

    @Update
    suspend fun updateCard(card: MembershipCardEntity)

    @Query("DELETE FROM membership_cards WHERE id = :id")
    suspend fun deleteCardById(id: Long)

    @Query("DELETE FROM membership_cards")
    suspend fun clearAllCards()

    // --- Card Templates ---
    @Query("SELECT * FROM card_templates ORDER BY templateId ASC")
    fun observeAllTemplates(): Flow<List<CardTemplateEntity>>

    @Query("SELECT * FROM card_templates ORDER BY templateId ASC")
    suspend fun getAllTemplatesSnapshot(): List<CardTemplateEntity>

    @Query("SELECT * FROM card_templates WHERE cardType = :cardType LIMIT 1")
    suspend fun getTemplateForCardType(cardType: String): CardTemplateEntity?

    @Query("SELECT COUNT(*) FROM card_templates")
    suspend fun countTemplates(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplates(templates: List<CardTemplateEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: CardTemplateEntity)

    @Query("DELETE FROM card_templates")
    suspend fun clearAllTemplates()
}
