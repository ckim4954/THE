package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.CardType
import com.example.domain.model.ImageSlotSpec
import com.example.domain.model.TemplateMetadata
import com.example.domain.model.TextFieldSpec
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "workout_packages")
data class WorkoutPackageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val cardType: String, // GYM_MONTHLY, GYM_PT, YOGA_MONTHLY
    val targetGroup: String?, // NAM, NU, TRE_EM for GYM_MONTHLY; null for PT & YOGA
    val packageName: String,
    val durationMonths: Int?, // For GYM_MONTHLY & YOGA_MONTHLY
    val totalSessions: Int?, // For GYM_PT
    val priceVnd: Long,
    val isDefaultSeed: Boolean = false,
    val sortOrder: Int = 0
)

@Entity(tableName = "member_photos")
data class MemberPhotoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val originalFilePath: String,
    val memberName: String,
    val phoneNumber: String,
    val widthPx: Int,
    val heightPx: Int,
    val fileSizeBytes: Long,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "membership_cards")
data class MembershipCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val cardType: String, // GYM_MONTHLY, GYM_PT, YOGA_MONTHLY
    val fullName: String,
    val phoneNumber: String,
    val targetGroup: String?, // Only for GYM_MONTHLY (NAM, NU, TRE_EM)
    val packageNameSnapshot: String,
    val startDateFormatted: String?, // DD/MM/YYYY for GYM_MONTHLY & YOGA_MONTHLY; null for GYM_PT
    val endDateFormatted: String?, // DD/MM/YYYY for GYM_MONTHLY & YOGA_MONTHLY; null for GYM_PT
    val totalPtSessions: Int?, // Only for GYM_PT
    val priceVnd: Long,
    val originalPhotoId: Long?, // Soft reference: deleting card does NOT delete original photo
    val originalPhotoPathSnapshot: String,
    val croppedPhotoPath: String,
    val cropScale: Float = 1f,
    val cropOffsetX: Float = 0f,
    val cropOffsetY: Float = 0f,
    val templateId: String,
    val templateVersion: Int = 1,
    val brandNameSnapshot: String,
    val brandContactSnapshot: String,
    val brandLogoPathSnapshot: String?,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "card_templates")
data class CardTemplateEntity(
    @PrimaryKey val templateId: String,
    val templateVersion: Int = 1,
    val cardType: String,
    val templateName: String,
    val canvasWidth: Int = 1200,
    val canvasHeight: Int = 750,
    val backgroundColorHex: String,
    val secondaryColorHex: String,
    val accentColorHex: String,
    val textPrimaryHex: String,
    val textSecondaryHex: String,
    val customBackgroundPath: String? = null,
    val slotXRatio: Float = 0.055f,
    val slotYRatio: Float = 0.21f,
    val slotWidthRatio: Float = 0.275f,
    val slotHeightRatio: Float = 0.64f,
    val slotCornerRadiusRatio: Float = 0.03f,
    val slotCropMode: String = "CENTER_CROP_FIXED_FRAME",
    val textFieldsJson: String = "[]"
) {
    fun toDomainModel(): TemplateMetadata {
        val parsedFields = textFieldsJson
            .split(";;")
            .mapNotNull { row ->
                val parts = row.split("|")
                if (parts.size >= 11) {
                    TextFieldSpec(
                        fieldKey = parts[0],
                        labelVi = parts[1],
                        xRatio = parts[2].toFloatOrNull() ?: 0.37f,
                        yRatio = parts[3].toFloatOrNull() ?: 0.30f,
                        fontFamily = parts[4],
                        fontSizePx = parts[5].toFloatOrNull() ?: 32f,
                        minFontSizePx = parts[6].toFloatOrNull() ?: 22f,
                        textAlign = parts[7],
                        textColorHex = parts[8],
                        maxWidthRatio = parts[9].toFloatOrNull() ?: 0.56f,
                        overflowBehavior = parts[10],
                        isVisible = parts.getOrNull(11)?.toBooleanStrictOrNull() ?: true
                    )
                } else {
                    null
                }
            }

        return TemplateMetadata(
            templateId = templateId,
            templateVersion = templateVersion,
            cardType = CardType.fromCode(cardType),
            templateName = templateName,
            canvasWidth = canvasWidth,
            canvasHeight = canvasHeight,
            backgroundColorHex = backgroundColorHex,
            secondaryColorHex = secondaryColorHex,
            accentColorHex = accentColorHex,
            textPrimaryHex = textPrimaryHex,
            textSecondaryHex = textSecondaryHex,
            customBackgroundPath = customBackgroundPath,
            imageSlot = ImageSlotSpec(
                xRatio = slotXRatio,
                yRatio = slotYRatio,
                widthRatio = slotWidthRatio,
                heightRatio = slotHeightRatio,
                cornerRadiusRatio = slotCornerRadiusRatio,
                cropMode = slotCropMode
            ),
            textFields = parsedFields
        )
    }

    companion object {
        fun encodeTextFields(fields: List<TextFieldSpec>): String {
            return fields.joinToString(";;") { f ->
                listOf(
                    f.fieldKey,
                    f.labelVi,
                    f.xRatio,
                    f.yRatio,
                    f.fontFamily,
                    f.fontSizePx,
                    f.minFontSizePx,
                    f.textAlign,
                    f.textColorHex,
                    f.maxWidthRatio,
                    f.overflowBehavior,
                    f.isVisible
                ).joinToString("|")
            }
        }
    }
}
