package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PersonPin
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.MemberPhotoEntity
import com.example.data.local.MembershipCardEntity
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateMetadata
import com.example.domain.util.FormattersAndValidators
import com.example.render.CardRenderPayload
import com.example.ui.components.CardCanvasPreviewBox
import com.example.ui.viewmodel.LibrarySubTab
import java.io.File

@Composable
fun LibraryTabScreen(
    activeSubTab: LibrarySubTab,
    cards: List<MembershipCardEntity>,
    memberPhotos: List<MemberPhotoEntity>,
    templates: List<TemplateMetadata>,
    isBusy: Boolean,
    onSelectSubTab: (LibrarySubTab) -> Unit,
    onEditCard: (MembershipCardEntity) -> Unit,
    onBuildPayloadForSavedCard: (MembershipCardEntity) -> CardRenderPayload,
    onExportPng: (CardRenderPayload) -> Unit,
    onExportPdf: (CardRenderPayload) -> Unit,
    onShareCard: (CardRenderPayload) -> Unit,
    onDeleteCard: (MembershipCardEntity) -> Unit,
    onAddStandalonePhoto: (Uri, String, String) -> Unit,
    onUpdatePhotoInfo: (Long, String, String) -> Unit,
    onUsePhotoToCreateCard: (CardType, MemberPhotoEntity) -> Unit,
    onDeleteOriginalPhoto: (MemberPhotoEntity) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Two strictly separated Library sections selector
        Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val isCards = activeSubTab == LibrarySubTab.CREATED_CARDS
                Button(
                    onClick = { onSelectSubTab(LibrarySubTab.CREATED_CARDS) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("lib_tab_cards"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCards) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isCards) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                ) {
                    Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Thẻ đã tạo (${cards.size})", fontWeight = FontWeight.Bold)
                }

                val isPhotos = activeSubTab == LibrarySubTab.MEMBER_PHOTOS
                Button(
                    onClick = { onSelectSubTab(LibrarySubTab.MEMBER_PHOTOS) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("lib_tab_photos"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPhotos) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isPhotos) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ảnh hội viên (${memberPhotos.size})", fontWeight = FontWeight.Bold)
                }
            }
        }

        when (activeSubTab) {
            LibrarySubTab.CREATED_CARDS -> {
                CreatedCardsSection(
                    cards = cards,
                    templates = templates,
                    isBusy = isBusy,
                    onEditCard = onEditCard,
                    onBuildPayload = onBuildPayloadForSavedCard,
                    onExportPng = onExportPng,
                    onExportPdf = onExportPdf,
                    onShareCard = onShareCard,
                    onDeleteCard = onDeleteCard
                )
            }
            LibrarySubTab.MEMBER_PHOTOS -> {
                MemberPhotosSection(
                    photos = memberPhotos,
                    onAddStandalonePhoto = onAddStandalonePhoto,
                    onUpdatePhotoInfo = onUpdatePhotoInfo,
                    onUsePhotoToCreateCard = onUsePhotoToCreateCard,
                    onDeleteOriginalPhoto = onDeleteOriginalPhoto
                )
            }
        }
    }
}

@Composable
private fun CreatedCardsSection(
    cards: List<MembershipCardEntity>,
    templates: List<TemplateMetadata>,
    isBusy: Boolean,
    onEditCard: (MembershipCardEntity) -> Unit,
    onBuildPayload: (MembershipCardEntity) -> CardRenderPayload,
    onExportPng: (CardRenderPayload) -> Unit,
    onExportPdf: (CardRenderPayload) -> Unit,
    onShareCard: (CardRenderPayload) -> Unit,
    onDeleteCard: (MembershipCardEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterType by remember { mutableStateOf<CardType?>(null) }
    var viewingCard by remember { mutableStateOf<MembershipCardEntity?>(null) }
    var deletingCard by remember { mutableStateOf<MembershipCardEntity?>(null) }

    val filteredCards = remember(cards, searchQuery, filterType) {
        cards.filter { card ->
            val matchesType = filterType == null || card.cardType == filterType?.code
            val q = searchQuery.trim()
            val matchesQuery = q.isEmpty() ||
                card.fullName.contains(q, ignoreCase = true) ||
                card.phoneNumber.contains(q, ignoreCase = true)
            matchesType && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Tìm thẻ theo họ tên hoặc số điện thoại") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Xóa tìm kiếm")
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_cards_input")
        )

        // Filter Chips by Card Type
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filterType == null,
                onClick = { filterType = null },
                label = { Text("Tất cả (${cards.size})") },
                modifier = Modifier.testTag("filter_card_all")
            )
            CardType.entries.forEach { type ->
                FilterChip(
                    selected = filterType == type,
                    onClick = { filterType = if (filterType == type) null else type },
                    label = { Text(type.displayTitle) },
                    modifier = Modifier.testTag("filter_card_${type.code}")
                )
            }
        }

        if (filteredCards.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Badge,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Chưa có thẻ nào trong danh sách",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Các thẻ hội viên sau khi lưu sẽ hiển thị tại đây để tra cứu, xuất PNG/PDF hoặc chia sẻ lại.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredCards, key = { it.id }) { card ->
                    val type = CardType.fromCode(card.cardType)
                    val group = TargetGroup.fromCode(card.targetGroup)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("card_library_item_${card.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewingCard = card },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AsyncImage(
                                    model = File(card.croppedPhotoPath),
                                    contentDescription = card.fullName,
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF1E293B)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = card.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val subLine = buildString {
                                        append(type.displayTitle)
                                        if (type == CardType.GYM_MONTHLY && group != null) {
                                            append(" (${group.displayLabel})")
                                        }
                                        append(" • SĐT: ${card.phoneNumber}")
                                    }
                                    Text(
                                        text = subLine,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    val detailLine = when (type) {
                                        CardType.GYM_PT -> "Tổng số buổi: ${card.totalPtSessions ?: 0} buổi PT"
                                        else -> "${card.startDateFormatted ?: ""} → ${card.endDateFormatted ?: ""}"
                                    }
                                    Text(
                                        text = detailLine,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Text(
                                    text = FormattersAndValidators.formatVnd(card.priceVnd),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                TextButton(onClick = { viewingCard = card }) {
                                    Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Xem")
                                }
                                TextButton(onClick = { onEditCard(card) }) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Sửa")
                                }
                                TextButton(
                                    onClick = { onExportPng(onBuildPayload(card)) },
                                    enabled = !isBusy
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("PNG")
                                }
                                TextButton(
                                    onClick = { onShareCard(onBuildPayload(card)) },
                                    enabled = !isBusy
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Chia sẻ")
                                }
                                IconButton(onClick = { deletingCard = card }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Xóa thẻ",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // View Full Rendered Card Modal
    if (viewingCard != null) {
        val card = viewingCard!!
        val payload = onBuildPayload(card)
        val tpl = templates.firstOrNull { it.cardType == payload.cardType } ?: templates.first()

        AlertDialog(
            onDismissRequest = { viewingCard = null },
            title = { Text("Xem thẻ: ${card.fullName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CardCanvasPreviewBox(payload = payload, template = tpl)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onExportPng(payload) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Lưu PNG")
                        }
                        OutlinedButton(
                            onClick = { onExportPdf(payload) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Xuất PDF")
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewingCard = null
                        onEditCard(card)
                    }
                ) {
                    Text("Chỉnh sửa thẻ")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewingCard = null }) {
                    Text("Đóng")
                }
            }
        )
    }

    // Confirm Delete Card Only (Original Photo Preserved)
    if (deletingCard != null) {
        val card = deletingCard!!
        AlertDialog(
            onDismissRequest = { deletingCard = null },
            title = { Text("Xác nhận xóa thẻ đã tạo") },
            text = {
                Text("Bạn có chắc chắn muốn xóa bản ghi thẻ của '${card.fullName}' khỏi Thư viện Thẻ?\n\nLưu ý: Ảnh gốc của hội viên trong Thư viện Ảnh Hội Viên sẽ KHÔNG bị xóa.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteCard(card)
                        deletingCard = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Xóa thẻ")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingCard = null }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun MemberPhotosSection(
    photos: List<MemberPhotoEntity>,
    onAddStandalonePhoto: (Uri, String, String) -> Unit,
    onUpdatePhotoInfo: (Long, String, String) -> Unit,
    onUsePhotoToCreateCard: (CardType, MemberPhotoEntity) -> Unit,
    onDeleteOriginalPhoto: (MemberPhotoEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedPhotoForDetail by remember { mutableStateOf<MemberPhotoEntity?>(null) }
    var photoForNewCard by remember { mutableStateOf<MemberPhotoEntity?>(null) }
    var deletingPhoto by remember { mutableStateOf<MemberPhotoEntity?>(null) }
    var pendingStandaloneUri by remember { mutableStateOf<Uri?>(null) }

    val standalonePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pendingStandaloneUri = uri
        }
    }

    val filteredPhotos = remember(photos, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) photos
        else photos.filter {
            it.memberName.contains(q, ignoreCase = true) ||
                it.phoneNumber.contains(q, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Tìm ảnh theo họ tên hoặc SĐT") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("search_photos_input")
            )
            Button(
                onClick = {
                    standalonePicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier
                    .height(54.dp)
                    .testTag("btn_add_standalone_photo"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.AddAPhoto, contentDescription = "Thêm ảnh gốc")
            }
        }

        if (filteredPhotos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Thư viện Ảnh Hội Viên đang trống",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Mọi ảnh gốc khi chụp hoặc chọn sẽ được lưu độc lập tại đây để tái sử dụng cho nhiều lần làm thẻ.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredPhotos, key = { it.id }) { photo ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedPhotoForDetail = photo }
                            .testTag("member_photo_card_${photo.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column {
                            AsyncImage(
                                model = File(photo.originalFilePath),
                                contentDescription = photo.memberName,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(0.85f)
                                    .background(Color(0xFF1E293B)),
                                contentScale = ContentScale.Crop
                            )
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = photo.memberName.ifBlank { "Chưa gắn họ tên" },
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = photo.phoneNumber.ifBlank { "Chưa có SĐT" },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { photoForNewCard = photo },
                                        modifier = Modifier.testTag("use_photo_btn_${photo.id}")
                                    ) {
                                        Icon(Icons.Default.PersonPin, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Tạo thẻ")
                                    }
                                    IconButton(
                                        onClick = { deletingPhoto = photo },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Xóa ảnh gốc",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Standalone Original Photo Dialog
    if (pendingStandaloneUri != null) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pendingStandaloneUri = null },
            title = { Text("Lưu ảnh gốc vào Thư viện Ảnh") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Họ và tên hội viên (Tùy chọn)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Số điện thoại (Tùy chọn)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddStandalonePhoto(pendingStandaloneUri!!, name, phone)
                        pendingStandaloneUri = null
                    }
                ) {
                    Text("Lưu ảnh gốc")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingStandaloneUri = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // View Large Original Photo & Edit Linked Info Dialog
    if (selectedPhotoForDetail != null) {
        val photo = selectedPhotoForDetail!!
        var editName by remember(photo) { mutableStateOf(photo.memberName) }
        var editPhone by remember(photo) { mutableStateOf(photo.phoneNumber) }

        AlertDialog(
            onDismissRequest = { selectedPhotoForDetail = null },
            title = { Text("Ảnh gốc hội viên (${photo.widthPx} × ${photo.heightPx} px)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AsyncImage(
                        model = File(photo.originalFilePath),
                        contentDescription = photo.memberName,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black),
                        contentScale = ContentScale.Fit
                    )
                    Text(
                        text = "Thời điểm lưu: ${FormattersAndValidators.formatTimestampDateTime(photo.createdAtMillis)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Họ tên liên kết") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = { editPhone = it },
                        label = { Text("Số điện thoại liên kết") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            selectedPhotoForDetail = null
                            photoForNewCard = photo.copy(memberName = editName, phoneNumber = editPhone)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Sử dụng ảnh này để tạo thẻ mới")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdatePhotoInfo(photo.id, editName, editPhone)
                        selectedPhotoForDetail = null
                    }
                ) {
                    Text("Lưu thông tin")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedPhotoForDetail = null }) {
                    Text("Đóng")
                }
            }
        )
    }

    // Choose Card Type when reusing an original photo
    if (photoForNewCard != null) {
        val photo = photoForNewCard!!
        AlertDialog(
            onDismissRequest = { photoForNewCard = null },
            title = { Text("Chọn loại thẻ muốn tạo từ ảnh này") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CardType.entries.forEach { type ->
                        Button(
                            onClick = {
                                photoForNewCard = null
                                onUsePhotoToCreateCard(type, photo)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(type.displayTitle, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { photoForNewCard = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Confirm Delete Original Photo Separately
    if (deletingPhoto != null) {
        val photo = deletingPhoto!!
        AlertDialog(
            onDismissRequest = { deletingPhoto = null },
            title = { Text("Xác nhận xóa ảnh gốc hội viên") },
            text = {
                Text("Bạn có chắc chắn muốn xóa vĩnh viễn ảnh gốc của '${photo.memberName.ifBlank { "Hội viên" }}' khỏi Thư viện Ảnh?\n\nCác thẻ đã tạo trước đó vẫn giữ bản ảnh đã cắt riêng của thẻ.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteOriginalPhoto(photo)
                        deletingPhoto = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Xóa ảnh gốc")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingPhoto = null }) {
                    Text("Hủy")
                }
            }
        )
    }
}
