package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.MemberPhotoEntity
import com.example.data.local.MembershipCardEntity
import com.example.data.local.WorkoutPackageEntity
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardDraft
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateMetadata
import com.example.domain.util.FormattersAndValidators
import com.example.render.CardRenderPayload
import com.example.ui.components.CameraCaptureDialog
import com.example.ui.components.CardCanvasPreviewBox
import com.example.ui.components.FixedFrameCropper
import com.example.ui.viewmodel.BottomNavTab
import java.io.File

@Composable
fun CreateCardTabScreen(
    wizardStep: Int?,
    draft: CardDraft,
    packages: List<WorkoutPackageEntity>,
    memberPhotos: List<MemberPhotoEntity>,
    recentCards: List<MembershipCardEntity>,
    templates: List<TemplateMetadata>,
    brandConfig: BrandConfig,
    hasUnsavedChanges: Boolean,
    isCardSavedToLibrary: Boolean,
    isBusy: Boolean,
    onStartNewCard: (CardType) -> Unit,
    onNavigateTab: (BottomNavTab) -> Unit,
    onEditExistingCard: (MembershipCardEntity) -> Unit,
    onExitWizard: () -> Unit,
    onGoToStep: (Int) -> Unit,
    onTargetGroupChanged: (TargetGroup) -> Unit,
    onPackageSelected: (WorkoutPackageEntity) -> Unit,
    onUpdateDraftFields: (
        fullName: String?,
        phoneNumber: String?,
        packageName: String?,
        startDate: String?,
        endDate: String?,
        totalPtSessions: String?,
        priceVndText: String?
    ) -> Unit,
    onPhotoPickedFromDevice: (Uri) -> Unit,
    onPhotoCapturedFromCamera: (File) -> Unit,
    onSelectExistingMemberPhoto: (MemberPhotoEntity) -> Unit,
    onUpdateCropTransform: (Float, Float, Float) -> Unit,
    onResetCropTransform: () -> Unit,
    onBuildDraftPayload: () -> CardRenderPayload,
    onSaveCardToLibrary: () -> Unit,
    onExportPng: (CardRenderPayload) -> Unit,
    onExportPdf: (CardRenderPayload) -> Unit,
    onShareCard: (CardRenderPayload) -> Unit,
    onPostError: (String) -> Unit
) {
    if (wizardStep == null) {
        CreateCardHomeContent(
            brandConfig = brandConfig,
            recentCards = recentCards.take(5),
            onStartNewCard = onStartNewCard,
            onNavigateTab = onNavigateTab,
            onEditExistingCard = onEditExistingCard
        )
    } else {
        CardCreationWizardContent(
            step = wizardStep,
            draft = draft,
            packages = packages,
            memberPhotos = memberPhotos,
            templates = templates,
            hasUnsavedChanges = hasUnsavedChanges,
            isCardSavedToLibrary = isCardSavedToLibrary,
            isBusy = isBusy,
            onExitWizard = onExitWizard,
            onGoToStep = onGoToStep,
            onTargetGroupChanged = onTargetGroupChanged,
            onPackageSelected = onPackageSelected,
            onUpdateDraftFields = onUpdateDraftFields,
            onPhotoPickedFromDevice = onPhotoPickedFromDevice,
            onPhotoCapturedFromCamera = onPhotoCapturedFromCamera,
            onSelectExistingMemberPhoto = onSelectExistingMemberPhoto,
            onUpdateCropTransform = onUpdateCropTransform,
            onResetCropTransform = onResetCropTransform,
            onBuildDraftPayload = onBuildDraftPayload,
            onSaveCardToLibrary = onSaveCardToLibrary,
            onExportPng = onExportPng,
            onExportPdf = onExportPdf,
            onShareCard = onShareCard,
            onPostError = onPostError
        )
    }
}

@Composable
private fun CreateCardHomeContent(
    brandConfig: BrandConfig,
    recentCards: List<MembershipCardEntity>,
    onStartNewCard: (CardType) -> Unit,
    onNavigateTab: (BottomNavTab) -> Unit,
    onEditExistingCard: (MembershipCardEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Brand Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF121316)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val customLogo = brandConfig.customLogoPath?.takeIf { File(it).exists() }
                    if (customLogo != null) {
                        AsyncImage(
                            model = File(customLogo),
                            contentDescription = "Logo phòng tập",
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.img_app_logo_fg_1794306459132),
                            contentDescription = "Logo 89 FITNESS & YOGA",
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = brandConfig.brandName,
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tạo thẻ hội viên kỹ thuật số tại quầy",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "CHỌN LOẠI THẺ CẦN TẠO",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            CardTypeActionCard(
                cardType = CardType.GYM_MONTHLY,
                accentColor = Color(0xFFE11D48),
                icon = Icons.Default.FitnessCenter,
                testTag = "select_card_gym_monthly",
                onClick = { onStartNewCard(CardType.GYM_MONTHLY) }
            )
        }

        item {
            CardTypeActionCard(
                cardType = CardType.GYM_PT,
                accentColor = Color(0xFFD97706),
                icon = Icons.Default.SportsGymnastics,
                testTag = "select_card_gym_pt",
                onClick = { onStartNewCard(CardType.GYM_PT) }
            )
        }

        item {
            CardTypeActionCard(
                cardType = CardType.YOGA_MONTHLY,
                accentColor = Color(0xFF059669),
                icon = Icons.Default.SelfImprovement,
                testTag = "select_card_yoga_monthly",
                onClick = { onStartNewCard(CardType.YOGA_MONTHLY) }
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { onNavigateTab(BottomNavTab.LIBRARY) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("home_shortcut_library"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Collections, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Thư viện")
                }
                OutlinedButton(
                    onClick = { onNavigateTab(BottomNavTab.SETTINGS) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("home_shortcut_settings"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Cài đặt")
                }
            }
        }

        if (recentCards.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "THẺ VỪA TẠO GẦN ĐÂY",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { onNavigateTab(BottomNavTab.LIBRARY) }) {
                        Text("Xem tất cả")
                    }
                }
            }

            items(recentCards, key = { it.id }) { card ->
                val type = CardType.fromCode(card.cardType)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onEditExistingCard(card) }
                        .testTag("recent_card_item_${card.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = File(card.croppedPhotoPath),
                            contentDescription = card.fullName,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF1E293B)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = card.fullName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${type.displayTitle} • ${card.phoneNumber}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = FormattersAndValidators.formatVnd(card.priceVnd),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
private fun CardTypeActionCard(
    cardType: CardType,
    accentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(accentColor.copy(alpha = 0.14f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = cardType.displayTitle,
                    tint = accentColor,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = cardType.displayTitle.uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = cardType.subtitleVi,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Mở biểu mẫu",
                tint = accentColor
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun CardCreationWizardContent(
    step: Int,
    draft: CardDraft,
    packages: List<WorkoutPackageEntity>,
    memberPhotos: List<MemberPhotoEntity>,
    templates: List<TemplateMetadata>,
    hasUnsavedChanges: Boolean,
    isCardSavedToLibrary: Boolean,
    isBusy: Boolean,
    onExitWizard: () -> Unit,
    onGoToStep: (Int) -> Unit,
    onTargetGroupChanged: (TargetGroup) -> Unit,
    onPackageSelected: (WorkoutPackageEntity) -> Unit,
    onUpdateDraftFields: (
        fullName: String?,
        phoneNumber: String?,
        packageName: String?,
        startDate: String?,
        endDate: String?,
        totalPtSessions: String?,
        priceVndText: String?
    ) -> Unit,
    onPhotoPickedFromDevice: (Uri) -> Unit,
    onPhotoCapturedFromCamera: (File) -> Unit,
    onSelectExistingMemberPhoto: (MemberPhotoEntity) -> Unit,
    onUpdateCropTransform: (Float, Float, Float) -> Unit,
    onResetCropTransform: () -> Unit,
    onBuildDraftPayload: () -> CardRenderPayload,
    onSaveCardToLibrary: () -> Unit,
    onExportPng: (CardRenderPayload) -> Unit,
    onExportPdf: (CardRenderPayload) -> Unit,
    onShareCard: (CardRenderPayload) -> Unit,
    onPostError: (String) -> Unit
) {
    var showUnsavedExitDialog by remember { mutableStateOf(false) }
    var showConfirmSaveCardDialog by remember { mutableStateOf(false) }
    var showCameraDialog by remember { mutableStateOf(false) }
    var showMemberPhotoPickerDialog by remember { mutableStateOf(false) }
    var datePickerTargetField by remember { mutableStateOf<String?>(null) } // "start" or "end"

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPhotoPickedFromDevice(uri)
        }
    }

    val handleBackNavigation = {
        when {
            step > 1 -> onGoToStep(step - 1)
            hasUnsavedChanges && !isCardSavedToLibrary -> showUnsavedExitDialog = true
            else -> onExitWizard()
        }
    }

    BackHandler(onBack = handleBackNavigation)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
    ) {
        // Wizard Top Bar + Step Indicator
        Surface(
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = handleBackNavigation,
                        modifier = Modifier.testTag("wizard_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Quay lại"
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (draft.editingCardId == null) {
                                "Tạo thẻ: ${draft.cardType.displayTitle}"
                            } else {
                                "Chỉnh sửa thẻ: ${draft.cardType.displayTitle}"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = draft.cardType.cardBadgeText,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WizardStepPill(
                        stepNumber = 1,
                        label = "1. Thông tin",
                        currentStep = step,
                        onClick = { onGoToStep(1) },
                        modifier = Modifier.weight(1f)
                    )
                    WizardStepPill(
                        stepNumber = 2,
                        label = "2. Ảnh",
                        currentStep = step,
                        onClick = { onGoToStep(2) },
                        modifier = Modifier.weight(1f)
                    )
                    WizardStepPill(
                        stepNumber = 3,
                        label = "3. Xem trước",
                        currentStep = step,
                        onClick = { onGoToStep(3) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Step Content
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (step) {
                1 -> {
                    // STEP 1: INFORMATION FORM
                    if (draft.cardType == CardType.GYM_MONTHLY) {
                        Text(
                            text = "Nhóm đối tượng (Hiển thị trên thẻ Gym tháng)",
                            style = MaterialTheme.typography.labelLarge
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            TargetGroup.entries.forEach { group ->
                                val selected = draft.targetGroup == group
                                FilterChip(
                                    selected = selected,
                                    onClick = { onTargetGroupChanged(group) },
                                    label = {
                                        Text(
                                            text = group.displayLabel,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("target_group_chip_${group.code}")
                                )
                            }
                        }
                    }

                    // Package Selector for current CardType (+ TargetGroup if Gym Monthly)
                    val availablePackages = packages.filter { pkg ->
                        pkg.cardType == draft.cardType.code &&
                            (draft.cardType != CardType.GYM_MONTHLY || pkg.targetGroup == draft.targetGroup.code)
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Chọn gói tập cấu hình sẵn (Tự động điền - vẫn có thể sửa)",
                            style = MaterialTheme.typography.labelLarge
                        )
                        if (availablePackages.isEmpty()) {
                            Text(
                                text = "Chưa có gói cố định trong Cài đặt cho mục này. Bạn có thể nhập trực tiếp thông tin bên dưới hoặc thêm gói trong Cài đặt.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                availablePackages.forEach { pkg ->
                                    val isSelected = draft.selectedPackageId == pkg.id
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { onPackageSelected(pkg) },
                                        label = {
                                            Text(
                                                text = "${pkg.packageName} • ${FormattersAndValidators.formatVnd(pkg.priceVnd)}"
                                            )
                                        },
                                        modifier = Modifier.testTag("pkg_chip_${pkg.id}")
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = draft.fullName,
                        onValueChange = { onUpdateDraftFields(it, null, null, null, null, null, null) },
                        label = { Text("Họ và tên hội viên *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_full_name")
                    )

                    OutlinedTextField(
                        value = draft.phoneNumber,
                        onValueChange = { onUpdateDraftFields(null, it, null, null, null, null, null) },
                        label = { Text("Số điện thoại *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_phone_number")
                    )

                    // Strictly show Date fields ONLY for GYM_MONTHLY and YOGA_MONTHLY
                    if (draft.cardType == CardType.GYM_MONTHLY || draft.cardType == CardType.YOGA_MONTHLY) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = draft.startDate,
                                onValueChange = {
                                    onUpdateDraftFields(null, null, null, it, null, null, null)
                                },
                                label = { Text("Ngày bắt đầu *") },
                                placeholder = { Text("DD/MM/YYYY") },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(onClick = { datePickerTargetField = "start" }) {
                                        Icon(
                                            imageVector = Icons.Default.CalendarMonth,
                                            contentDescription = "Chọn ngày bắt đầu"
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_start_date")
                            )

                            OutlinedTextField(
                                value = draft.endDate,
                                onValueChange = {
                                    onUpdateDraftFields(null, null, null, null, it, null, null)
                                },
                                label = { Text("Ngày hết hạn *") },
                                placeholder = { Text("DD/MM/YYYY") },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(onClick = { datePickerTargetField = "end" }) {
                                        Icon(
                                            imageVector = Icons.Default.CalendarMonth,
                                            contentDescription = "Chọn ngày hết hạn"
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_end_date")
                            )
                        }
                    }

                    // Strictly show Total PT Sessions ONLY for GYM_PT
                    if (draft.cardType == CardType.GYM_PT) {
                        OutlinedTextField(
                            value = draft.totalPtSessions,
                            onValueChange = { input ->
                                val clean = input.filter { it.isDigit() }
                                onUpdateDraftFields(null, null, null, null, null, clean, null)
                            },
                            label = { Text("Tổng số buổi PT *") },
                            placeholder = { Text("Ví dụ: 12, 24, 36...") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_pt_sessions")
                        )
                    }

                    // Editable Price VND for all 3 card types
                    val parsedPrice = FormattersAndValidators.parseVndInput(draft.priceVndText)
                    OutlinedTextField(
                        value = draft.priceVndText,
                        onValueChange = { input ->
                            val digits = input.filter { it.isDigit() }.toLongOrNull()
                            val formatted = if (digits != null) {
                                FormattersAndValidators.formatVndDigitsOnly(digits)
                            } else {
                                ""
                            }
                            onUpdateDraftFields(null, null, null, null, null, null, formatted)
                        },
                        label = { Text("Giá tiền (VNĐ) *") },
                        supportingText = {
                            Text(
                                text = if (parsedPrice != null) {
                                    "Hiển thị trên thẻ: ${FormattersAndValidators.formatVnd(parsedPrice)} (Chỉnh sửa tại đây không làm đổi giá mặc định trong Cài đặt)"
                                } else {
                                    "Nhập số tiền VNĐ (hệ thống tự định dạng dấu chấm)"
                                }
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_price_vnd")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { onGoToStep(2) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("step1_next_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Tiếp tục: Chọn & Căn chỉnh ảnh", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    }
                }

                2 -> {
                    // STEP 2: PHOTO SELECTION & FIXED-FRAME CROPPING
                    Text(
                        text = "Chọn nguồn ảnh hội viên (Ảnh gốc tự động lưu riêng)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showCameraDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("btn_open_camera"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chụp ảnh")
                        }

                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("btn_pick_gallery_photo"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Từ thiết bị")
                        }
                    }

                    OutlinedButton(
                        onClick = { showMemberPhotoPickerDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_pick_member_photo_library"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.FolderSpecial, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Chọn từ Thư viện Ảnh Hội Viên đã lưu (${memberPhotos.size})")
                    }

                    val activePhotoPath = draft.originalPhotoPath ?: draft.croppedPhotoPath
                    if (!activePhotoPath.isNullOrBlank() && File(activePhotoPath).exists()) {
                        FixedFrameCropper(
                            photoPath = activePhotoPath,
                            cropScale = draft.cropScale,
                            cropOffsetX = draft.cropOffsetX,
                            cropOffsetY = draft.cropOffsetY,
                            onTransformChanged = onUpdateCropTransform,
                            onResetTransform = onResetCropTransform
                        )
                    } else {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddAPhoto,
                                    contentDescription = null,
                                    modifier = Modifier.size(48.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Chưa có ảnh hội viên",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Hãy chụp ảnh mới hoặc chọn ảnh từ thư viện để căn chỉnh vào khung cố định của phôi thẻ.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onGoToStep(1) },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("step2_back_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Quay lại Bước 1")
                        }
                        Button(
                            onClick = { onGoToStep(3) },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("step2_next_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Xem trước thẻ", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                3 -> {
                    // STEP 3: PREVIEW, SAVE LIBRARY, EXPORT PNG, EXPORT PDF, DIRECT SHARE
                    val payload = onBuildDraftPayload()
                    val activeTemplate = templates.firstOrNull { it.cardType == draft.cardType }
                        ?: templates.first()

                    Text(
                        text = "Bản xem trước thẻ kỹ thuật số (1200 × 750 px • Tỷ lệ 8:5)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    CardCanvasPreviewBox(
                        payload = payload,
                        template = activeTemplate,
                        modifier = Modifier.testTag("step3_card_preview_box")
                    )

                    // Quick Edit Navigation Buttons (Preserves all entered data)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onGoToStep(1) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("step3_edit_info_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sửa thông tin")
                        }
                        OutlinedButton(
                            onClick = { onGoToStep(2) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("step3_edit_photo_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Đổi / Căn lại ảnh")
                        }
                    }

                    HorizontalDivider()

                    // Primary Save to Card Library Action
                    Button(
                        onClick = {
                            if (draft.editingCardId != null) {
                                showConfirmSaveCardDialog = true
                            } else {
                                onSaveCardToLibrary()
                            }
                        },
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("btn_save_card_library"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCardSavedToLibrary) Color(0xFF059669) else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(
                            imageVector = if (isCardSavedToLibrary) Icons.Default.CheckCircle else Icons.Default.Save,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when {
                                isCardSavedToLibrary -> "Đã lưu vào Thư viện Thẻ (Nhấn để cập nhật lại)"
                                draft.editingCardId != null -> "Xác nhận lưu chỉnh sửa thẻ"
                                else -> "Lưu thẻ vào Thư viện"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Export PNG, Share Direct, and Export PDF Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onExportPng(payload) },
                            enabled = !isBusy,
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("btn_export_png"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            )
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Lưu PNG", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onShareCard(payload) },
                            enabled = !isBusy,
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("btn_share_direct"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chia sẻ", fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = { onExportPdf(payload) },
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("btn_export_pdf"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Xuất PDF (Trang đơn tỷ lệ 8:5 sắc nét)")
                    }
                }
            }
        }
    }

    // DatePicker Modal for Start Date or End Date
    if (datePickerTargetField != null) {
        val currentFieldText = if (datePickerTargetField == "start") draft.startDate else draft.endDate
        val initialMillis = FormattersAndValidators.parseDdMmYyyyToUtcMillis(currentFieldText)
            ?: System.currentTimeMillis()
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)

        DatePickerDialog(
            onDismissRequest = { datePickerTargetField = null },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedMillis = pickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            val formatted = FormattersAndValidators.formatUtcMillisToDdMmYyyy(selectedMillis)
                            if (datePickerTargetField == "start") {
                                onUpdateDraftFields(null, null, null, formatted, null, null, null)
                            } else {
                                onUpdateDraftFields(null, null, null, null, formatted, null, null)
                            }
                        }
                        datePickerTargetField = null
                    }
                ) {
                    Text("Chọn ngày")
                }
            },
            dismissButton = {
                TextButton(onClick = { datePickerTargetField = null }) {
                    Text("Hủy")
                }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }

    // CameraX Capture Modal
    if (showCameraDialog) {
        CameraCaptureDialog(
            onDismiss = { showCameraDialog = false },
            onPhotoCaptured = { file ->
                showCameraDialog = false
                onPhotoCapturedFromCamera(file)
            },
            onError = { msg ->
                showCameraDialog = false
                onPostError(msg)
            }
        )
    }

    // Existing Member Original Photo Selector Modal
    if (showMemberPhotoPickerDialog) {
        MemberPhotoSelectorDialog(
            photos = memberPhotos,
            onDismiss = { showMemberPhotoPickerDialog = false },
            onSelectPhoto = { photo ->
                showMemberPhotoPickerDialog = false
                onSelectExistingMemberPhoto(photo)
            }
        )
    }

    // Confirm saving changes to an existing card
    if (showConfirmSaveCardDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmSaveCardDialog = false },
            title = { Text("Xác nhận lưu chỉnh sửa thẻ") },
            text = {
                Text("Bạn có chắc chắn muốn cập nhật thông tin mới cho thẻ của ${draft.fullName}? Ảnh PNG đã xuất ra máy trước đó sẽ không bị ghi đè.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmSaveCardDialog = false
                        onSaveCardToLibrary()
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmSaveCardDialog = false }) {
                    Text("Tiếp tục sửa")
                }
            }
        )
    }

    // Unsaved changes guard dialog
    if (showUnsavedExitDialog) {
        AlertDialog(
            onDismissRequest = { showUnsavedExitDialog = false },
            title = { Text("Thay đổi chưa lưu") },
            text = {
                Text("Bạn có thông tin thẻ đang nhập chưa được lưu vào Thư viện Thẻ. (Lưu ý: Ảnh gốc hội viên nếu đã chụp/chọn vẫn được giữ nguyên trong Thư viện Ảnh).")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnsavedExitDialog = false
                        onExitWizard()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Hủy thay đổi & Thoát")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnsavedExitDialog = false }) {
                    Text("Tiếp tục chỉnh sửa")
                }
            }
        )
    }
}

@Composable
private fun WizardStepPill(
    stepNumber: Int,
    label: String,
    currentStep: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isCurrent = currentStep == stepNumber
    val isCompleted = currentStep > stepNumber
    val bgColor = when {
        isCurrent -> MaterialTheme.colorScheme.primary
        isCompleted -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val textColor = when {
        isCurrent -> MaterialTheme.colorScheme.onPrimary
        isCompleted -> MaterialTheme.colorScheme.onPrimaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = textColor,
            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
private fun MemberPhotoSelectorDialog(
    photos: List<MemberPhotoEntity>,
    onDismiss: () -> Unit,
    onSelectPhoto: (MemberPhotoEntity) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(photos, query) {
        if (query.isBlank()) photos
        else photos.filter {
            it.memberName.contains(query, ignoreCase = true) ||
                it.phoneNumber.contains(query, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chọn từ Thư viện Ảnh Hội Viên") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Tìm theo tên hoặc SĐT") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (filtered.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Không tìm thấy ảnh hội viên phù hợp.")
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filtered, key = { it.id }) { photo ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectPhoto(photo) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = File(photo.originalFilePath),
                                        contentDescription = photo.memberName,
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(RoundedCornerShape(10.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = photo.memberName.ifBlank { "Ảnh chưa gắn tên" },
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = photo.phoneNumber.ifBlank { "Chưa có SĐT" },
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(
                                            text = "${photo.widthPx}×${photo.heightPx} px • ${FormattersAndValidators.formatTimestampDateTime(photo.createdAtMillis)}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Đóng")
            }
        }
    )
}
