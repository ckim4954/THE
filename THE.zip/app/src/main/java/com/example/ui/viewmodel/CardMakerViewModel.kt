package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.MemberPhotoEntity
import com.example.data.local.MembershipCardEntity
import com.example.data.local.WorkoutPackageEntity
import com.example.data.preferences.AppPreferencesRepository
import com.example.data.repository.CardMakerRepository
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardDraft
import com.example.domain.model.CardType
import com.example.domain.model.ExportResolution
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateMetadata
import com.example.domain.model.ThemeMode
import com.example.domain.util.FormattersAndValidators
import com.example.render.CardRenderEngine
import com.example.render.CardRenderPayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class BottomNavTab {
    CREATE_CARD,
    LIBRARY,
    SETTINGS
}

enum class LibrarySubTab {
    CREATED_CARDS,
    MEMBER_PHOTOS
}

class CardMakerViewModel(
    application: Application,
    private val repository: CardMakerRepository
) : AndroidViewModel(application) {

    val packages: StateFlow<List<WorkoutPackageEntity>> = repository.packagesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memberPhotos: StateFlow<List<MemberPhotoEntity>> = repository.memberPhotosFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cards: StateFlow<List<MembershipCardEntity>> = repository.cardsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val templates: StateFlow<List<TemplateMetadata>> = repository.templatesFlow
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            AppDatabase.defaultTemplates().map { it.toDomainModel() }
        )

    val brandConfig: StateFlow<BrandConfig> = repository.brandConfigFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BrandConfig())

    val themeMode: StateFlow<ThemeMode> = repository.themeModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    val exportResolution: StateFlow<ExportResolution> = repository.exportResolutionFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ExportResolution.STANDARD_HD)

    private val _currentTab = MutableStateFlow(BottomNavTab.CREATE_CARD)
    val currentTab: StateFlow<BottomNavTab> = _currentTab.asStateFlow()

    private val _librarySubTab = MutableStateFlow(LibrarySubTab.CREATED_CARDS)
    val librarySubTab: StateFlow<LibrarySubTab> = _librarySubTab.asStateFlow()

    // null = Home card type selector; 1 = Info Step; 2 = Photo & Crop Step; 3 = Preview & Export Step
    private val _wizardStep = MutableStateFlow<Int?>(null)
    val wizardStep: StateFlow<Int?> = _wizardStep.asStateFlow()

    private val _draft = MutableStateFlow(CardDraft())
    val draft: StateFlow<CardDraft> = _draft.asStateFlow()

    private val _hasUnsavedChanges = MutableStateFlow(false)
    val hasUnsavedChanges: StateFlow<Boolean> = _hasUnsavedChanges.asStateFlow()

    private val _isCardSavedToLibrary = MutableStateFlow(false)
    val isCardSavedToLibrary: StateFlow<Boolean> = _isCardSavedToLibrary.asStateFlow()

    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isStatusError = MutableStateFlow(false)
    val isStatusError: StateFlow<Boolean> = _isStatusError.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureInitialDataSeeded()
        }
    }

    fun selectBottomTab(tab: BottomNavTab) {
        _currentTab.value = tab
    }

    fun selectLibrarySubTab(subTab: LibrarySubTab) {
        _librarySubTab.value = subTab
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun postMessage(message: String, isError: Boolean = false) {
        _statusMessage.value = message
        _isStatusError.value = isError
    }

    // --- Card Creation & Editing Wizard ---
    fun startNewCardWizard(
        cardType: CardType,
        preselectedPhoto: MemberPhotoEntity? = null
    ) {
        val today = FormattersAndValidators.todayFormatted()
        val matchingPackages = getPackagesForSelection(cardType, TargetGroup.NAM)
        val defaultPkg = matchingPackages.firstOrNull()

        val initialEndDate = if (cardType != CardType.GYM_PT) {
            FormattersAndValidators.calculateEndDate(today, defaultPkg?.durationMonths ?: 1)
        } else {
            ""
        }
        val initialSessions = if (cardType == CardType.GYM_PT) {
            defaultPkg?.totalSessions?.toString() ?: ""
        } else {
            ""
        }
        val initialPrice = defaultPkg?.priceVnd?.let {
            FormattersAndValidators.formatVndDigitsOnly(it)
        } ?: ""

        _draft.value = CardDraft(
            editingCardId = null,
            cardType = cardType,
            targetGroup = TargetGroup.NAM,
            selectedPackageId = defaultPkg?.id,
            packageName = defaultPkg?.packageName ?: "",
            fullName = preselectedPhoto?.memberName ?: "",
            phoneNumber = preselectedPhoto?.phoneNumber ?: "",
            startDate = if (cardType != CardType.GYM_PT) today else "",
            endDate = initialEndDate,
            totalPtSessions = initialSessions,
            priceVndText = initialPrice,
            originalPhotoId = preselectedPhoto?.id,
            originalPhotoPath = preselectedPhoto?.originalFilePath,
            croppedPhotoPath = null,
            cropScale = 1f,
            cropOffsetX = 0f,
            cropOffsetY = 0f
        )
        _hasUnsavedChanges.value = preselectedPhoto != null
        _isCardSavedToLibrary.value = false
        _currentTab.value = BottomNavTab.CREATE_CARD
        _wizardStep.value = 1
    }

    fun startEditingExistingCard(card: MembershipCardEntity) {
        val cardType = CardType.fromCode(card.cardType)
        val group = TargetGroup.fromCode(card.targetGroup) ?: TargetGroup.NAM
        val sourcePhoto = if (File(card.originalPhotoPathSnapshot).exists()) {
            card.originalPhotoPathSnapshot
        } else {
            card.croppedPhotoPath
        }

        _draft.value = CardDraft(
            editingCardId = card.id,
            cardType = cardType,
            targetGroup = group,
            selectedPackageId = null,
            packageName = card.packageNameSnapshot,
            fullName = card.fullName,
            phoneNumber = card.phoneNumber,
            startDate = card.startDateFormatted ?: FormattersAndValidators.todayFormatted(),
            endDate = card.endDateFormatted ?: "",
            totalPtSessions = card.totalPtSessions?.toString() ?: "",
            priceVndText = FormattersAndValidators.formatVndDigitsOnly(card.priceVnd),
            originalPhotoId = card.originalPhotoId,
            originalPhotoPath = sourcePhoto,
            croppedPhotoPath = card.croppedPhotoPath,
            cropScale = card.cropScale,
            cropOffsetX = card.cropOffsetX,
            cropOffsetY = card.cropOffsetY
        )
        _hasUnsavedChanges.value = false
        _isCardSavedToLibrary.value = true
        _currentTab.value = BottomNavTab.CREATE_CARD
        _wizardStep.value = 1
    }

    fun exitWizard() {
        _wizardStep.value = null
        _hasUnsavedChanges.value = false
        _previewBitmap.value = null
    }

    fun getPackagesForSelection(
        cardType: CardType,
        targetGroup: TargetGroup
    ): List<WorkoutPackageEntity> {
        return packages.value.filter { pkg ->
            if (pkg.cardType != cardType.code) return@filter false
            if (cardType == CardType.GYM_MONTHLY) {
                pkg.targetGroup == targetGroup.code
            } else {
                true
            }
        }
    }

    fun onTargetGroupChanged(newGroup: TargetGroup) {
        val current = _draft.value
        val matching = getPackagesForSelection(current.cardType, newGroup)
        val firstPkg = matching.firstOrNull()
        val start = current.startDate.ifBlank { FormattersAndValidators.todayFormatted() }
        val newEnd = if (firstPkg?.durationMonths != null) {
            FormattersAndValidators.calculateEndDate(start, firstPkg.durationMonths)
        } else {
            current.endDate
        }
        val newPrice = firstPkg?.priceVnd?.let { FormattersAndValidators.formatVndDigitsOnly(it) }
            ?: current.priceVndText

        _draft.update {
            it.copy(
                targetGroup = newGroup,
                selectedPackageId = firstPkg?.id,
                packageName = firstPkg?.packageName ?: it.packageName,
                endDate = newEnd,
                priceVndText = newPrice
            )
        }
        _hasUnsavedChanges.value = true
        _isCardSavedToLibrary.value = false
    }

    fun onPackageSelected(pkg: WorkoutPackageEntity) {
        val current = _draft.value
        val start = current.startDate.ifBlank { FormattersAndValidators.todayFormatted() }
        val newEnd = if (current.cardType != CardType.GYM_PT && pkg.durationMonths != null) {
            FormattersAndValidators.calculateEndDate(start, pkg.durationMonths)
        } else {
            current.endDate
        }
        val newSessions = if (current.cardType == CardType.GYM_PT && pkg.totalSessions != null) {
            pkg.totalSessions.toString()
        } else {
            current.totalPtSessions
        }
        _draft.update {
            it.copy(
                selectedPackageId = pkg.id,
                packageName = pkg.packageName,
                startDate = if (current.cardType != CardType.GYM_PT) start else "",
                endDate = newEnd,
                totalPtSessions = newSessions,
                priceVndText = FormattersAndValidators.formatVndDigitsOnly(pkg.priceVnd)
            )
        }
        _hasUnsavedChanges.value = true
        _isCardSavedToLibrary.value = false
    }

    fun updateDraftFields(
        fullName: String? = null,
        phoneNumber: String? = null,
        packageName: String? = null,
        startDate: String? = null,
        endDate: String? = null,
        totalPtSessions: String? = null,
        priceVndText: String? = null
    ) {
        _draft.update { curr ->
            var updatedStart = startDate ?: curr.startDate
            var updatedEnd = endDate ?: curr.endDate

            // If user changed startDate and a package with durationMonths is active, auto-recalculate endDate
            if (startDate != null && endDate == null && FormattersAndValidators.isValidDateDdMmYyyy(startDate)) {
                val activePkg = packages.value.firstOrNull { it.id == curr.selectedPackageId }
                val months = activePkg?.durationMonths
                if (months != null) {
                    updatedEnd = FormattersAndValidators.calculateEndDate(startDate, months)
                }
            }

            curr.copy(
                fullName = fullName ?: curr.fullName,
                phoneNumber = phoneNumber ?: curr.phoneNumber,
                packageName = packageName ?: curr.packageName,
                startDate = updatedStart,
                endDate = updatedEnd,
                totalPtSessions = totalPtSessions ?: curr.totalPtSessions,
                priceVndText = priceVndText ?: curr.priceVndText
            )
        }
        _hasUnsavedChanges.value = true
        _isCardSavedToLibrary.value = false
    }

    fun updateCropTransform(scale: Float, offsetX: Float, offsetY: Float) {
        _draft.update {
            it.copy(
                cropScale = scale.coerceIn(0.6f, 4.5f),
                cropOffsetX = offsetX.coerceIn(-0.85f, 0.85f),
                cropOffsetY = offsetY.coerceIn(-0.85f, 0.85f)
            )
        }
        _hasUnsavedChanges.value = true
        _isCardSavedToLibrary.value = false
    }

    fun resetCropTransform() {
        updateCropTransform(1f, 0f, 0f)
    }

    fun onPhotoPickedFromDeviceUri(uri: Uri) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val curr = _draft.value
            val res = repository.saveOriginalPhotoFromUri(uri, curr.fullName, curr.phoneNumber)
            _isBusy.value = false
            res.onSuccess { savedPhoto ->
                _draft.update {
                    it.copy(
                        originalPhotoId = savedPhoto.id,
                        originalPhotoPath = savedPhoto.originalFilePath,
                        cropScale = 1f,
                        cropOffsetX = 0f,
                        cropOffsetY = 0f
                    )
                }
                _hasUnsavedChanges.value = true
                _isCardSavedToLibrary.value = false
                postMessage("Đã lưu bản ảnh gốc vào Thư viện Ảnh Hội Viên.")
            }.onFailure { err ->
                postMessage(err.message ?: "Không thể lưu ảnh gốc.", isError = true)
            }
        }
    }

    fun onPhotoCapturedFromCamera(tempFile: File) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val curr = _draft.value
            val res = repository.saveOriginalPhotoFromCameraFile(tempFile, curr.fullName, curr.phoneNumber)
            _isBusy.value = false
            res.onSuccess { savedPhoto ->
                _draft.update {
                    it.copy(
                        originalPhotoId = savedPhoto.id,
                        originalPhotoPath = savedPhoto.originalFilePath,
                        cropScale = 1f,
                        cropOffsetX = 0f,
                        cropOffsetY = 0f
                    )
                }
                _hasUnsavedChanges.value = true
                _isCardSavedToLibrary.value = false
                postMessage("Đã chụp và lưu ảnh gốc hội viên độc lập.")
            }.onFailure { err ->
                postMessage(err.message ?: "Lỗi khi lưu ảnh chụp.", isError = true)
            }
        }
    }

    fun selectExistingMemberPhotoForDraft(photo: MemberPhotoEntity) {
        _draft.update { curr ->
            curr.copy(
                originalPhotoId = photo.id,
                originalPhotoPath = photo.originalFilePath,
                fullName = curr.fullName.ifBlank { photo.memberName },
                phoneNumber = curr.phoneNumber.ifBlank { photo.phoneNumber },
                cropScale = 1f,
                cropOffsetX = 0f,
                cropOffsetY = 0f
            )
        }
        _hasUnsavedChanges.value = true
        _isCardSavedToLibrary.value = false
        postMessage("Đã chọn ảnh gốc từ Thư viện Ảnh Hội Viên.")
    }

    fun goToWizardStep(targetStep: Int) {
        val currentStep = _wizardStep.value ?: return
        if (targetStep > 1 && currentStep == 1) {
            val error = FormattersAndValidators.validateStep1Info(_draft.value)
            if (error != null) {
                postMessage(error, isError = true)
                return
            }
        }
        if (targetStep == 3) {
            val error1 = FormattersAndValidators.validateStep1Info(_draft.value)
            if (error1 != null) {
                postMessage(error1, isError = true)
                return
            }
            val error2 = FormattersAndValidators.validateStep2Photo(_draft.value)
            if (error2 != null) {
                postMessage(error2, isError = true)
                return
            }
            refreshPreviewBitmap()
        }
        _wizardStep.value = targetStep
    }

    fun buildRenderPayloadFromDraft(): CardRenderPayload {
        val d = _draft.value
        val b = brandConfig.value
        val price = FormattersAndValidators.parseVndInput(d.priceVndText) ?: 0L
        return CardRenderPayload(
            cardType = d.cardType,
            fullName = d.fullName.trim(),
            phoneNumber = d.phoneNumber.trim(),
            targetGroup = if (d.cardType == CardType.GYM_MONTHLY) d.targetGroup else null,
            packageName = d.packageName.trim(),
            startDateFormatted = if (d.cardType != CardType.GYM_PT) d.startDate.trim() else null,
            endDateFormatted = if (d.cardType != CardType.GYM_PT) d.endDate.trim() else null,
            totalPtSessions = if (d.cardType == CardType.GYM_PT) d.totalPtSessions.trim().toIntOrNull() ?: 1 else null,
            priceVnd = price,
            photoPath = d.originalPhotoPath ?: d.croppedPhotoPath,
            cropScale = d.cropScale,
            cropOffsetX = d.cropOffsetX,
            cropOffsetY = d.cropOffsetY,
            brandName = b.brandName,
            brandContact = b.contactInfo,
            brandLogoPath = b.customLogoPath
        )
    }

    fun buildRenderPayloadFromSavedCard(card: MembershipCardEntity): CardRenderPayload {
        val type = CardType.fromCode(card.cardType)
        val sourcePhoto = if (File(card.originalPhotoPathSnapshot).exists()) {
            card.originalPhotoPathSnapshot
        } else {
            card.croppedPhotoPath
        }
        return CardRenderPayload(
            cardType = type,
            fullName = card.fullName,
            phoneNumber = card.phoneNumber,
            targetGroup = if (type == CardType.GYM_MONTHLY) TargetGroup.fromCode(card.targetGroup) else null,
            packageName = card.packageNameSnapshot,
            startDateFormatted = card.startDateFormatted,
            endDateFormatted = card.endDateFormatted,
            totalPtSessions = card.totalPtSessions,
            priceVnd = card.priceVnd,
            photoPath = sourcePhoto,
            cropScale = if (sourcePhoto == card.originalPhotoPathSnapshot) card.cropScale else 1f,
            cropOffsetX = if (sourcePhoto == card.originalPhotoPathSnapshot) card.cropOffsetX else 0f,
            cropOffsetY = if (sourcePhoto == card.originalPhotoPathSnapshot) card.cropOffsetY else 0f,
            brandName = card.brandNameSnapshot,
            brandContact = card.brandContactSnapshot,
            brandLogoPath = card.brandLogoPathSnapshot
        )
    }

    fun refreshPreviewBitmap() {
        viewModelScope.launch {
            val payload = buildRenderPayloadFromDraft()
            val tpl = repository.getTemplateMetadataForType(payload.cardType)
            val bmp = withContext(Dispatchers.Default) {
                CardRenderEngine.renderCardBitmap(
                    context = getApplication(),
                    payload = payload,
                    template = tpl,
                    targetWidth = 1200,
                    targetHeight = 750
                )
            }
            _previewBitmap.value = bmp
        }
    }

    fun saveCurrentDraftToCardLibrary(onSuccessCallback: (() -> Unit)? = null) {
        if (_isBusy.value) return
        val d = _draft.value
        val photoPath = d.originalPhotoPath ?: d.croppedPhotoPath
        if (photoPath.isNullOrBlank()) {
            postMessage("Thiếu ảnh hội viên.", isError = true)
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            val payload = buildRenderPayloadFromDraft()
            val res = repository.saveMembershipCard(
                editingCardId = d.editingCardId,
                payload = payload,
                originalPhotoId = d.originalPhotoId,
                originalPhotoPath = photoPath
            )
            _isBusy.value = false
            res.onSuccess { savedCard ->
                _draft.update { it.copy(editingCardId = savedCard.id, croppedPhotoPath = savedCard.croppedPhotoPath) }
                _hasUnsavedChanges.value = false
                _isCardSavedToLibrary.value = true
                postMessage("Đã lưu thẻ của ${savedCard.fullName} vào Thư viện Thẻ.")
                onSuccessCallback?.invoke()
            }.onFailure { err ->
                postMessage(err.message ?: "Không thể lưu thẻ vào thư viện.", isError = true)
            }
        }
    }

    fun exportPayloadToPng(payload: CardRenderPayload) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.exportCardToGalleryPng(payload)
            _isBusy.value = false
            res.onSuccess { path ->
                postMessage("Đã lưu ảnh PNG chất lượng cao: $path")
            }.onFailure { err ->
                postMessage(err.message ?: "Xuất ảnh PNG thất bại.", isError = true)
            }
        }
    }

    fun exportPayloadToPdf(payload: CardRenderPayload, onPdfUriReady: (Uri) -> Unit) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.exportCardToSinglePagePdf(payload)
            _isBusy.value = false
            res.onSuccess { uri ->
                postMessage("Đã xuất tệp PDF chuẩn tỷ lệ 8:5.")
                onPdfUriReady(uri)
            }.onFailure { err ->
                postMessage(err.message ?: "Xuất PDF thất bại.", isError = true)
            }
        }
    }

    fun sharePayloadDirectPng(payload: CardRenderPayload, onShareUriReady: (Uri) -> Unit) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.prepareShareablePngUri(payload)
            _isBusy.value = false
            res.onSuccess { uri ->
                onShareUriReady(uri)
            }.onFailure { err ->
                postMessage(err.message ?: "Không thể chuẩn bị ảnh để chia sẻ.", isError = true)
            }
        }
    }

    // --- Library Operations ---
    fun deleteCardFromLibrary(card: MembershipCardEntity) {
        viewModelScope.launch {
            repository.deleteMembershipCardOnly(card)
            postMessage("Đã xóa thẻ của ${card.fullName} (Ảnh gốc hội viên vẫn được giữ nguyên).")
        }
    }

    fun addStandalonePhotoToLibrary(uri: Uri, memberName: String, phoneNumber: String) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.saveOriginalPhotoFromUri(uri, memberName, phoneNumber)
            _isBusy.value = false
            res.onSuccess {
                postMessage("Đã lưu ảnh gốc hội viên vào thư viện.")
            }.onFailure { err ->
                postMessage(err.message ?: "Không thể lưu ảnh gốc.", isError = true)
            }
        }
    }

    fun updateMemberPhotoInfo(photoId: Long, name: String, phone: String) {
        viewModelScope.launch {
            repository.updateMemberPhotoMetadata(photoId, name, phone)
            postMessage("Đã cập nhật thông tin liên kết ảnh gốc.")
        }
    }

    fun deleteOriginalPhotoFromLibrary(photo: MemberPhotoEntity) {
        viewModelScope.launch {
            repository.deleteOriginalMemberPhoto(photo)
            postMessage("Đã xóa ảnh gốc khỏi Thư viện Ảnh Hội Viên.")
        }
    }

    // --- Settings Operations ---
    fun savePackageConfig(pkg: WorkoutPackageEntity) {
        viewModelScope.launch {
            repository.saveWorkoutPackage(pkg)
            postMessage("Đã lưu cấu hình gói tập '${pkg.packageName}'.")
        }
    }

    fun deletePackageConfig(pkg: WorkoutPackageEntity) {
        viewModelScope.launch {
            repository.deleteWorkoutPackage(pkg.id)
            postMessage("Đã xóa gói '${pkg.packageName}' (Các thẻ cũ đã tạo không bị ảnh hưởng).")
        }
    }

    fun resetDefaultGymPrices() {
        viewModelScope.launch {
            repository.resetDefaultGymPackages()
            postMessage("Đã khôi phục bảng giá Gym tháng mặc định (Nam / Nữ / Trẻ em).")
        }
    }

    fun saveBrandSettings(
        brandName: String,
        contactInfo: String,
        newLogoUri: Uri?,
        removeLogo: Boolean
    ) {
        viewModelScope.launch {
            repository.saveBrandSettings(brandName, contactInfo, newLogoUri, removeLogo)
            postMessage("Đã lưu cấu hình thương hiệu cho các thẻ tạo mới.")
        }
    }

    fun saveTemplateCustomization(
        cardType: CardType,
        bgHex: String,
        secHex: String,
        accentHex: String,
        customBgUri: Uri?,
        clearCustomBg: Boolean
    ) {
        viewModelScope.launch {
            repository.updateTemplateColorsAndBackground(
                cardType = cardType,
                backgroundColorHex = bgHex,
                secondaryColorHex = secHex,
                accentColorHex = accentHex,
                customBackgroundUri = customBgUri,
                clearCustomBackground = clearCustomBg
            )
            postMessage("Đã lưu cấu hình phôi thẻ ${cardType.displayTitle}.")
        }
    }

    fun resetTemplatesToDefault() {
        viewModelScope.launch {
            repository.resetAllTemplatesToDefault()
            postMessage("Đã khôi phục 3 phôi thẻ mặc định chuẩn 89 FITNESS & YOGA.")
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.saveThemeMode(mode)
            postMessage("Đã lưu chế độ giao diện: ${mode.displayLabel}")
        }
    }

    fun setExportResolution(resolution: ExportResolution) {
        viewModelScope.launch {
            repository.saveExportResolution(resolution)
            postMessage("Đã lưu độ phân giải xuất thẻ: ${resolution.displayLabel}")
        }
    }

    fun exportBackupZip(destinationUri: Uri) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.exportFullBackupZip(destinationUri)
            _isBusy.value = false
            res.onSuccess { msg -> postMessage(msg) }
                .onFailure { err -> postMessage(err.message ?: "Lỗi khi sao lưu dữ liệu.", isError = true) }
        }
    }

    fun restoreBackupZip(sourceUri: Uri) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.restoreFullBackupZip(sourceUri)
            _isBusy.value = false
            res.onSuccess { msg -> postMessage(msg) }
                .onFailure { err -> postMessage(err.message ?: "Lỗi khi khôi phục dữ liệu.", isError = true) }
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AppDatabase.getInstance(application)
                    val prefs = AppPreferencesRepository(application)
                    val repo = CardMakerRepository(application, db.appDao(), prefs)
                    return CardMakerViewModel(application, repo) as T
                }
            }
    }
}
