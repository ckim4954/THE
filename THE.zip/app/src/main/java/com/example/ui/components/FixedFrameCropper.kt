package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.TemplateMetadata
import com.example.render.CardRenderEngine
import com.example.render.CardRenderPayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

@Composable
fun FixedFrameCropper(
    photoPath: String,
    cropScale: Float,
    cropOffsetX: Float,
    cropOffsetY: Float,
    onTransformChanged: (scale: Float, offsetX: Float, offsetY: Float) -> Unit,
    onResetTransform: () -> Unit,
    modifier: Modifier = Modifier
) {
    var loadedBitmap by remember(photoPath) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(photoPath) {
        loadedBitmap = withContext(Dispatchers.IO) {
            CardRenderEngine.decodeSampledBitmap(photoPath, 1000, 1000)
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Khung ảnh cố định trên phôi (Tỷ lệ chuẩn)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                OutlinedButton(
                    onClick = onResetTransform,
                    modifier = Modifier.testTag("reset_crop_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.CenterFocusStrong,
                        contentDescription = "Đặt lại vị trí ảnh"
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Căn giữa")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Fixed Aspect Ratio Slot Box (widthRatio = 0.275 * 1200 = 330, heightRatio = 0.64 * 750 = 480 => 330/480 = 0.6875f)
            Box(
                modifier = Modifier
                    .width(220.dp)
                    .aspectRatio(0.6875f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0F172A))
                    .border(
                        width = 3.dp,
                        color = MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .pointerInput(photoPath) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (cropScale * zoom).coerceIn(0.6f, 4.5f)
                            val boxW = size.width.toFloat().coerceAtLeast(1f)
                            val boxH = size.height.toFloat().coerceAtLeast(1f)
                            val newOffsetX = (cropOffsetX + pan.x / boxW).coerceIn(-0.85f, 0.85f)
                            val newOffsetY = (cropOffsetY + pan.y / boxH).coerceIn(-0.85f, 0.85f)
                            onTransformChanged(newScale, newOffsetX, newOffsetY)
                        }
                    }
                    .testTag("fixed_crop_viewport"),
                contentAlignment = Alignment.Center
            ) {
                val bmp = loadedBitmap
                if (bmp != null) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val bw = bmp.width.toFloat().coerceAtLeast(1f)
                        val bh = bmp.height.toFloat().coerceAtLeast(1f)
                        val baseScale = max(size.width / bw, size.height / bh)
                        val totalScale = baseScale * cropScale
                        val scaledW = bw * totalScale
                        val scaledH = bh * totalScale
                        val dx = (size.width - scaledW) / 2f + cropOffsetX * size.width
                        val dy = (size.height - scaledH) / 2f + cropOffsetY * size.height

                        drawIntoCanvas { canvas ->
                            val matrix = android.graphics.Matrix().apply {
                                postScale(totalScale, totalScale)
                                postTranslate(dx, dy)
                            }
                            val paint = android.graphics.Paint(
                                android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG
                            )
                            canvas.nativeCanvas.drawBitmap(bmp, matrix, paint)
                        }

                        // Subtle rule-of-thirds alignment grid inside fixed slot
                        val gridColor = Color.White.copy(alpha = 0.25f)
                        drawLine(
                            color = gridColor,
                            start = Offset(size.width / 3f, 0f),
                            end = Offset(size.width / 3f, size.height),
                            strokeWidth = 1f
                        )
                        drawLine(
                            color = gridColor,
                            start = Offset(size.width * 2f / 3f, 0f),
                            end = Offset(size.width * 2f / 3f, size.height),
                            strokeWidth = 1f
                        )
                        drawLine(
                            color = gridColor,
                            start = Offset(0f, size.height / 3f),
                            end = Offset(size.width, size.height / 3f),
                            strokeWidth = 1f
                        )
                        drawLine(
                            color = gridColor,
                            start = Offset(0f, size.height * 2f / 3f),
                            end = Offset(size.width, size.height * 2f / 3f),
                            strokeWidth = 1f
                        )
                    }
                } else {
                    Text(
                        text = "Đang tải ảnh gốc...",
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Kéo trực tiếp trong khung để di chuyển ảnh • Dùng thanh trượt để phóng to/thu nhỏ",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        onTransformChanged((cropScale - 0.15f).coerceAtLeast(0.6f), cropOffsetX, cropOffsetY)
                    }
                ) {
                    Icon(Icons.Default.ZoomOut, contentDescription = "Thu nhỏ")
                }
                Slider(
                    value = cropScale,
                    onValueChange = { newScale ->
                        onTransformChanged(newScale, cropOffsetX, cropOffsetY)
                    },
                    valueRange = 0.6f..4.0f,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("crop_zoom_slider")
                )
                IconButton(
                    onClick = {
                        onTransformChanged((cropScale + 0.15f).coerceAtMost(4.0f), cropOffsetX, cropOffsetY)
                    }
                ) {
                    Icon(Icons.Default.ZoomIn, contentDescription = "Phóng to")
                }
            }
        }
    }
}

@Composable
fun CardCanvasPreviewBox(
    payload: CardRenderPayload,
    template: TemplateMetadata,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var renderedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(payload, template) {
        renderedBitmap = withContext(Dispatchers.Default) {
            CardRenderEngine.renderCardBitmap(
                context = context,
                payload = payload,
                template = template,
                targetWidth = 1200,
                targetHeight = 750
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1200f / 750f) // Strict 8:5 Digital Card Aspect Ratio
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF121316)),
        contentAlignment = Alignment.Center
    ) {
        val bmp = renderedBitmap
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Xem trước thẻ hội viên 89 FITNESS & YOGA",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        } else {
            Text(
                text = "Đang dựng thẻ 1200 × 750 px...",
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
