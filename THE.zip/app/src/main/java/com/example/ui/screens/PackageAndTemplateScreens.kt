package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.WorkoutPackageEntity
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateMetadata
import com.example.domain.util.FormattersAndValidators
import com.example.render.CardRenderEngine
import com.example.render.CardRenderPayload
import com.example.ui.components.CardCanvasPreviewBox

@Composable
fun PackageConfigSubScreen(
    packages: List<WorkoutPackageEntity>,
    onBack: () -> Unit,
    onSavePackage: (WorkoutPackageEntity) -> Unit,
    onDeletePackage: (WorkoutPackageEntity) -> Unit,
    onResetDefaultGymPrices: () -> Unit
) {
    var selectedType by remember { mutableStateOf(CardType.GYM_MONTHLY) }
    var selectedGroup by remember { mutableStateOf(TargetGroup.NAM) }
    var editingPkg by remember { mutableStateOf<WorkoutPackageEntity?>(null) }
    var isCreatingNew by remember { mutableStateOf(false) }
    var deletingPkg by remember { mutableStateOf<WorkoutPackageEntity?>(null) }
    var showResetGymConfirm by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    val filteredPackages = remember(packages, selectedType, selectedGroup) {
        packages.filter { pkg ->
            pkg.cardType == selectedType.code &&
                (selectedType != CardType.GYM_MONTHLY || pkg.targetGroup == selectedGroup.code)
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingPkg = null
                    isCreatingNew = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("fab_add_package")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Thêm gói tập")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("pkg_config_back_btn")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Cấu hình gói tập mặc định",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Xóa hoặc sửa gói không làm mất lịch sử thẻ cũ",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (selectedType == CardType.GYM_MONTHLY) {
                            IconButton(onClick = { showResetGymConfirm = true }) {
                                Icon(Icons.Default.Restore, contentDescription = "Khôi phục giá Gym mặc định")
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CardType.entries.forEach { type ->
                            FilterChip(
                                selected = selectedType == type,
                                onClick = { selectedType = type },
                                label = { Text(type.displayTitle) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_pkg_type_${type.code}")
                            )
                        }
                    }

                    if (selectedType == CardType.GYM_MONTHLY) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TargetGroup.entries.forEach { group ->
                                FilterChip(
                                    selected = selectedGroup == group,
                                    onClick = { selectedGroup = group },
                                    label = { Text("Nhóm ${group.displayLabel}") },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("settings_pkg_group_${group.code}")
                                )
                            }
                        }
                    }
                }
            }

            if (filteredPackages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Chưa có gói tập nào cho ${selectedType.displayTitle}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Nhấn nút (+) ở góc dưới để tạo gói mới với thời hạn/số buổi và giá tiền chuẩn của phòng tập.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredPackages, key = { it.id }) { pkg ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pkg_row_${pkg.id}"),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = pkg.packageName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    val metaText = when (selectedType) {
                                        CardType.GYM_PT -> "Tổng số buổi: ${pkg.totalSessions ?: 1} buổi PT"
                                        else -> "Thời hạn: ${pkg.durationMonths ?: 1} tháng"
                                    }
                                    Text(
                                        text = metaText,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = FormattersAndValidators.formatVnd(pkg.priceVnd),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(
                                    onClick = {
                                        editingPkg = pkg
                                        isCreatingNew = false
                                    }
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Sửa gói")
                                }
                                IconButton(onClick = { deletingPkg = pkg }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Xóa gói",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (isCreatingNew || editingPkg != null) {
        val current = editingPkg
        var name by remember(current) { mutableStateOf(current?.packageName ?: "") }
        var durationOrSessions by remember(current) {
            mutableStateOf(
                when (selectedType) {
                    CardType.GYM_PT -> current?.totalSessions?.toString() ?: "12"
                    else -> current?.durationMonths?.toString() ?: "1"
                }
            )
        }
        var priceText by remember(current) {
            mutableStateOf(
                current?.priceVnd?.let { FormattersAndValidators.formatVndDigitsOnly(it) } ?: ""
            )
        }
        var validationError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = {
                isCreatingNew = false
                editingPkg = null
            },
            title = {
                Text(
                    if (current == null) "Thêm gói ${selectedType.displayTitle}"
                    else "Chỉnh sửa gói ${current.packageName}"
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (selectedType == CardType.GYM_MONTHLY) {
                        Text(
                            text = "Nhóm đối tượng: ${selectedGroup.displayLabel}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Tên gói (VD: 1 tháng, Gói 12 buổi) *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = durationOrSessions,
                        onValueChange = { durationOrSessions = it.filter { ch -> ch.isDigit() } },
                        label = {
                            Text(
                                if (selectedType == CardType.GYM_PT) "Tổng số buổi PT *"
                                else "Thời hạn (số tháng) *"
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { raw ->
                            val digits = raw.filter { it.isDigit() }.toLongOrNull()
                            priceText = if (digits != null) FormattersAndValidators.formatVndDigitsOnly(digits) else ""
                        },
                        label = { Text("Giá tiền mặc định (VNĐ) *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (validationError != null) {
                        Text(
                            text = validationError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cleanName = name.trim()
                        val num = durationOrSessions.toIntOrNull()
                        val price = FormattersAndValidators.parseVndInput(priceText)
                        if (cleanName.isEmpty() || num == null || num <= 0 || price == null) {
                            validationError = "Vui lòng nhập đầy đủ tên gói, số tháng/buổi (>0) và giá tiền."
                            return@Button
                        }
                        val entity = WorkoutPackageEntity(
                            id = current?.id ?: 0L,
                            cardType = selectedType.code,
                            targetGroup = if (selectedType == CardType.GYM_MONTHLY) selectedGroup.code else null,
                            packageName = cleanName,
                            durationMonths = if (selectedType != CardType.GYM_PT) num else null,
                            totalSessions = if (selectedType == CardType.GYM_PT) num else null,
                            priceVnd = price,
                            isDefaultSeed = current?.isDefaultSeed ?: false,
                            sortOrder = current?.sortOrder ?: num
                        )
                        onSavePackage(entity)
                        isCreatingNew = false
                        editingPkg = null
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        isCreatingNew = false
                        editingPkg = null
                    }
                ) {
                    Text("Hủy")
                }
            }
        )
    }

    if (deletingPkg != null) {
        val pkg = deletingPkg!!
        AlertDialog(
            onDismissRequest = { deletingPkg = null },
            title = { Text("Xác nhận xóa gói tập") },
            text = {
                Text("Bạn có chắc chắn muốn xóa gói '${pkg.packageName}' (${FormattersAndValidators.formatVnd(pkg.priceVnd)})?\n\nCác thẻ hội viên cũ đã tạo từ gói này vẫn giữ nguyên lịch sử giá và thời hạn.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePackage(pkg)
                        deletingPkg = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Xác nhận xóa")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingPkg = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    if (showResetGymConfirm) {
        AlertDialog(
            onDismissRequest = { showResetGymConfirm = false },
            title = { Text("Khôi phục bảng giá Gym tháng mặc định") },
            text = {
                Text("Hệ thống sẽ khôi phục lại 12 gói Gym tháng chuẩn cho Nam, Nữ và Trẻ em theo bảng giá mặc định của 89 FITNESS & YOGA.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetGymConfirm = false
                        onResetDefaultGymPrices()
                    }
                ) {
                    Text("Khôi phục")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetGymConfirm = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
fun TemplateConfigSubScreen(
    templates: List<TemplateMetadata>,
    brandConfig: BrandConfig,
    onBack: () -> Unit,
    onSaveTemplateCustomization: (CardType, String, String, String, Uri?, Boolean) -> Unit,
    onResetAllTemplates: () -> Unit
) {
    var selectedType by remember { mutableStateOf(CardType.GYM_MONTHLY) }
    val activeTemplate = templates.firstOrNull { it.cardType == selectedType } ?: templates.first()

    var bgHex by remember(activeTemplate) { mutableStateOf(activeTemplate.backgroundColorHex) }
    var secHex by remember(activeTemplate) { mutableStateOf(activeTemplate.secondaryColorHex) }
    var accentHex by remember(activeTemplate) { mutableStateOf(activeTemplate.accentColorHex) }
    var customBgUri by remember(activeTemplate) { mutableStateOf<Uri?>(null) }
    var clearCustomBg by remember(activeTemplate) { mutableStateOf(false) }
    var showConfirmSave by remember { mutableStateOf(false) }
    var showConfirmReset by remember { mutableStateOf(false) }

    val bgPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            customBgUri = uri
            clearCustomBg = false
        }
    }

    BackHandler(onBack = onBack)

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("tpl_config_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Quản lý 3 phôi thẻ kỹ thuật số",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Chuẩn Canvas 1200 × 750 px (Tỷ lệ 8:5) • Khung ảnh cố định",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { showConfirmReset = true }) {
                        Icon(Icons.Default.Restore, contentDescription = "Khôi phục phôi gốc")
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CardType.entries.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type.displayTitle) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val previewTemplate = activeTemplate.copy(
                backgroundColorHex = bgHex,
                secondaryColorHex = secHex,
                accentColorHex = accentHex
            )
            val samplePayload = CardRenderPayload(
                cardType = selectedType,
                fullName = "NGUYỄN VĂN HỘI VIÊN",
                phoneNumber = "0989 898 989",
                targetGroup = if (selectedType == CardType.GYM_MONTHLY) TargetGroup.NAM else null,
                packageName = "1 tháng",
                startDateFormatted = if (selectedType != CardType.GYM_PT) "01/11/2026" else null,
                endDateFormatted = if (selectedType != CardType.GYM_PT) "01/12/2026" else null,
                totalPtSessions = if (selectedType == CardType.GYM_PT) 24 else null,
                priceVnd = if (selectedType == CardType.GYM_PT) 6_000_000L else 300_000L,
                photoPath = null,
                brandName = brandConfig.brandName,
                brandContact = brandConfig.contactInfo,
                brandLogoPath = brandConfig.customLogoPath
            )

            CardCanvasPreviewBox(payload = samplePayload, template = previewTemplate)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Thông số Metadata Phôi (${activeTemplate.templateId} • v${activeTemplate.templateVersion})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "• Kích thước nội bộ: ${activeTemplate.canvasWidth} × ${activeTemplate.canvasHeight} px (8:5 sRGB)",
                        style = MaterialTheme.typography.bodySmall
                    )
                    val slot = activeTemplate.imageSlot
                    Text(
                        text = "• Khung ảnh cố định: X=${(slot.xRatio * 100).toInt()}%, Y=${(slot.yRatio * 100).toInt()}%, W=${(slot.widthRatio * 100).toInt()}%, H=${(slot.heightRatio * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "• Số trường văn bản cấu hình: ${activeTemplate.textFields.size} trường (Montserrat & Be Vietnam Pro)",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            // Preset Color Palettes
            Text(
                text = "Bộ màu sắc phôi thẻ",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ColorPresetChip(
                    label = "Đỏ Carbon",
                    bg = "#121316",
                    sec = "#1F242D",
                    accent = "#E11D48",
                    onSelect = { b, s, a -> bgHex = b; secHex = s; accentHex = a },
                    modifier = Modifier.weight(1f)
                )
                ColorPresetChip(
                    label = "Vàng Gold",
                    bg = "#111113",
                    sec = "#1C1917",
                    accent = "#F59E0B",
                    onSelect = { b, s, a -> bgHex = b; secHex = s; accentHex = a },
                    modifier = Modifier.weight(1f)
                )
                ColorPresetChip(
                    label = "Xanh Ngọc",
                    bg = "#064E3B",
                    sec = "#065F46",
                    accent = "#34D399",
                    onSelect = { b, s, a -> bgHex = b; secHex = s; accentHex = a },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = bgHex,
                    onValueChange = { bgHex = it },
                    label = { Text("Mã màu nền (#HEX)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = accentHex,
                    onValueChange = { accentHex = it },
                    label = { Text("Màu nhấn (#HEX)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        bgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ảnh nền phôi tùy chỉnh")
                }
                if (activeTemplate.customBackgroundPath != null || customBgUri != null) {
                    TextButton(
                        onClick = {
                            customBgUri = null
                            clearCustomBg = true
                        }
                    ) {
                        Text("Bỏ ảnh nền")
                    }
                }
            }

            Button(
                onClick = { showConfirmSave = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Lưu cấu hình phôi ${selectedType.displayTitle}", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showConfirmSave) {
        AlertDialog(
            onDismissRequest = { showConfirmSave = false },
            title = { Text("Xác nhận lưu phôi thẻ") },
            text = { Text("Lưu thay đổi màu sắc và cấu hình cho phôi ${selectedType.displayTitle}?") },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmSave = false
                        onSaveTemplateCustomization(
                            selectedType,
                            bgHex,
                            secHex,
                            accentHex,
                            customBgUri,
                            clearCustomBg
                        )
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmSave = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    if (showConfirmReset) {
        AlertDialog(
            onDismissRequest = { showConfirmReset = false },
            title = { Text("Khôi phục 3 phôi thẻ mặc định") },
            text = { Text("Đặt lại toàn bộ màu sắc và bố cục của cả 3 phôi thẻ về thiết kế mặc định của 89 FITNESS & YOGA?") },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmReset = false
                        onResetAllTemplates()
                    }
                ) {
                    Text("Khôi phục mặc định")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmReset = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun ColorPresetChip(
    label: String,
    bg: String,
    sec: String,
    accent: String,
    onSelect: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val accentInt = CardRenderEngine.parseHexColorSafe(accent, android.graphics.Color.RED)
    Card(
        modifier = modifier.clickable { onSelect(bg, sec, accent) },
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(Color(accentInt))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        }
    }
}
