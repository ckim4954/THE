package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RestorePage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.WorkoutPackageEntity
import com.example.domain.model.BrandConfig
import com.example.domain.model.CardType
import com.example.domain.model.ExportResolution
import com.example.domain.model.TemplateMetadata
import com.example.domain.model.ThemeMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SettingsSubPage {
    MAIN_LIST,
    PACKAGE_CONFIG,
    TEMPLATE_CONFIG
}

@Composable
fun SettingsTabScreen(
    brandConfig: BrandConfig,
    packages: List<WorkoutPackageEntity>,
    templates: List<TemplateMetadata>,
    themeMode: ThemeMode,
    exportResolution: ExportResolution,
    totalCardsCount: Int,
    totalPhotosCount: Int,
    onSaveBrandSettings: (String, String, Uri?, Boolean) -> Unit,
    onSavePackage: (WorkoutPackageEntity) -> Unit,
    onDeletePackage: (WorkoutPackageEntity) -> Unit,
    onResetDefaultGymPrices: () -> Unit,
    onSaveTemplateCustomization: (CardType, String, String, String, Uri?, Boolean) -> Unit,
    onResetTemplates: () -> Unit,
    onSelectThemeMode: (ThemeMode) -> Unit,
    onSelectExportResolution: (ExportResolution) -> Unit,
    onExportBackupZip: (Uri) -> Unit,
    onRestoreBackupZip: (Uri) -> Unit
) {
    var subPage by remember { mutableStateOf(SettingsSubPage.MAIN_LIST) }

    var showBrandDialog by remember { mutableStateOf(false) }
    var showExportConfigDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var pendingRestoreZipUri by remember { mutableStateOf<Uri?>(null) }

    val createBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            onExportBackupZip(uri)
        }
    }

    val openBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            pendingRestoreZipUri = uri
        }
    }

    when (subPage) {
        SettingsSubPage.PACKAGE_CONFIG -> {
            PackageConfigSubScreen(
                packages = packages,
                onBack = { subPage = SettingsSubPage.MAIN_LIST },
                onSavePackage = onSavePackage,
                onDeletePackage = onDeletePackage,
                onResetDefaultGymPrices = onResetDefaultGymPrices
            )
        }
        SettingsSubPage.TEMPLATE_CONFIG -> {
            TemplateConfigSubScreen(
                templates = templates,
                brandConfig = brandConfig,
                onBack = { subPage = SettingsSubPage.MAIN_LIST },
                onSaveTemplateCustomization = onSaveTemplateCustomization,
                onResetAllTemplates = onResetTemplates
            )
        }
        SettingsSubPage.MAIN_LIST -> {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "CÀI ĐẶT HỆ THỐNG",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Quản lý thương hiệu, gói tập, phôi thẻ và sao lưu dữ liệu",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // 1. Nhận diện phòng tập
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.Business,
                        title = "1. Nhận diện phòng tập",
                        subtitle = "${brandConfig.brandName} • Logo & Liên hệ",
                        testTag = "settings_group_brand",
                        onClick = { showBrandDialog = true }
                    )
                }

                // 2. Cấu hình gói tập
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.Inventory2,
                        title = "2. Cấu hình gói tập",
                        subtitle = "Gym tháng (Nam/Nữ/Trẻ em), Gym PT, Yoga tháng (${packages.size} gói)",
                        testTag = "settings_group_packages",
                        onClick = { subPage = SettingsSubPage.PACKAGE_CONFIG }
                    )
                }

                // 3. Quản lý phôi thẻ
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.ColorLens,
                        title = "3. Quản lý phôi thẻ",
                        subtitle = "3 phôi mặc định (1200×750 px • Tỷ lệ 8:5) & Metadata",
                        testTag = "settings_group_templates",
                        onClick = { subPage = SettingsSubPage.TEMPLATE_CONFIG }
                    )
                }

                // 4. Cài đặt xuất ảnh và PDF
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.HighQuality,
                        title = "4. Cài đặt xuất ảnh và PDF",
                        subtitle = exportResolution.displayLabel,
                        testTag = "settings_group_export",
                        onClick = { showExportConfigDialog = true }
                    )
                }

                // 5. Quản lý dữ liệu và sao lưu
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.Backup,
                        title = "5. Quản lý dữ liệu và sao lưu",
                        subtitle = "Xuất & Khôi phục tệp ZIP (Dữ liệu + Ảnh gốc hội viên)",
                        testTag = "settings_group_backup",
                        onClick = { showBackupDialog = true }
                    )
                }

                // 6. Giao diện
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.DarkMode,
                        title = "6. Giao diện (Light / Dark Mode)",
                        subtitle = "Đang dùng: ${themeMode.displayLabel}",
                        testTag = "settings_group_theme",
                        onClick = { showThemeDialog = true }
                    )
                }

                // 7. Hệ thống và giới thiệu
                item {
                    SettingsGroupRowCard(
                        icon = Icons.Default.Info,
                        title = "7. Hệ thống và giới thiệu",
                        subtitle = "89 FITNESS & YOGA • Offline-First v1.0",
                        testTag = "settings_group_about",
                        onClick = { showAboutDialog = true }
                    )
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }

    // 1. Brand Configuration Dialog
    if (showBrandDialog) {
        var name by remember(brandConfig) { mutableStateOf(brandConfig.brandName) }
        var contact by remember(brandConfig) { mutableStateOf(brandConfig.contactInfo) }
        var pickedLogoUri by remember { mutableStateOf<Uri?>(null) }
        var removeLogo by remember { mutableStateOf(false) }

        val logoPicker = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickVisualMedia()
        ) { uri ->
            if (uri != null) {
                pickedLogoUri = uri
                removeLogo = false
            }
        }

        AlertDialog(
            onDismissRequest = { showBrandDialog = false },
            title = { Text("Nhận diện phòng tập") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val existingLogo = brandConfig.customLogoPath?.takeIf { File(it).exists() }
                        when {
                            pickedLogoUri != null -> {
                                AsyncImage(
                                    model = pickedLogoUri,
                                    contentDescription = "Logo mới",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            existingLogo != null && !removeLogo -> {
                                AsyncImage(
                                    model = File(existingLogo),
                                    contentDescription = "Logo hiện tại",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            else -> {
                                Image(
                                    painter = painterResource(id = R.drawable.img_app_logo_fg_1794306459132),
                                    contentDescription = "Logo mặc định",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            OutlinedButton(
                                onClick = {
                                    logoPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Đổi Logo")
                            }
                            if (brandConfig.customLogoPath != null || pickedLogoUri != null) {
                                TextButton(
                                    onClick = {
                                        pickedLogoUri = null
                                        removeLogo = true
                                    }
                                ) {
                                    Text("Dùng logo mặc định")
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Tên thương hiệu (Mặc định: 89 FITNESS & YOGA)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = contact,
                        onValueChange = { contact = it },
                        label = { Text("Thông tin chân thẻ / Liên hệ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Lưu ý: Thay đổi thương hiệu chỉ áp dụng cho các thẻ tạo mới (không làm thay đổi các thẻ cũ đã phát hành).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveBrandSettings(name, contact, pickedLogoUri, removeLogo)
                        showBrandDialog = false
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBrandDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    // 4. Export PNG & PDF Settings Dialog
    if (showExportConfigDialog) {
        var selectedRes by remember(exportResolution) { mutableStateOf(exportResolution) }
        AlertDialog(
            onDismissRequest = { showExportConfigDialog = false },
            title = { Text("Cài đặt xuất ảnh PNG và PDF") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Chọn độ phân giải xuất ảnh PNG và PDF (Giữ chuẩn tỷ lệ 8:5, không kéo méo):",
                        style = MaterialTheme.typography.bodySmall
                    )
                    ExportResolution.entries.forEach { res ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRes = res }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedRes == res,
                                onClick = { selectedRes = res }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = res.displayLabel, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Text(
                        text = "• Định dạng PDF: Xuất từng thẻ trên một trang PDF riêng biệt đúng tỷ lệ 8:5.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSelectExportResolution(selectedRes)
                        showExportConfigDialog = false
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportConfigDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    // 5. Backup & Restore ZIP Dialog
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text("Sao lưu & Khôi phục dữ liệu (.ZIP)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Tệp sao lưu (.zip) bao gồm toàn bộ:\n• Danh sách thẻ đã tạo ($totalCardsCount thẻ)\n• Toàn bộ ảnh gốc hội viên ($totalPhotosCount ảnh gốc)\n• Bảng giá gói tập (${packages.size} gói) & Cấu hình thương hiệu",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(
                        onClick = {
                            showBackupDialog = false
                            val dateTag = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
                            createBackupLauncher.launch("89FitnessYoga_Backup_$dateTag.zip")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Backup, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Xuất tệp Sao lưu (.ZIP)")
                    }
                    OutlinedButton(
                        onClick = {
                            showBackupDialog = false
                            openBackupLauncher.launch(arrayOf("application/zip", "application/octet-stream"))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.RestorePage, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Khôi phục từ tệp (.ZIP)")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBackupDialog = false }) {
                    Text("Đóng")
                }
            }
        )
    }

    // Confirm Restore Backup ZIP
    if (pendingRestoreZipUri != null) {
        AlertDialog(
            onDismissRequest = { pendingRestoreZipUri = null },
            title = { Text("Xác nhận khôi phục dữ liệu") },
            text = {
                Text("Hệ thống sẽ nạp dữ liệu thẻ, gói tập và ảnh gốc hội viên từ tệp ZIP đã chọn. Bạn có chắc chắn muốn tiếp tục?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uri = pendingRestoreZipUri!!
                        pendingRestoreZipUri = null
                        onRestoreBackupZip(uri)
                    }
                ) {
                    Text("Xác nhận khôi phục")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestoreZipUri = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // 6. Theme Mode Dialog (Immediate Preview + Confirm Save)
    if (showThemeDialog) {
        val initialMode = remember { themeMode }
        var chosenMode by remember { mutableStateOf(themeMode) }

        AlertDialog(
            onDismissRequest = {
                onSelectThemeMode(initialMode)
                showThemeDialog = false
            },
            title = { Text("Chế độ Giao diện (Light / Dark Mode)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    chosenMode = mode
                                    onSelectThemeMode(mode) // Immediate visual switch
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = chosenMode == mode,
                                onClick = {
                                    chosenMode = mode
                                    onSelectThemeMode(mode)
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = mode.displayLabel, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                    Text(
                        text = "Lưu ý: Chế độ Dark Mode chỉ áp dụng cho giao diện ứng dụng, tuyệt đối không làm biến đổi màu phôi thẻ khi xuất.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSelectThemeMode(chosenMode)
                        showThemeDialog = false
                    }
                ) {
                    Text("Xác nhận lưu")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        onSelectThemeMode(initialMode)
                        showThemeDialog = false
                    }
                ) {
                    Text("Hủy")
                }
            }
        )
    }

    // 7. System & About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("89 FITNESS & YOGA") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "VIRTUAL MEMBERSHIP CARD MAKER",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text("• Phiên bản: 1.0 (Offline-First Native Android)")
                    Text("• Các loại thẻ hỗ trợ: Gym tháng, Gym PT, Yoga tháng")
                    Text("• Dữ liệu đang lưu cục bộ: $totalCardsCount thẻ đã tạo • $totalPhotosCount ảnh gốc hội viên • ${packages.size} gói tập")
                    Text("• Quyền riêng tư: Toàn bộ ảnh hội viên và dữ liệu thẻ được lưu cục bộ trên thiết bị, không tự động tải lên đám mây hay gửi qua bất kỳ dịch vụ bên ngoài nào.")
                }
            },
            confirmButton = {
                Button(onClick = { showAboutDialog = false }) {
                    Text("Đóng")
                }
            }
        )
    }
}

@Composable
private fun SettingsGroupRowCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
