package com.example.render

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.domain.model.CardType
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateMetadata
import com.example.domain.util.FormattersAndValidators
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

data class CardRenderPayload(
    val cardType: CardType,
    val fullName: String,
    val phoneNumber: String,
    val targetGroup: TargetGroup?, // Only used when cardType == GYM_MONTHLY
    val packageName: String,
    val startDateFormatted: String?, // Only used for GYM_MONTHLY & YOGA_MONTHLY
    val endDateFormatted: String?, // Only used for GYM_MONTHLY & YOGA_MONTHLY
    val totalPtSessions: Int?, // Only used for GYM_PT
    val priceVnd: Long,
    val photoPath: String?,
    val cropScale: Float = 1f,
    val cropOffsetX: Float = 0f,
    val cropOffsetY: Float = 0f,
    val brandName: String = "89 FITNESS & YOGA",
    val brandContact: String = "Hội viên chính thức • 89 FITNESS & YOGA",
    val brandLogoPath: String? = null
)

object CardRenderEngine {

    fun renderCardBitmap(
        context: Context,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        targetWidth: Int = template.canvasWidth,
        targetHeight: Int = template.canvasHeight
    ): Bitmap {
        val width = targetWidth.coerceAtLeast(600)
        val height = targetHeight.coerceAtLeast(375)
        val scaleFactor = width.toFloat() / 1200f

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val montserratBase = try {
            ResourcesCompat.getFont(context, R.font.montserrat) ?: Typeface.SANS_SERIF
        } catch (_: Exception) {
            Typeface.SANS_SERIF
        }
        val montserratBold = Typeface.create(montserratBase, Typeface.BOLD)

        val beVietnamBase = try {
            ResourcesCompat.getFont(context, R.font.be_vietnam_pro) ?: Typeface.SANS_SERIF
        } catch (_: Exception) {
            Typeface.SANS_SERIF
        }
        val beVietnamMedium = Typeface.create(beVietnamBase, Typeface.NORMAL)
        val beVietnamBold = Typeface.create(beVietnamBase, Typeface.BOLD)

        // 1. Render Template Background
        drawTemplateBackground(canvas, width.toFloat(), height.toFloat(), scaleFactor, template)

        // 2. Render Top Header (Logo + Brand Name + Card Type Badge)
        drawHeaderSection(
            context = context,
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scaleFactor,
            payload = payload,
            template = template,
            titleTypeface = montserratBold,
            subtitleTypeface = beVietnamMedium
        )

        // 3. Render Fixed Member Photo Slot
        drawFixedPhotoSlot(
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scaleFactor,
            payload = payload,
            template = template,
            labelTypeface = beVietnamMedium
        )

        // 4. Render Card Content Strictly By CardType
        drawInformationFields(
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scaleFactor,
            payload = payload,
            template = template,
            headingTypeface = montserratBold,
            labelTypeface = beVietnamMedium,
            valueTypeface = beVietnamBold
        )

        // 5. Render Footer Bar
        drawFooterBar(
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scaleFactor,
            payload = payload,
            template = template,
            footerTypeface = beVietnamMedium
        )

        return bitmap
    }

    fun generateCroppedPhotoFile(
        sourcePhotoPath: String,
        cropScale: Float,
        cropOffsetX: Float,
        cropOffsetY: Float,
        outputFile: File,
        slotWidthPx: Int = 660,
        slotHeightPx: Int = 960
    ): Boolean {
        val srcBitmap = decodeSampledBitmap(sourcePhotoPath, 1600, 1600) ?: return false
        val outBitmap = Bitmap.createBitmap(slotWidthPx, slotHeightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)

        drawTransformedPhotoInRect(
            canvas = canvas,
            photoBitmap = srcBitmap,
            destRect = RectF(0f, 0f, slotWidthPx.toFloat(), slotHeightPx.toFloat()),
            cropScale = cropScale,
            cropOffsetX = cropOffsetX,
            cropOffsetY = cropOffsetY
        )

        outputFile.parentFile?.mkdirs()
        FileOutputStream(outputFile).use { fos ->
            outBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
            fos.flush()
        }
        return true
    }

    private fun drawTemplateBackground(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        template: TemplateMetadata
    ) {
        val bgColor = parseHexColorSafe(template.backgroundColorHex, Color.parseColor("#121316"))
        val secColor = parseHexColorSafe(template.secondaryColorHex, Color.parseColor("#1F242D"))
        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))

        val customBgBitmap = template.customBackgroundPath
            ?.takeIf { File(it).exists() }
            ?.let { decodeSampledBitmap(it, width.toInt(), height.toInt()) }

        if (customBgBitmap != null) {
            val dest = RectF(0f, 0f, width, height)
            drawCenterCropBitmap(canvas, customBgBitmap, dest)
            // Subtle dark overlay so text remains crisp and readable
            val scrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(120, 10, 12, 16)
            }
            canvas.drawRect(dest, scrimPaint)
        } else {
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, width, height,
                    intArrayOf(bgColor, secColor, bgColor),
                    floatArrayOf(0f, 0.55f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, width, height, bgPaint)

            // Decorative geometric artwork per CardType
            val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accentColor
                alpha = 34
                style = Paint.Style.FILL
            }
            when (template.cardType) {
                CardType.GYM_MONTHLY -> {
                    // Bold diagonal athletic stripes on top-right and bottom-right
                    val stripePath1 = Path().apply {
                        moveTo(width * 0.72f, 0f)
                        lineTo(width * 0.84f, 0f)
                        lineTo(width * 0.62f, height)
                        lineTo(width * 0.50f, height)
                        close()
                    }
                    canvas.drawPath(stripePath1, accentPaint)

                    val stripePath2 = Path().apply {
                        moveTo(width * 0.88f, 0f)
                        lineTo(width * 0.96f, 0f)
                        lineTo(width * 0.74f, height)
                        lineTo(width * 0.66f, height)
                        close()
                    }
                    accentPaint.alpha = 20
                    canvas.drawPath(stripePath2, accentPaint)
                }
                CardType.GYM_PT -> {
                    // Luxe gold geometric chevron & corner glow
                    val diamondPath = Path().apply {
                        moveTo(width * 0.85f, -height * 0.1f)
                        lineTo(width * 1.1f, height * 0.45f)
                        lineTo(width * 0.85f, height * 1.05f)
                        lineTo(width * 0.60f, height * 0.45f)
                        close()
                    }
                    canvas.drawPath(diamondPath, accentPaint)
                }
                CardType.YOGA_MONTHLY -> {
                    // Serene organic lotus arcs on right side
                    accentPaint.alpha = 28
                    canvas.drawCircle(width * 0.92f, height * 0.22f, 260f * scale, accentPaint)
                    accentPaint.alpha = 18
                    canvas.drawCircle(width * 0.85f, height * 0.78f, 310f * scale, accentPaint)
                }
            }
        }

        // Top accent bar & outer subtle card frame
        val topBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width, 10f * scale, topBarPaint)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            alpha = 90
            style = Paint.Style.STROKE
            strokeWidth = 2.5f * scale
        }
        val inset = 16f * scale
        canvas.drawRoundRect(
            RectF(inset, inset, width - inset, height - inset),
            24f * scale,
            24f * scale,
            borderPaint
        )
    }

    private fun drawHeaderSection(
        context: Context,
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        titleTypeface: Typeface,
        subtitleTypeface: Typeface
    ) {
        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))
        val primaryTextColor = parseHexColorSafe(template.textPrimaryHex, Color.WHITE)
        val secondaryTextColor = parseHexColorSafe(template.textSecondaryHex, Color.LTGRAY)

        // Logo circle/rounded box at top-left
        val logoSize = 84f * scale
        val logoLeft = 64f * scale
        val logoTop = 42f * scale
        val logoRect = RectF(logoLeft, logoTop, logoLeft + logoSize, logoTop + logoSize)

        val logoBitmap = payload.brandLogoPath
            ?.takeIf { File(it).exists() }
            ?.let { decodeSampledBitmap(it, 256, 256) }
            ?: BitmapFactory.decodeResource(context.resources, R.drawable.img_app_logo_fg_1794306459132)

        val logoClip = Path().apply {
            addRoundRect(logoRect, 18f * scale, 18f * scale, Path.Direction.CW)
        }
        canvas.save()
        canvas.clipPath(logoClip)
        if (logoBitmap != null) {
            drawCenterCropBitmap(canvas, logoBitmap, logoRect)
        } else {
            val fallbackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
            canvas.drawRect(logoRect, fallbackPaint)
        }
        canvas.restore()

        val logoBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.STROKE
            strokeWidth = 2.5f * scale
        }
        canvas.drawRoundRect(logoRect, 18f * scale, 18f * scale, logoBorderPaint)

        // Brand Name & Subtitle
        val brandX = logoRect.right + 22f * scale
        val maxBrandWidth = width * 0.46f
        val brandPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = titleTypeface
            color = primaryTextColor
            textSize = 34f * scale
            letterSpacing = 0.04f
        }
        val fittedBrand = fitAndEllipsizeText(
            text = payload.brandName.ifBlank { "89 FITNESS & YOGA" }.uppercase(),
            paint = brandPaint,
            maxWidth = maxBrandWidth,
            minTextSize = 22f * scale
        )
        canvas.drawText(fittedBrand, brandX, logoTop + 44f * scale, brandPaint)

        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = subtitleTypeface
            color = secondaryTextColor
            textSize = 18f * scale
            letterSpacing = 0.08f
        }
        canvas.drawText("THẺ HỘI VIÊN KỸ THUẬT SỐ", brandX, logoTop + 72f * scale, subPaint)

        // Card Type Badge Pill on Top-Right
        val badgeText = payload.cardType.cardBadgeText
        val badgeTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = titleTypeface
            textSize = 22f * scale
            color = Color.parseColor("#0F172A")
            letterSpacing = 0.05f
        }
        val textWidth = badgeTextPaint.measureText(badgeText)
        val badgePaddingH = 28f * scale
        val badgeHeight = 54f * scale
        val badgeRight = width - 56f * scale
        val badgeLeft = badgeRight - textWidth - badgePaddingH * 2
        val badgeTop = logoTop + 14f * scale
        val badgeRect = RectF(badgeLeft, badgeTop, badgeRight, badgeTop + badgeHeight)

        val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(badgeRect, badgeHeight / 2f, badgeHeight / 2f, badgeBgPaint)

        // Ensure high-contrast text on accent pill
        val luminance = (0.299 * Color.red(accentColor) + 0.587 * Color.green(accentColor) + 0.114 * Color.blue(accentColor)) / 255.0
        badgeTextPaint.color = if (luminance > 0.6) Color.parseColor("#0F172A") else Color.WHITE

        val fontMetrics = badgeTextPaint.fontMetrics
        val badgeTextY = badgeRect.centerY() - (fontMetrics.ascent + fontMetrics.descent) / 2f
        canvas.drawText(badgeText, badgeLeft + badgePaddingH, badgeTextY, badgeTextPaint)

        // Header divider line
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = primaryTextColor
            alpha = 35
            strokeWidth = 1.5f * scale
        }
        canvas.drawLine(56f * scale, 146f * scale, width - 56f * scale, 146f * scale, dividerPaint)
    }

    private fun drawFixedPhotoSlot(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        labelTypeface: Typeface
    ) {
        val slot = template.imageSlot
        val slotLeft = width * slot.xRatio
        val slotTop = height * slot.yRatio
        val slotW = width * slot.widthRatio
        val slotH = height * slot.heightRatio
        val cornerRadius = width * slot.cornerRadiusRatio
        val slotRect = RectF(slotLeft, slotTop, slotLeft + slotW, slotTop + slotH)

        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))

        // Slot shadow/backing
        val slotBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1E293B")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(slotRect, cornerRadius, cornerRadius, slotBgPaint)

        val photoBitmap = payload.photoPath
            ?.takeIf { File(it).exists() }
            ?.let { decodeSampledBitmap(it, 1200, 1200) }

        val clipPath = Path().apply {
            addRoundRect(slotRect, cornerRadius, cornerRadius, Path.Direction.CW)
        }
        canvas.save()
        canvas.clipPath(clipPath)

        if (photoBitmap != null) {
            drawTransformedPhotoInRect(
                canvas = canvas,
                photoBitmap = photoBitmap,
                destRect = slotRect,
                cropScale = payload.cropScale,
                cropOffsetX = payload.cropOffsetX,
                cropOffsetY = payload.cropOffsetY
            )
        } else {
            // Placeholder silhouette when previewing without photo
            val placeholderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#475569")
                style = Paint.Style.FILL
            }
            val cx = slotRect.centerX()
            val cy = slotRect.centerY() - 25f * scale
            canvas.drawCircle(cx, cy - 35f * scale, 48f * scale, placeholderPaint)
            canvas.drawOval(
                RectF(cx - 85f * scale, cy + 25f * scale, cx + 85f * scale, cy + 150f * scale),
                placeholderPaint
            )
            val hintPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = labelTypeface
                textSize = 20f * scale
                color = Color.parseColor("#CBD5E1")
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("ẢNH HỘI VIÊN", cx, slotRect.bottom - 36f * scale, hintPaint)
        }
        canvas.restore()

        // Crisp fixed-frame border
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.STROKE
            strokeWidth = 4f * scale
        }
        canvas.drawRoundRect(slotRect, cornerRadius, cornerRadius, framePaint)
    }

    private fun drawInformationFields(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        headingTypeface: Typeface,
        labelTypeface: Typeface,
        valueTypeface: Typeface
    ) {
        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))
        val primaryTextColor = parseHexColorSafe(template.textPrimaryHex, Color.WHITE)
        val secondaryTextColor = parseHexColorSafe(template.textSecondaryHex, Color.parseColor("#CBD5E1"))

        val contentLeft = width * 0.365f
        val contentRight = width - 56f * scale
        val maxContentWidth = contentRight - contentLeft
        val colGap = 24f * scale
        val halfColWidth = (maxContentWidth - colGap) / 2f
        val col2Left = contentLeft + halfColWidth + colGap

        // Member Full Name block (common to all 3 card types)
        drawFieldLabel(canvas, "HỌ VÀ TÊN HỘI VIÊN", contentLeft, 198f * scale, scale, secondaryTextColor, labelTypeface)

        val namePaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = headingTypeface
            color = primaryTextColor
            textSize = 42f * scale
        }
        val displayName = payload.fullName.trim().ifEmpty { "CHƯA NHẬP HỌ TÊN" }.uppercase()
        val fittedName = fitAndEllipsizeText(
            text = displayName,
            paint = namePaint,
            maxWidth = maxContentWidth,
            minTextSize = 26f * scale
        )
        canvas.drawText(fittedName, contentLeft, 248f * scale, namePaint)

        // Subtle accent underline under member name
        val underlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            alpha = 160
            strokeWidth = 3f * scale
        }
        canvas.drawLine(contentLeft, 266f * scale, contentLeft + 140f * scale, 266f * scale, underlinePaint)

        when (payload.cardType) {
            CardType.GYM_MONTHLY -> {
                // Row 2: Nhóm đối tượng (Nam / Nữ / Trẻ em) + Số điện thoại
                val groupLabel = (payload.targetGroup ?: TargetGroup.NAM).displayLabel
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 290f * scale, contentLeft + halfColWidth, 396f * scale),
                    label = "NHÓM ĐỐI TƯỢNG",
                    value = groupLabel,
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    boxStrokeColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 290f * scale, contentRight, 396f * scale),
                    label = "SỐ ĐIỆN THOẠI",
                    value = payload.phoneNumber.ifBlank { "—" },
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    boxStrokeColor = primaryTextColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )

                // Row 3: Ngày bắt đầu + Ngày hết hạn
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 414f * scale, contentLeft + halfColWidth, 520f * scale),
                    label = "NGÀY BẮT ĐẦU",
                    value = payload.startDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    boxStrokeColor = primaryTextColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 414f * scale, contentRight, 520f * scale),
                    label = "NGÀY HẾT HẠN",
                    value = payload.endDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    boxStrokeColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )

                // Row 4: Loại thẻ & Giá tiền
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 538f * scale, contentLeft + halfColWidth, 644f * scale),
                    label = "LOẠI THẺ",
                    value = "GYM MONTHLY",
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    boxStrokeColor = primaryTextColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 538f * scale, contentRight, 644f * scale),
                    label = "GIÁ TIỀN",
                    value = FormattersAndValidators.formatVnd(payload.priceVnd),
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = Color.parseColor("#FBBF24"),
                    boxStrokeColor = Color.parseColor("#FBBF24"),
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
            }

            CardType.GYM_PT -> {
                // Strictly NO startDate and NO endDate and NO remaining sessions!
                // Row 2: Số điện thoại + Loại thẻ (PERSONAL TRAINING)
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 296f * scale, contentLeft + halfColWidth, 412f * scale),
                    label = "SỐ ĐIỆN THOẠI",
                    value = payload.phoneNumber.ifBlank { "—" },
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    boxStrokeColor = primaryTextColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 296f * scale, contentRight, 412f * scale),
                    label = "LOẠI THẺ",
                    value = "PERSONAL TRAINING",
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    boxStrokeColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )

                // Row 3: Tổng số buổi PT + Giá tiền
                val sessionsText = "${payload.totalPtSessions ?: 0} BUỔI PT"
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 436f * scale, contentLeft + halfColWidth, 566f * scale),
                    label = "TỔNG SỐ BUỔI PT",
                    value = sessionsText,
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    boxStrokeColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 436f * scale, contentRight, 566f * scale),
                    label = "GIÁ TIỀN",
                    value = FormattersAndValidators.formatVnd(payload.priceVnd),
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    boxStrokeColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
            }

            CardType.YOGA_MONTHLY -> {
                // Strictly NO targetGroup (Nam / Nữ / Trẻ em)!
                // Row 2: Số điện thoại + Loại thẻ (YOGA MONTHLY)
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 290f * scale, contentLeft + halfColWidth, 396f * scale),
                    label = "SỐ ĐIỆN THOẠI",
                    value = payload.phoneNumber.ifBlank { "—" },
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    boxStrokeColor = primaryTextColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 290f * scale, contentRight, 396f * scale),
                    label = "LOẠI THẺ",
                    value = "YOGA MONTHLY",
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    boxStrokeColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )

                // Row 3: Ngày bắt đầu + Ngày hết hạn
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 414f * scale, contentLeft + halfColWidth, 520f * scale),
                    label = "NGÀY BẮT ĐẦU",
                    value = payload.startDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    boxStrokeColor = primaryTextColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface
                )
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 414f * scale, contentRight, 520f * scale),
                    label = "NGÀY HẾT HẠN",
                    value = payload.endDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    boxStrokeColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )

                // Row 4: Giá tiền (Full width highlight)
                drawInfoBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 538f * scale, contentRight, 644f * scale),
                    label = "GIÁ TIỀN",
                    value = FormattersAndValidators.formatVnd(payload.priceVnd),
                    scale = scale,
                    labelColor = secondaryTextColor,
                    valueColor = Color.parseColor("#FDE68A"),
                    boxStrokeColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface
                )
            }
        }
    }

    private fun drawFooterBar(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        footerTypeface: Typeface
    ) {
        val secondaryTextColor = parseHexColorSafe(template.textSecondaryHex, Color.LTGRAY)
        val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = footerTypeface
            textSize = 18f * scale
            color = secondaryTextColor
            alpha = 200
        }
        val contact = payload.brandContact.trim().ifEmpty { payload.brandName }
        val fittedContact = fitAndEllipsizeText(
            text = contact,
            paint = footerPaint,
            maxWidth = width - 112f * scale,
            minTextSize = 15f * scale
        )
        canvas.drawText(fittedContact, 64f * scale, height - 38f * scale, footerPaint)
    }

    private fun drawFieldLabel(
        canvas: Canvas,
        label: String,
        x: Float,
        y: Float,
        scale: Float,
        color: Int,
        typeface: Typeface
    ) {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            this.typeface = typeface
            this.color = color
            this.textSize = 17f * scale
            this.letterSpacing = 0.06f
        }
        canvas.drawText(label, x, y, paint)
    }

    private fun drawInfoBox(
        canvas: Canvas,
        rect: RectF,
        label: String,
        value: String,
        scale: Float,
        labelColor: Int,
        valueColor: Int,
        boxStrokeColor: Int,
        labelTypeface: Typeface,
        valueTypeface: Typeface
    ) {
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            alpha = 70
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(rect, 16f * scale, 16f * scale, bgPaint)

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = boxStrokeColor
            alpha = 65
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * scale
        }
        canvas.drawRoundRect(rect, 16f * scale, 16f * scale, strokePaint)

        val padX = 20f * scale
        val maxValWidth = (rect.width() - padX * 2).coerceAtLeast(60f)

        val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = labelTypeface
            color = labelColor
            textSize = 16f * scale
            letterSpacing = 0.05f
        }
        canvas.drawText(label, rect.left + padX, rect.top + 32f * scale, labelPaint)

        val valPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = valueTypeface
            color = valueColor
            textSize = 28f * scale
        }
        val fittedVal = fitAndEllipsizeText(
            text = value,
            paint = valPaint,
            maxWidth = maxValWidth,
            minTextSize = 19f * scale
        )
        canvas.drawText(fittedVal, rect.left + padX, rect.bottom - 22f * scale, valPaint)
    }

    fun fitAndEllipsizeText(
        text: String,
        paint: TextPaint,
        maxWidth: Float,
        minTextSize: Float
    ): String {
        if (text.isEmpty() || maxWidth <= 0f) return text
        var currentSize = paint.textSize
        while (paint.measureText(text) > maxWidth && currentSize > minTextSize) {
            currentSize = (currentSize - 1.5f).coerceAtLeast(minTextSize)
            paint.textSize = currentSize
        }
        return if (paint.measureText(text) > maxWidth) {
            TextUtils.ellipsize(text, paint, maxWidth, TextUtils.TruncateAt.END).toString()
        } else {
            text
        }
    }

    private fun drawTransformedPhotoInRect(
        canvas: Canvas,
        photoBitmap: Bitmap,
        destRect: RectF,
        cropScale: Float,
        cropOffsetX: Float,
        cropOffsetY: Float
    ) {
        val bw = photoBitmap.width.toFloat().coerceAtLeast(1f)
        val bh = photoBitmap.height.toFloat().coerceAtLeast(1f)
        val baseScale = max(destRect.width() / bw, destRect.height() / bh)
        val userScale = cropScale.coerceIn(0.5f, 5.0f)
        val totalScale = baseScale * userScale

        val scaledW = bw * totalScale
        val scaledH = bh * totalScale

        // cropOffsetX and cropOffsetY are normalized relative to slot width/height (-1.0f..1.0f)
        val dx = destRect.centerX() - (scaledW / 2f) + (cropOffsetX * destRect.width())
        val dy = destRect.centerY() - (scaledH / 2f) + (cropOffsetY * destRect.height())

        val matrix = Matrix().apply {
            postScale(totalScale, totalScale)
            postTranslate(dx, dy)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(photoBitmap, matrix, paint)
    }

    private fun drawCenterCropBitmap(canvas: Canvas, bitmap: Bitmap, destRect: RectF) {
        drawTransformedPhotoInRect(canvas, bitmap, destRect, 1f, 0f, 0f)
    }

    fun decodeSampledBitmap(path: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        return try {
            val file = File(path)
            if (!file.exists()) return null
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, options)
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
            options.inJustDecodeBounds = false
            options.inPreferredConfig = Bitmap.Config.ARGB_8888
            BitmapFactory.decodeFile(path, options)
        } catch (_: Exception) {
            null
        }
    }

    private fun calculateInSampleSize(
        options: BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    fun parseHexColorSafe(hex: String, fallback: Int): Int {
        return try {
            Color.parseColor(hex.trim())
        } catch (_: Exception) {
            fallback
        }
    }
}
