package com.example.render

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.util.LruCache
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.domain.model.ArtworkPatternStyle
import com.example.domain.model.CardIconType
import com.example.domain.model.CardType
import com.example.domain.model.HeaderLayoutStyle
import com.example.domain.model.InfoBoxStyle
import com.example.domain.model.PhotoFrameShape
import com.example.domain.model.TargetGroup
import com.example.domain.model.TemplateCategory
import com.example.domain.model.TemplateMetadata
import com.example.domain.util.FormattersAndValidators
import java.io.File
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

data class CardRenderPayload(
    val cardType: CardType,
    val templateId: String,
    val fullName: String,
    val phoneNumber: String,
    val targetGroup: TargetGroup?, // Only for GYM_MONTHLY
    val packageName: String = "",
    val durationMonths: Int?, // For GYM_MONTHLY & YOGA_MONTHLY
    val startDateFormatted: String?, // For GYM_MONTHLY & YOGA_MONTHLY
    val endDateFormatted: String?, // For GYM_MONTHLY & YOGA_MONTHLY
    val totalPtSessions: Int?, // Only for GYM_PT
    val priceVnd: Long,
    val photoPath: String?,
    val cropScale: Float = 1f,
    val cropOffsetX: Float = 0f,
    val cropOffsetY: Float = 0f,
    val brandName: String = "89 FITNESS & YOGA",
    val brandContact: String = "Hội viên chính thức • 89 FITNESS & YOGA",
    val brandLogoPath: String? = null
)

object CardRenderEngine {

    // Cache 8:5 sample thumbnails (760x475) for smooth scrolling in 1-column template lists
    private val thumbnailCache = object : LruCache<String, Bitmap>(28) {}

    // Cache decoded background artwork drawables so they are not re-decoded repeatedly
    private val artworkResourceCache = object : LruCache<Int, Bitmap>(8) {}

    fun getOrRenderSampleThumbnail(
        context: Context,
        template: TemplateMetadata,
        brandName: String = "89 FITNESS & YOGA",
        previewCardType: CardType = template.category.primaryPreviewCardType()
    ): Bitmap {
        val cacheKey = "${template.templateId}_v${template.templateVersion}_${previewCardType.code}_$brandName"
        thumbnailCache.get(cacheKey)?.let { if (!it.isRecycled) return it }

        val samplePayload = buildSamplePayload(template, brandName, previewCardType)
        val bmp = renderCardBitmap(
            context = context,
            payload = samplePayload,
            template = template,
            targetWidth = 760,
            targetHeight = 475
        )
        thumbnailCache.put(cacheKey, bmp)
        return bmp
    }

    /**
     * Neutral sample payload for template previewing (Section 10.1):
     * Strictly uses "HỌ VÀ TÊN" placeholder instead of any hardcoded fake person name.
     */
    fun buildSamplePayload(
        template: TemplateMetadata,
        brandName: String = "89 FITNESS & YOGA",
        previewCardType: CardType = template.category.primaryPreviewCardType()
    ): CardRenderPayload = CardRenderPayload(
        cardType = previewCardType,
        templateId = template.templateId,
        fullName = "HỌ VÀ TÊN",
        phoneNumber = "0989 898 989",
        targetGroup = if (previewCardType == CardType.GYM_MONTHLY) TargetGroup.NAM else null,
        packageName = when (previewCardType) {
            CardType.GYM_MONTHLY -> "3 tháng"
            CardType.YOGA_MONTHLY -> "2 tháng"
            CardType.GYM_PT -> "Gói 24 buổi PT"
        },
        durationMonths = when (previewCardType) {
            CardType.GYM_MONTHLY -> 3
            CardType.YOGA_MONTHLY -> 2
            CardType.GYM_PT -> null
        },
        startDateFormatted = if (previewCardType != CardType.GYM_PT) "01/11/2026" else null,
        endDateFormatted = if (previewCardType != CardType.GYM_PT) "01/02/2027" else null,
        totalPtSessions = if (previewCardType == CardType.GYM_PT) 24 else null,
        priceVnd = when (previewCardType) {
            CardType.GYM_MONTHLY -> 800_000L
            CardType.GYM_PT -> 6_000_000L
            CardType.YOGA_MONTHLY -> 1_000_000L
        },
        photoPath = null,
        brandName = brandName
    )

    fun renderCardBitmap(
        context: Context,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        targetWidth: Int = template.canvasWidth,
        targetHeight: Int = template.canvasHeight
    ): Bitmap {
        val width = targetWidth.coerceAtLeast(480)
        val height = targetHeight.coerceAtLeast(300)
        val scale = width.toFloat() / 1200f

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val montserratBase = try {
            ResourcesCompat.getFont(context, R.font.montserrat) ?: Typeface.SANS_SERIF
        } catch (_: Exception) {
            Typeface.SANS_SERIF
        }
        val montserratBold = Typeface.create(montserratBase, Typeface.BOLD)

        val beVietnamBase = try {
            ResourcesCompat.getFont(context, R.font.be_vietnam_pro) ?: Typeface.SANS_SERIF
        } catch (_: Exception) {
            Typeface.SANS_SERIF
        }
        val beVietnamMedium = Typeface.create(beVietnamBase, Typeface.NORMAL)
        val beVietnamBold = Typeface.create(beVietnamBase, Typeface.BOLD)

        // 1. Render Multi-Layered Artwork Background (AI Background Texture + Rich Vector/Canvas Art + Content Contrast Shield)
        drawTemplateArtwork(context, canvas, width.toFloat(), height.toFloat(), scale, template)

        // 2. Render Clean Header (Brand Logo + Brand Name + Single Vietnamese Card Type Label with Vector Icon)
        drawHeaderByStyle(
            context = context,
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scale,
            payload = payload,
            template = template,
            titleTypeface = montserratBold,
            subtitleTypeface = beVietnamBold
        )

        // 3. Render Prominent Member Photo Frame with Elevation Shadow & Double Bevel Border
        drawPhotoSlotByShape(
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scale,
            payload = payload,
            template = template,
            labelTypeface = beVietnamBold
        )

        // 4. Render High-Contrast Member Info Panels & Highlight Badges (Priority #1 Name, #3 Duration/PT, #4 Expiry, #5 Price)
        drawFieldsByStyle(
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scale,
            payload = payload,
            template = template,
            headingTypeface = montserratBold,
            labelTypeface = beVietnamMedium,
            valueTypeface = beVietnamBold
        )

        // 5. Render Footer Bar
        drawFooterBar(
            canvas = canvas,
            width = width.toFloat(),
            height = height.toFloat(),
            scale = scale,
            payload = payload,
            template = template,
            footerTypeface = beVietnamMedium
        )

        return bitmap
    }

    private fun isLightPalette(template: TemplateMetadata): Boolean {
        val bg = parseHexColorSafe(template.backgroundColorHex, Color.BLACK)
        val luminance = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0
        return luminance > 0.58
    }

    private const val DRAWABLE_BG_UNIVERSAL = "bg_art_universal_luxury_1794349441347"
    private const val DRAWABLE_BG_GYM = "bg_art_gym_athletic_1794349441059"
    private const val DRAWABLE_BG_YOGA = "bg_art_yoga_wellness_1794349442642"
    private const val DRAWABLE_BG_PT = "bg_art_pt_titanium_1794349443945"
    private const val DRAWABLE_APP_LOGO = "img_app_logo_fg_1794306459132"

    @Suppress("DiscouragedApi")
    fun resolveDrawableResId(context: Context, drawableName: String): Int {
        return try {
            val runtimeId = context.resources.getIdentifier(drawableName, "drawable", context.packageName)
            if (runtimeId != 0) {
                runtimeId
            } else {
                context.resources.getIdentifier(drawableName, "drawable", "com.example")
            }
        } catch (_: Exception) {
            0
        }
    }

    private fun getCategoryArtworkBitmap(context: Context, category: TemplateCategory): Bitmap? {
        val drawableName = when (category) {
            TemplateCategory.UNIVERSAL -> DRAWABLE_BG_UNIVERSAL
            TemplateCategory.GYM -> DRAWABLE_BG_GYM
            TemplateCategory.YOGA -> DRAWABLE_BG_YOGA
            TemplateCategory.PT -> DRAWABLE_BG_PT
        }
        val resId = resolveDrawableResId(context, drawableName)
        if (resId == 0) return null

        artworkResourceCache.get(resId)?.let { if (!it.isRecycled) return it }
        return try {
            val opts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeResource(context.resources, resId, opts)?.also {
                artworkResourceCache.put(resId, it)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun drawTemplateArtwork(
        context: Context,
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        template: TemplateMetadata
    ) {
        val bgPrimary = parseHexColorSafe(template.backgroundColorHex, Color.parseColor("#101E38"))
        val bgSecondary = parseHexColorSafe(template.secondaryColorHex, Color.parseColor("#1E325C"))
        val accent = parseHexColorSafe(template.accentColorHex, Color.parseColor("#D4AF37"))
        val priceColor = parseHexColorSafe(template.priceHighlightHex, accent)
        val isLight = isLightPalette(template)

        // Base rich multi-stop gradient
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, width, height,
                intArrayOf(bgPrimary, bgSecondary, bgPrimary),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        // Blend curated AI 8:5 artwork texture at controlled opacity so it adds depth without overpowering text
        val artBitmap = getCategoryArtworkBitmap(context, template.category)
        if (artBitmap != null && !artBitmap.isRecycled) {
            val artAlpha = when (template.artworkPattern) {
                ArtworkPatternStyle.A1_UNIVERSAL_PREMIUM -> 72
                ArtworkPatternStyle.A2_UNIVERSAL_MINIMAL -> 28
                ArtworkPatternStyle.A3_UNIVERSAL_FUTURISTIC -> 58
                ArtworkPatternStyle.G1_ATHLETIC_PERFORMANCE -> 86
                ArtworkPatternStyle.G2_LUXURY_BLACK_GOLD -> 56
                ArtworkPatternStyle.G3_BOLD_SPORT_EDITORIAL -> 30
                ArtworkPatternStyle.Y1_ZEN_MINIMAL -> 46
                ArtworkPatternStyle.Y2_BOTANICAL_ELEGANCE -> 54
                ArtworkPatternStyle.Y3_LUXURY_WELLNESS -> 48
                ArtworkPatternStyle.P1_ELITE_PERSONAL_TRAINER -> 68
                ArtworkPatternStyle.P2_PERFORMANCE_LAB -> 26
                ArtworkPatternStyle.P3_BLACK_TITANIUM -> 78
            }
            val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = artAlpha
            }
            drawCenterCropBitmap(canvas, artBitmap, RectF(0f, 0f, width, height), bitmapPaint)
        }

        // Ambient radial spotlight behind content & photo areas for depth
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                width * 0.78f,
                height * 0.25f,
                480f * scale,
                Color.argb(if (isLight) 38 else 64, Color.red(accent), Color.green(accent), Color.blue(accent)),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width, height, glowPaint)

        val artPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent
            style = Paint.Style.FILL
        }

        when (template.artworkPattern) {
            ArtworkPatternStyle.A1_UNIVERSAL_PREMIUM -> {
                // Luxury sapphire & champagne gold double frame + flowing ribbon arcs
                val frameStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2.6f * scale
                    alpha = 180
                }
                val m = 20f * scale
                canvas.drawRoundRect(RectF(m, m, width - m, height - m), 22f * scale, 22f * scale, frameStroke)
                frameStroke.strokeWidth = 1.2f * scale
                frameStroke.alpha = 95
                canvas.drawRoundRect(
                    RectF(m + 8f * scale, m + 8f * scale, width - m - 8f * scale, height - m - 8f * scale),
                    16f * scale,
                    16f * scale,
                    frameStroke
                )

                val arcStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2f * scale
                    alpha = 75
                }
                for (i in 0..3) {
                    val offset = i * 20f * scale
                    val path = Path().apply {
                        moveTo(width * 0.48f, height + offset)
                        cubicTo(
                            width * 0.68f, height * 0.64f + offset,
                            width * 0.86f, height * 0.84f + offset,
                            width + 24f, height * 0.46f + offset
                        )
                    }
                    canvas.drawPath(path, arcStroke)
                }
            }

            ArtworkPatternStyle.A2_UNIVERSAL_MINIMAL -> {
                // Bright alabaster card with cobalt blue top bar, coral accent pill, and Swiss architectural geometry
                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, width, 12f * scale, artPaint)
                val coralPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = priceColor
                    style = Paint.Style.FILL
                }
                canvas.drawRect(width * 0.68f, 0f, width, 12f * scale, coralPaint)

                // Soft geometric halo behind right photo slot
                artPaint.alpha = 22
                canvas.drawCircle(width * 0.81f, height * 0.52f, 230f * scale, artPaint)
                coralPaint.alpha = 18
                canvas.drawCircle(width * 0.14f, height * 0.85f, 150f * scale, coralPaint)

                val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    alpha = 45
                    strokeWidth = 1.8f * scale
                }
                canvas.drawLine(width * 0.655f, 136f * scale, width * 0.655f, height - 56f * scale, dividerPaint)
            }

            ArtworkPatternStyle.A3_UNIVERSAL_FUTURISTIC -> {
                // Luminous electric blue & cyan polygon facets + precision HUD chamfered frame
                val facetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = LinearGradient(
                        width * 0.55f, 0f, width, height * 0.65f,
                        Color.argb(55, Color.red(accent), Color.green(accent), Color.blue(accent)),
                        Color.TRANSPARENT,
                        Shader.TileMode.CLAMP
                    )
                }
                val poly = Path().apply {
                    moveTo(width * 0.62f, 0f)
                    lineTo(width, 0f)
                    lineTo(width, height * 0.58f)
                    lineTo(width * 0.78f, height * 0.36f)
                    close()
                }
                canvas.drawPath(poly, facetPaint)

                val hudStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2.4f * scale
                    alpha = 145
                }
                val pad = 22f * scale
                val corner = 26f * scale
                val hudPath = Path().apply {
                    moveTo(pad + corner, pad)
                    lineTo(width - pad - corner, pad)
                    lineTo(width - pad, pad + corner)
                    lineTo(width - pad, height - pad - corner)
                    lineTo(width - pad - corner, height - pad)
                    lineTo(pad + corner, height - pad)
                    lineTo(pad, height - pad - corner)
                    lineTo(pad, pad + corner)
                    close()
                }
                canvas.drawPath(hudPath, hudStroke)
            }

            ArtworkPatternStyle.G1_ATHLETIC_PERFORMANCE -> {
                // Dynamic crimson & volt gold athletic power ribbons + top speed bar
                val crimsonSlash = Path().apply {
                    moveTo(width * 0.66f, 0f)
                    lineTo(width * 0.82f, 0f)
                    lineTo(width * 0.56f, height)
                    lineTo(width * 0.40f, height)
                    close()
                }
                artPaint.alpha = 52
                canvas.drawPath(crimsonSlash, artPaint)

                val goldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = priceColor
                    style = Paint.Style.FILL
                    alpha = 38
                }
                val goldSlash = Path().apply {
                    moveTo(width * 0.84f, 0f)
                    lineTo(width * 0.92f, 0f)
                    lineTo(width * 0.66f, height)
                    lineTo(width * 0.58f, height)
                    close()
                }
                canvas.drawPath(goldSlash, goldPaint)

                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, width * 0.72f, 12f * scale, artPaint)
                goldPaint.alpha = 255
                canvas.drawRect(width * 0.72f, 0f, width, 12f * scale, goldPaint)
            }

            ArtworkPatternStyle.G2_LUXURY_BLACK_GOLD -> {
                // Warm brushed bronze & gold royal crest lines + golden sunburst behind right arch photo
                val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 3f * scale
                    alpha = 210
                }
                val m1 = 18f * scale
                val m2 = 28f * scale
                canvas.drawRoundRect(RectF(m1, m1, width - m1, height - m1), 20f * scale, 20f * scale, strokePaint)
                strokePaint.strokeWidth = 1.3f * scale
                strokePaint.alpha = 120
                canvas.drawRoundRect(RectF(m2, m2, width - m2, height - m2), 14f * scale, 14f * scale, strokePaint)

                artPaint.alpha = 36
                canvas.drawCircle(width * 0.81f, height * 0.52f, 225f * scale, artPaint)
                strokePaint.alpha = 70
                canvas.drawCircle(width * 0.81f, height * 0.52f, 242f * scale, strokePaint)
            }

            ArtworkPatternStyle.G3_BOLD_SPORT_EDITORIAL -> {
                // High-contrast light magazine editorial layout with bold orange sidebar & stark geometric block
                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, 54f * scale, height, artPaint)

                val darkWedgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#111827")
                    alpha = 22
                    style = Paint.Style.FILL
                }
                val wedge = Path().apply {
                    moveTo(width * 0.64f, 0f)
                    lineTo(width, 0f)
                    lineTo(width, height)
                    lineTo(width * 0.76f, height)
                    close()
                }
                canvas.drawPath(wedge, darkWedgePaint)

                artPaint.alpha = 38
                val topAccent = Path().apply {
                    moveTo(width * 0.58f, 0f)
                    lineTo(width, 0f)
                    lineTo(width, height * 0.34f)
                    close()
                }
                canvas.drawPath(topAccent, artPaint)
            }

            ArtworkPatternStyle.Y1_ZEN_MINIMAL -> {
                // Serene warm ivory & sage green Enso Zen circle + organic horizon waves
                val ensoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 16f * scale
                    strokeCap = Paint.Cap.ROUND
                    alpha = 36
                }
                val r = 215f * scale
                val cx = width * 0.19f
                val cy = height * 0.52f
                canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 20f, 310f, false, ensoPaint)

                val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2f * scale
                    alpha = 55
                }
                for (i in 0..2) {
                    val dy = i * 16f * scale
                    val wave = Path().apply {
                        moveTo(0f, height * 0.86f + dy)
                        cubicTo(
                            width * 0.35f, height * 0.78f + dy,
                            width * 0.65f, height * 0.94f + dy,
                            width, height * 0.84f + dy
                        )
                    }
                    canvas.drawPath(wave, wavePaint)
                }
            }

            ArtworkPatternStyle.Y2_BOTANICAL_ELEGANCE -> {
                // Organic botanical leaf silhouettes & terracotta gold accents on soft sage cream
                artPaint.alpha = 30
                val leafLeft = Path().apply {
                    moveTo(0f, height * 0.35f)
                    quadTo(width * 0.18f, height * 0.25f, width * 0.24f, 0f)
                    quadTo(width * 0.06f, height * 0.10f, 0f, height * 0.35f)
                    close()
                }
                canvas.drawPath(leafLeft, artPaint)

                val leafRight = Path().apply {
                    moveTo(width, height)
                    quadTo(width * 0.68f, height * 0.86f, width * 0.74f, height * 0.38f)
                    quadTo(width * 0.94f, height * 0.60f, width, height)
                    close()
                }
                canvas.drawPath(leafRight, artPaint)

                val stemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = priceColor
                    style = Paint.Style.STROKE
                    strokeWidth = 2.2f * scale
                    alpha = 85
                }
                val stem = Path().apply {
                    moveTo(width * 0.05f, height - 24f * scale)
                    cubicTo(width * 0.35f, height - 58f * scale, width * 0.65f, height - 12f * scale, width * 0.95f, height - 42f * scale)
                }
                canvas.drawPath(stem, stemPaint)
            }

            ArtworkPatternStyle.Y3_LUXURY_WELLNESS -> {
                // Soft lavender ivory & lotus geometric mandala around circular portrait frame
                val lotusCx = width * 0.188f
                val lotusCy = height * 0.49f
                val petalStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 2f * scale
                    alpha = 52
                }
                for (deg in 0 until 360 step 30) {
                    val rad = Math.toRadians(deg.toDouble())
                    val px = lotusCx + (cos(rad) * 185f * scale).toFloat()
                    val py = lotusCy + (sin(rad) * 185f * scale).toFloat()
                    canvas.drawCircle(px, py, 46f * scale, petalStroke)
                }

                artPaint.alpha = 24
                canvas.drawCircle(lotusCx, lotusCy, 210f * scale, artPaint)
            }

            ArtworkPatternStyle.P1_ELITE_PERSONAL_TRAINER -> {
                // Rich gunmetal & amber gold power chevrons + top/bottom championship rules
                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, width, 10f * scale, artPaint)
                canvas.drawRect(0f, height - 10f * scale, width, height, artPaint)

                val chevPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    style = Paint.Style.STROKE
                    strokeWidth = 12f * scale
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                    alpha = 42
                }
                for (i in 0..2) {
                    val ox = width * 0.74f + i * 46f * scale
                    val path = Path().apply {
                        moveTo(ox, height * 0.18f)
                        lineTo(ox + 52f * scale, height * 0.50f)
                        lineTo(ox, height * 0.82f)
                    }
                    canvas.drawPath(path, chevPaint)
                }
            }

            ArtworkPatternStyle.P2_PERFORMANCE_LAB -> {
                // Bright technical ice-silver lab grid + cyan telemetry corner brackets
                val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    alpha = 28
                    strokeWidth = 1.2f * scale
                }
                val step = 56f * scale
                var x = step
                while (x < width) {
                    canvas.drawLine(x, 0f, x, height, gridPaint)
                    x += step
                }
                var y = step
                while (y < height) {
                    canvas.drawLine(0f, y, width, y, gridPaint)
                    y += step
                }

                val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    alpha = 210
                    strokeWidth = 4.5f * scale
                    style = Paint.Style.STROKE
                }
                val m = 22f * scale
                val len = 40f * scale
                canvas.drawLine(m, m, m + len, m, cornerPaint)
                canvas.drawLine(m, m, m, m + len, cornerPaint)
                canvas.drawLine(width - m, m, width - m - len, m, cornerPaint)
                canvas.drawLine(width - m, m, width - m, m + len, cornerPaint)
                canvas.drawLine(m, height - m, m + len, height - m, cornerPaint)
                canvas.drawLine(m, height - m, m, height - m - len, cornerPaint)
                canvas.drawLine(width - m, height - m, width - m - len, height - m, cornerPaint)
                canvas.drawLine(width - m, height - m, width - m, height - m - len, cornerPaint)
            }

            ArtworkPatternStyle.P3_BLACK_TITANIUM -> {
                // Brushed dark titanium metallic sheen + crimson power pillar + silver frame
                artPaint.alpha = 255
                canvas.drawRect(0f, 0f, 38f * scale, height, artPaint)

                val silverPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#CBD5E1")
                    alpha = 255
                }
                canvas.drawRect(38f * scale, 0f, 44f * scale, height, silverPaint)

                val brushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    alpha = 16
                    strokeWidth = 1.2f * scale
                }
                var by = 18f * scale
                while (by < height) {
                    canvas.drawLine(44f * scale, by, width, by, brushPaint)
                    by += 14f * scale
                }

                val metalBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#94A3B8")
                    style = Paint.Style.STROKE
                    strokeWidth = 2.2f * scale
                    alpha = 140
                }
                val m = 22f * scale
                canvas.drawRoundRect(RectF(44f * scale + m, m, width - m, height - m), 14f * scale, 14f * scale, metalBorder)
            }
        }

        // Content Area Contrast Backing Panel so member data ALWAYS stands out clearly (Section 6)
        val panelLeft = width * template.contentLeftRatio - 18f * scale
        val panelRight = width * template.contentRightRatio + 18f * scale
        val panelTop = 152f * scale
        val panelBottom = 646f * scale
        val panelRect = RectF(panelLeft, panelTop, panelRight, panelBottom)
        val panelFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isLight) Color.argb(175, 255, 255, 255) else Color.argb(128, 8, 12, 22)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(panelRect, 22f * scale, 22f * scale, panelFillPaint)

        val panelStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent
            alpha = if (isLight) 75 else 95
            style = Paint.Style.STROKE
            strokeWidth = 1.6f * scale
        }
        canvas.drawRoundRect(panelRect, 22f * scale, 22f * scale, panelStrokePaint)
    }

    private fun drawCenterCropBitmap(
        canvas: Canvas,
        bitmap: Bitmap,
        destRect: RectF,
        paint: Paint
    ) {
        val bw = bitmap.width.toFloat().coerceAtLeast(1f)
        val bh = bitmap.height.toFloat().coerceAtLeast(1f)
        val scale = max(destRect.width() / bw, destRect.height() / bh)
        val dx = destRect.centerX() - (bw * scale) / 2f
        val dy = destRect.centerY() - (bh * scale) / 2f
        val matrix = Matrix().apply {
            postScale(scale, scale)
            postTranslate(dx, dy)
        }
        canvas.drawBitmap(bitmap, matrix, paint)
    }

    private fun drawHeaderByStyle(
        context: Context,
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        titleTypeface: Typeface,
        subtitleTypeface: Typeface
    ) {
        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))
        val primaryTextColor = parseHexColorSafe(template.textPrimaryHex, Color.WHITE)
        val secondaryTextColor = parseHexColorSafe(template.textSecondaryHex, Color.LTGRAY)
        val isLight = isLightPalette(template)

        val customLogo = payload.brandLogoPath
            ?.takeIf { File(it).exists() }
            ?.let { decodeSampledBitmap(it, 256, 256) }
        val defaultLogoResId = resolveDrawableResId(context, DRAWABLE_APP_LOGO)
        val logoBitmap = customLogo ?: defaultLogoResId.takeIf { it != 0 }?.let { resId ->
            artworkResourceCache.get(resId)?.takeIf { !it.isRecycled }
                ?: BitmapFactory.decodeResource(context.resources, resId)?.also {
                    artworkResourceCache.put(resId, it)
                }
        }

        val leftStart = when {
            template.artworkPattern == ArtworkPatternStyle.G3_BOLD_SPORT_EDITORIAL -> 96f * scale
            template.artworkPattern == ArtworkPatternStyle.P3_BLACK_TITANIUM -> 82f * scale
            else -> 64f * scale
        }

        val logoSize = 78f * scale
        val logoTop = 34f * scale
        val logoRect = RectF(leftStart, logoTop, leftStart + logoSize, logoTop + logoSize)
        drawLogoBox(canvas, logoBitmap, logoRect, accentColor, scale)
        if (customLogo != null && !customLogo.isRecycled) {
            customLogo.recycle()
        }

        val brandX = logoRect.right + 20f * scale
        val brandPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = titleTypeface
            color = primaryTextColor
            textSize = 33f * scale
            letterSpacing = 0.04f
        }
        val fittedBrand = fitAndEllipsizeText(
            text = payload.brandName.ifBlank { "89 FITNESS & YOGA" }.uppercase(),
            paint = brandPaint,
            maxWidth = width - brandX - 56f * scale,
            minTextSize = 20f * scale
        )
        canvas.drawText(fittedBrand, brandX, logoTop + 38f * scale, brandPaint)

        // Single concise Vietnamese card type badge + vector icon right below brand name (Section 7)
        val cardTypeLabel = payload.cardType.shortCardLabelVi.uppercase()
        val cardTypePaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = subtitleTypeface
            color = if (isLight) Color.WHITE else Color.parseColor("#0F172A")
            textSize = 18.5f * scale
            letterSpacing = 0.04f
        }
        val iconSize = 20f * scale
        val badgeTextWidth = cardTypePaint.measureText(cardTypeLabel)
        val badgeW = iconSize + badgeTextWidth + 32f * scale
        val badgeH = 32f * scale
        val badgeTop = logoTop + 48f * scale
        val badgeRect = RectF(brandX, badgeTop, brandX + badgeW, badgeTop + badgeH)

        val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(badgeRect, 10f * scale, 10f * scale, badgeBgPaint)

        val badgeContentColor = if (isLightColor(accentColor)) Color.parseColor("#0F172A") else Color.WHITE
        cardTypePaint.color = badgeContentColor

        drawVectorIcon(
            canvas = canvas,
            iconType = CardIconType.MEMBERSHIP_CARD,
            cx = badgeRect.left + 12f * scale + iconSize / 2f,
            cy = badgeRect.centerY(),
            size = iconSize,
            color = badgeContentColor,
            scale = scale
        )
        canvas.drawText(
            cardTypeLabel,
            badgeRect.left + 12f * scale + iconSize + 8f * scale,
            badgeRect.centerY() + 6.5f * scale,
            cardTypePaint
        )

        // Subtle template style subtitle next to card type badge
        val dotAndStylePaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = subtitleTypeface
            color = secondaryTextColor
            textSize = 16.5f * scale
            letterSpacing = 0.02f
        }
        val styleStartX = badgeRect.right + 14f * scale
        val maxStyleWidth = (width - styleStartX - 56f * scale).coerceAtLeast(80f)
        val fittedStyle = fitAndEllipsizeText(
            text = template.templateName,
            paint = dotAndStylePaint,
            maxWidth = maxStyleWidth,
            minTextSize = 13f * scale
        )
        canvas.drawText(fittedStyle, styleStartX, badgeRect.centerY() + 6f * scale, dotAndStylePaint)

        // Crisp header divider line
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            alpha = if (isLight) 110 else 130
            strokeWidth = 2f * scale
        }
        canvas.drawLine(leftStart, 130f * scale, width - 56f * scale, 130f * scale, dividerPaint)
    }

    private fun isLightColor(color: Int): Boolean {
        val lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0
        return lum > 0.62
    }

    private fun drawLogoBox(
        canvas: Canvas,
        logoBitmap: Bitmap?,
        logoRect: RectF,
        accentColor: Int,
        scale: Float
    ) {
        val clip = Path().apply {
            addRoundRect(logoRect, 16f * scale, 16f * scale, Path.Direction.CW)
        }
        canvas.save()
        canvas.clipPath(clip)
        if (logoBitmap != null) {
            drawTransformedPhotoInRect(canvas, logoBitmap, logoRect, 1f, 0f, 0f)
        } else {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
            canvas.drawRect(logoRect, p)
        }
        canvas.restore()

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.STROKE
            strokeWidth = 2.6f * scale
        }
        canvas.drawRoundRect(logoRect, 16f * scale, 16f * scale, borderPaint)
    }

    private fun drawPhotoSlotByShape(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        labelTypeface: Typeface
    ) {
        val slot = template.imageSlot
        val slotLeft = width * slot.xRatio
        val slotTop = height * slot.yRatio
        val slotW = width * slot.widthRatio
        val slotH = height * slot.heightRatio
        val slotRect = RectF(slotLeft, slotTop, slotLeft + slotW, slotTop + slotH)

        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))
        val isLight = isLightPalette(template)

        // Outer halo / shadow so the portrait frame stands out as Visual Priority #2
        val shadowRect = RectF(
            slotRect.left - 5f * scale,
            slotRect.top - 5f * scale,
            slotRect.right + 5f * scale,
            slotRect.bottom + 5f * scale
        )
        val outerPath = createFrameShapePath(shadowRect, slot.shape, width * slot.cornerRadiusRatio + 4f * scale)
        val outerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            alpha = if (isLight) 48 else 72
            style = Paint.Style.FILL
        }
        canvas.drawPath(outerPath, outerGlowPaint)

        val shapePath = createFrameShapePath(slotRect, slot.shape, width * slot.cornerRadiusRatio)

        // Slot backing fill
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isLight) Color.parseColor("#E2E8F0") else Color.parseColor("#1E293B")
            style = Paint.Style.FILL
        }
        canvas.drawPath(shapePath, bgPaint)

        // Decode original member photo at resolution matching output canvas (1x, 1.5x, 2x)
        val reqDecodeSide = (max(width, height) * 0.95f).toInt().coerceIn(960, 2400)
        val photoBitmap = payload.photoPath
            ?.takeIf { File(it).exists() }
            ?.let { decodeSampledBitmap(it, reqDecodeSide, reqDecodeSide) }

        canvas.save()
        canvas.clipPath(shapePath)
        if (photoBitmap != null) {
            drawTransformedPhotoInRect(
                canvas = canvas,
                photoBitmap = photoBitmap,
                destRect = slotRect,
                cropScale = payload.cropScale,
                cropOffsetX = payload.cropOffsetX,
                cropOffsetY = payload.cropOffsetY
            )
            photoBitmap.recycle()
        } else {
            // Refined portrait placeholder inside the exact frame shape for template previewing
            val silPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accentColor
                alpha = if (isLight) 95 else 115
                style = Paint.Style.FILL
            }
            val cx = slotRect.centerX()
            val cy = slotRect.centerY() - 16f * scale
            val headR = min(slotRect.width(), slotRect.height()) * 0.16f
            canvas.drawCircle(cx, cy - headR * 0.78f, headR, silPaint)
            canvas.drawOval(
                RectF(cx - headR * 1.85f, cy + headR * 0.42f, cx + headR * 1.85f, cy + headR * 2.55f),
                silPaint
            )
            val hintPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = labelTypeface
                textSize = 18f * scale
                color = if (isLight) Color.parseColor("#1E293B") else Color.WHITE
                alpha = 225
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("ẢNH HỘI VIÊN", cx, slotRect.bottom - 26f * scale, hintPaint)
        }
        canvas.restore()

        // Crisp double border around photo slot
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.STROKE
            strokeWidth = 4.2f * scale
        }
        canvas.drawPath(shapePath, borderPaint)
    }

    fun createFrameShapePath(
        rect: RectF,
        shape: PhotoFrameShape,
        cornerRadius: Float
    ): Path {
        val path = Path()
        when (shape) {
            PhotoFrameShape.ROUNDED_RECT -> {
                path.addRoundRect(rect, cornerRadius, cornerRadius, Path.Direction.CW)
            }
            PhotoFrameShape.CIRCLE -> {
                val r = min(rect.width(), rect.height()) / 2f
                path.addCircle(rect.centerX(), rect.centerY(), r, Path.Direction.CW)
            }
            PhotoFrameShape.OVAL_PILL -> {
                val r = rect.width() / 2f
                path.addRoundRect(rect, r, r, Path.Direction.CW)
            }
            PhotoFrameShape.ARCH_TOP -> {
                val topRadius = rect.width() / 2f
                val bottomRadius = min(cornerRadius, 24f)
                val radii = floatArrayOf(
                    topRadius, topRadius,
                    topRadius, topRadius,
                    bottomRadius, bottomRadius,
                    bottomRadius, bottomRadius
                )
                path.addRoundRect(rect, radii, Path.Direction.CW)
            }
            PhotoFrameShape.CHAMFERED_OCTAGON -> {
                val cut = min(rect.width(), rect.height()) * 0.13f
                path.moveTo(rect.left + cut, rect.top)
                path.lineTo(rect.right - cut, rect.top)
                path.lineTo(rect.right, rect.top + cut)
                path.lineTo(rect.right, rect.bottom - cut)
                path.lineTo(rect.right - cut, rect.bottom)
                path.lineTo(rect.left + cut, rect.bottom)
                path.lineTo(rect.left, rect.bottom - cut)
                path.lineTo(rect.left, rect.top + cut)
                path.close()
            }
            PhotoFrameShape.CUT_CORNER -> {
                val cut = min(rect.width(), rect.height()) * 0.14f
                path.moveTo(rect.left + cut, rect.top)
                path.lineTo(rect.right, rect.top)
                path.lineTo(rect.right, rect.bottom - cut)
                path.lineTo(rect.right - cut, rect.bottom)
                path.lineTo(rect.left, rect.bottom)
                path.lineTo(rect.left, rect.top + cut)
                path.close()
            }
        }
        return path
    }

    private fun drawFieldsByStyle(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        headingTypeface: Typeface,
        labelTypeface: Typeface,
        valueTypeface: Typeface
    ) {
        val accentColor = parseHexColorSafe(template.accentColorHex, Color.parseColor("#E11D48"))
        val primaryTextColor = parseHexColorSafe(template.textPrimaryHex, Color.WHITE)
        val secondaryTextColor = parseHexColorSafe(template.textSecondaryHex, Color.parseColor("#CBD5E1"))
        val priceColor = parseHexColorSafe(template.priceHighlightHex, Color.parseColor("#FBBF24"))
        val isLight = isLightPalette(template)

        val contentLeft = width * template.contentLeftRatio
        val contentRight = width * template.contentRightRatio
        val maxContentWidth = (contentRight - contentLeft).coerceAtLeast(240f * scale)
        val colGap = 18f * scale
        val halfColWidth = (maxContentWidth - colGap) / 2f
        val col2Left = contentLeft + halfColWidth + colGap

        // =========================================================================
        // PRIORITY #1: MEMBER FULL NAME BLOCK (Large, High-Contrast, Full Vietnamese Diacritics)
        // =========================================================================
        val nameBoxRect = RectF(contentLeft, 166f * scale, contentRight, 260f * scale)
        val nameBoxFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isLight) {
                Color.argb(24, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            } else {
                Color.argb(46, 255, 255, 255)
            }
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(nameBoxRect, 14f * scale, 14f * scale, nameBoxFill)

        val nameAccentBar = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(
            RectF(nameBoxRect.left, nameBoxRect.top, nameBoxRect.left + 8f * scale, nameBoxRect.bottom),
            4f * scale,
            4f * scale,
            nameAccentBar
        )

        val nameInnerLeft = contentLeft + 20f * scale
        val userIconSize = 19f * scale
        drawVectorIcon(
            canvas = canvas,
            iconType = CardIconType.USER,
            cx = nameInnerLeft + userIconSize / 2f,
            cy = 188f * scale,
            size = userIconSize,
            color = accentColor,
            scale = scale
        )

        val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = labelTypeface
            color = secondaryTextColor
            textSize = 15f * scale
            letterSpacing = 0.06f
        }
        canvas.drawText(
            "HỘI VIÊN CHÍNH THỨC",
            nameInnerLeft + userIconSize + 8f * scale,
            194f * scale,
            labelPaint
        )

        val namePaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = headingTypeface
            color = primaryTextColor
            textSize = 40f * scale
        }
        val displayName = payload.fullName.trim().ifEmpty { "HỌ VÀ TÊN" }.uppercase()
        val fittedName = fitAndEllipsizeText(
            text = displayName,
            paint = namePaint,
            maxWidth = maxContentWidth - 32f * scale,
            minTextSize = 22f * scale
        )
        canvas.drawText(fittedName, nameInnerLeft, 242f * scale, namePaint)

        // =========================================================================
        // PRIORITY #3, #4, #5, #6, #7: DYNAMIC FIELDS & HIGHLIGHT BADGES
        // =========================================================================
        val dynamicDurationText = when {
            payload.durationMonths != null && payload.durationMonths > 0 -> "${payload.durationMonths} THÁNG"
            payload.packageName.isNotBlank() -> payload.packageName.uppercase()
            else -> "1 THÁNG"
        }

        when (payload.cardType) {
            CardType.GYM_MONTHLY -> {
                // Row 1: Thời hạn gói (Highlight Badge - Priority #3) + Ngày hết hạn (Highlight Box - Priority #4)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 276f * scale, contentLeft + halfColWidth, 382f * scale),
                    iconType = CardIconType.CLOCK,
                    label = "THỜI HẠN GÓI",
                    value = dynamicDurationText,
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = true
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 276f * scale, contentRight, 382f * scale),
                    iconType = CardIconType.CALENDAR_CHECK,
                    label = "NGÀY HẾT HẠN",
                    value = payload.endDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = false
                )

                // Row 2: Giá tiền (Highlight Badge - Priority #5) + Số điện thoại (Priority #6)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 398f * scale, contentLeft + halfColWidth, 504f * scale),
                    iconType = CardIconType.WALLET,
                    label = "GIÁ TIỀN",
                    value = FormattersAndValidators.formatVnd(payload.priceVnd),
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = priceColor,
                    accentColor = priceColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = true
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 398f * scale, contentRight, 504f * scale),
                    iconType = CardIconType.PHONE,
                    label = "ĐIỆN THOẠI",
                    value = payload.phoneNumber.ifBlank { "—" },
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = false
                )

                // Row 3: Giới tính / Nhóm (Priority #7) + Ngày bắt đầu (Priority #7)
                val groupText = (payload.targetGroup ?: TargetGroup.NAM).displayLabel
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 520f * scale, contentLeft + halfColWidth, 626f * scale),
                    iconType = CardIconType.GROUP,
                    label = "NHÓM THẺ",
                    value = groupText,
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = false
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 520f * scale, contentRight, 626f * scale),
                    iconType = CardIconType.CALENDAR,
                    label = "NGÀY BẮT ĐẦU",
                    value = payload.startDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = false
                )
            }

            CardType.GYM_PT -> {
                // Row 1: Tổng số buổi PT (Prominent Highlight Badge - Priority #3) + Giá tiền (Highlight Badge - Priority #5)
                val sessionsText = "${payload.totalPtSessions ?: 1} BUỔI PT"
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 282f * scale, contentLeft + halfColWidth, 424f * scale),
                    iconType = CardIconType.DUMBBELL,
                    label = "SỐ BUỔI PT ĐĂNG KÝ",
                    value = sessionsText,
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = true
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 282f * scale, contentRight, 424f * scale),
                    iconType = CardIconType.WALLET,
                    label = "GIÁ TIỀN GÓI PT",
                    value = FormattersAndValidators.formatVnd(payload.priceVnd),
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = priceColor,
                    accentColor = priceColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = true
                )

                // Row 2: Số điện thoại liên hệ (Full width - Priority #6)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 446f * scale, contentRight, 574f * scale),
                    iconType = CardIconType.PHONE,
                    label = "SỐ ĐIỆN THOẠI LIÊN HỆ",
                    value = payload.phoneNumber.ifBlank { "—" },
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = false
                )
            }

            CardType.YOGA_MONTHLY -> {
                // Row 1: Thời hạn gói (Highlight Badge - Priority #3) +Giá tiền (Highlight Badge - Priority #5)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 276f * scale, contentLeft + halfColWidth, 382f * scale),
                    iconType = CardIconType.CLOCK,
                    label = "THỜI HẠN GÓI",
                    value = dynamicDurationText,
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = true
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 276f * scale, contentRight, 382f * scale),
                    iconType = CardIconType.WALLET,
                    label = "GIÁ TIỀN",
                    value = FormattersAndValidators.formatVnd(payload.priceVnd),
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = priceColor,
                    accentColor = priceColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = true
                )

                // Row 2: Ngày bắt đầu + Ngày hết hạn (Priority #4)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 398f * scale, contentLeft + halfColWidth, 504f * scale),
                    iconType = CardIconType.CALENDAR,
                    label = "NGÀY BẮT ĐẦU",
                    value = payload.startDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = valueTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = false
                )
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(col2Left, 398f * scale, contentRight, 504f * scale),
                    iconType = CardIconType.CALENDAR_CHECK,
                    label = "NGÀY HẾT HẠN",
                    value = payload.endDateFormatted?.ifBlank { "—" } ?: "—",
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = accentColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = false
                )

                // Row 3: Số điện thoại (Priority #6)
                drawStyledFieldBox(
                    canvas = canvas,
                    rect = RectF(contentLeft, 520f * scale, contentRight, 626f * scale),
                    iconType = CardIconType.PHONE,
                    label = "SỐ ĐIỆN THOẠI HỘI VIÊN",
                    value = payload.phoneNumber.ifBlank { "—" },
                    scale = scale,
                    boxStyle = template.infoBoxStyle,
                    labelColor = secondaryTextColor,
                    valueColor = primaryTextColor,
                    accentColor = accentColor,
                    labelTypeface = labelTypeface,
                    valueTypeface = headingTypeface,
                    isLightCard = isLight,
                    isHighlightBadge = false
                )
            }
        }
    }

    private fun drawStyledFieldBox(
        canvas: Canvas,
        rect: RectF,
        iconType: CardIconType,
        label: String,
        value: String,
        scale: Float,
        boxStyle: InfoBoxStyle,
        labelColor: Int,
        valueColor: Int,
        accentColor: Int,
        labelTypeface: Typeface,
        valueTypeface: Typeface,
        isLightCard: Boolean,
        isHighlightBadge: Boolean
    ) {
        val cornerR = when (boxStyle) {
            InfoBoxStyle.PILL_CARD -> rect.height() * 0.30f
            InfoBoxStyle.OUTLINE_SHARP, InfoBoxStyle.EDITORIAL_COLUMN -> 10f * scale
            else -> 16f * scale
        }

        if (isHighlightBadge) {
            // Prominent Highlight Badge for Duration / PT Sessions / Price
            val badgeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (isLightCard) {
                    Color.argb(34, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
                } else {
                    Color.argb(58, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
                }
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(rect, cornerR, cornerR, badgeFill)

            val badgeStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accentColor
                alpha = if (isLightCard) 195 else 220
                style = Paint.Style.STROKE
                strokeWidth = 2.4f * scale
            }
            canvas.drawRoundRect(rect, cornerR, cornerR, badgeStroke)
        } else {
            when (boxStyle) {
                InfoBoxStyle.FILLED_GLASS -> {
                    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLightCard) Color.WHITE else Color.parseColor("#0F172A")
                        alpha = if (isLightCard) 215 else 155
                        style = Paint.Style.FILL
                    }
                    canvas.drawRoundRect(rect, cornerR, cornerR, bgPaint)
                    val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = accentColor
                        alpha = 95
                        style = Paint.Style.STROKE
                        strokeWidth = 1.6f * scale
                    }
                    canvas.drawRoundRect(rect, cornerR, cornerR, strokePaint)
                }

                InfoBoxStyle.OUTLINE_SHARP -> {
                    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLightCard) Color.WHITE else Color.parseColor("#0F172A")
                        alpha = if (isLightCard) 225 else 145
                        style = Paint.Style.FILL
                    }
                    canvas.drawRoundRect(rect, cornerR, cornerR, bgPaint)
                    val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = accentColor
                        alpha = 145
                        style = Paint.Style.STROKE
                        strokeWidth = 2f * scale
                    }
                    canvas.drawRoundRect(rect, cornerR, cornerR, strokePaint)
                }

                InfoBoxStyle.MINIMAL_HAIRLINE -> {
                    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLightCard) Color.WHITE else Color.parseColor("#1E293B")
                        alpha = if (isLightCard) 225 else 135
                        style = Paint.Style.FILL
                    }
                    canvas.drawRoundRect(rect, 12f * scale, 12f * scale, bgPaint)
                    val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = accentColor
                        alpha = 140
                        strokeWidth = 2.4f * scale
                    }
                    canvas.drawLine(rect.left + 8f * scale, rect.bottom, rect.right - 8f * scale, rect.bottom, linePaint)
                }

                InfoBoxStyle.PILL_CARD -> {
                    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLightCard) Color.WHITE else Color.parseColor("#1E293B")
                        alpha = if (isLightCard) 225 else 145
                        style = Paint.Style.FILL
                    }
                    canvas.drawRoundRect(rect, cornerR, cornerR, bgPaint)
                    val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = accentColor
                        alpha = 115
                        style = Paint.Style.STROKE
                        strokeWidth = 1.8f * scale
                    }
                    canvas.drawRoundRect(rect, cornerR, cornerR, strokePaint)
                }

                InfoBoxStyle.EDITORIAL_COLUMN -> {
                    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLightCard) Color.WHITE else Color.parseColor("#0F172A")
                        alpha = if (isLightCard) 235 else 155
                        style = Paint.Style.FILL
                    }
                    canvas.drawRoundRect(rect, cornerR, cornerR, bgPaint)
                    val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = accentColor
                        alpha = 255
                        style = Paint.Style.FILL
                    }
                    canvas.drawRoundRect(
                        RectF(rect.left, rect.top, rect.left + 7f * scale, rect.bottom),
                        4f * scale,
                        4f * scale,
                        barPaint
                    )
                }
            }
        }

        val padX = 18f * scale
        val maxValWidth = (rect.width() - padX * 2).coerceAtLeast(60f)

        // Draw crisp vector icon before the field label
        val iconSize = 18.5f * scale
        val labelBaselineY = rect.top + 31f * scale
        val iconCy = labelBaselineY - 6.5f * scale
        drawVectorIcon(
            canvas = canvas,
            iconType = iconType,
            cx = rect.left + padX + iconSize / 2f,
            cy = iconCy,
            size = iconSize,
            color = accentColor,
            scale = scale
        )

        val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = labelTypeface
            color = labelColor
            textSize = 14.5f * scale
            letterSpacing = 0.05f
        }
        val labelX = rect.left + padX + iconSize + 8f * scale
        val fittedLabel = fitAndEllipsizeText(
            text = label,
            paint = labelPaint,
            maxWidth = (rect.right - labelX - 8f * scale).coerceAtLeast(40f),
            minTextSize = 12f * scale
        )
        canvas.drawText(fittedLabel, labelX, labelBaselineY, labelPaint)

        val valPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = valueTypeface
            color = valueColor
            textSize = if (isHighlightBadge) 29.5f * scale else 27.5f * scale
        }
        val fittedVal = fitAndEllipsizeText(
            text = value,
            paint = valPaint,
            maxWidth = maxValWidth,
            minTextSize = 18f * scale
        )
        canvas.drawText(fittedVal, rect.left + padX, rect.bottom - 20f * scale, valPaint)
    }

    /**
     * Unified Vector Icon Renderer (Section 8 of V4.0 Spec):
     * Draws resolution-independent vector icons with uniform stroke thickness & high contrast.
     */
    private fun drawVectorIcon(
        canvas: Canvas,
        iconType: CardIconType,
        cx: Float,
        cy: Float,
        size: Float,
        color: Int,
        scale: Float
    ) {
        val r = size / 2f
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.STROKE
            strokeWidth = 2.3f * scale
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        when (iconType) {
            CardIconType.USER -> {
                canvas.drawCircle(cx, cy - r * 0.34f, r * 0.38f, strokePaint)
                val arcRect = RectF(cx - r * 0.78f, cy + r * 0.12f, cx + r * 0.78f, cy + r * 1.15f)
                canvas.drawArc(arcRect, 180f, 180f, false, strokePaint)
            }

            CardIconType.GROUP -> {
                canvas.drawCircle(cx - r * 0.22f, cy - r * 0.32f, r * 0.34f, strokePaint)
                val primaryArc = RectF(cx - r * 0.85f, cy + r * 0.14f, cx + r * 0.40f, cy + r * 1.05f)
                canvas.drawArc(primaryArc, 180f, 180f, false, strokePaint)
                canvas.drawCircle(cx + r * 0.42f, cy - r * 0.22f, r * 0.26f, strokePaint)
                val secArc = RectF(cx + r * 0.05f, cy + r * 0.24f, cx + r * 0.92f, cy + r * 1.05f)
                canvas.drawArc(secArc, 200f, 140f, false, strokePaint)
            }

            CardIconType.PHONE -> {
                val phoneRect = RectF(cx - r * 0.56f, cy - r * 0.86f, cx + r * 0.56f, cy + r * 0.86f)
                canvas.drawRoundRect(phoneRect, 3.5f * scale, 3.5f * scale, strokePaint)
                canvas.drawLine(cx - r * 0.20f, cy - r * 0.58f, cx + r * 0.20f, cy - r * 0.58f, strokePaint)
                canvas.drawPoint(cx, cy + r * 0.56f, strokePaint)
            }

            CardIconType.CALENDAR -> {
                val calRect = RectF(cx - r * 0.82f, cy - r * 0.68f, cx + r * 0.82f, cy + r * 0.82f)
                canvas.drawRoundRect(calRect, 3.5f * scale, 3.5f * scale, strokePaint)
                canvas.drawLine(calRect.left, cy - r * 0.22f, calRect.right, cy - r * 0.22f, strokePaint)
                canvas.drawLine(cx - r * 0.42f, cy - r * 0.92f, cx - r * 0.42f, cy - r * 0.48f, strokePaint)
                canvas.drawLine(cx + r * 0.42f, cy - r * 0.92f, cx + r * 0.42f, cy - r * 0.48f, strokePaint)
            }

            CardIconType.CALENDAR_CHECK -> {
                val calRect = RectF(cx - r * 0.82f, cy - r * 0.68f, cx + r * 0.82f, cy + r * 0.82f)
                canvas.drawRoundRect(calRect, 3.5f * scale, 3.5f * scale, strokePaint)
                canvas.drawLine(calRect.left, cy - r * 0.22f, calRect.right, cy - r * 0.22f, strokePaint)
                canvas.drawLine(cx - r * 0.42f, cy - r * 0.92f, cx - r * 0.42f, cy - r * 0.48f, strokePaint)
                canvas.drawLine(cx + r * 0.42f, cy - r * 0.92f, cx + r * 0.42f, cy - r * 0.48f, strokePaint)
                val checkPath = Path().apply {
                    moveTo(cx - r * 0.36f, cy + r * 0.28f)
                    lineTo(cx - r * 0.08f, cy + r * 0.54f)
                    lineTo(cx + r * 0.42f, cy + r * 0.04f)
                }
                canvas.drawPath(checkPath, strokePaint)
            }

            CardIconType.CLOCK -> {
                canvas.drawCircle(cx, cy, r * 0.82f, strokePaint)
                canvas.drawLine(cx, cy, cx, cy - r * 0.46f, strokePaint)
                canvas.drawLine(cx, cy, cx + r * 0.38f, cy + r * 0.20f, strokePaint)
            }

            CardIconType.DUMBBELL -> {
                canvas.drawLine(cx - r * 0.88f, cy, cx + r * 0.88f, cy, strokePaint)
                canvas.drawLine(cx - r * 0.56f, cy - r * 0.58f, cx - r * 0.56f, cy + r * 0.58f, strokePaint)
                canvas.drawLine(cx - r * 0.82f, cy - r * 0.38f, cx - r * 0.82f, cy + r * 0.38f, strokePaint)
                canvas.drawLine(cx + r * 0.56f, cy - r * 0.58f, cx + r * 0.56f, cy + r * 0.58f, strokePaint)
                canvas.drawLine(cx + r * 0.82f, cy - r * 0.38f, cx + r * 0.82f, cy + r * 0.38f, strokePaint)
            }

            CardIconType.WALLET -> {
                val wRect = RectF(cx - r * 0.85f, cy - r * 0.62f, cx + r * 0.85f, cy + r * 0.68f)
                canvas.drawRoundRect(wRect, 3.5f * scale, 3.5f * scale, strokePaint)
                val claspRect = RectF(cx + r * 0.18f, cy - r * 0.22f, cx + r * 0.85f, cy + r * 0.26f)
                canvas.drawRoundRect(claspRect, 2.5f * scale, 2.5f * scale, strokePaint)
            }

            CardIconType.MEMBERSHIP_CARD -> {
                val cRect = RectF(cx - r * 0.88f, cy - r * 0.62f, cx + r * 0.88f, cy + r * 0.62f)
                canvas.drawRoundRect(cRect, 3.5f * scale, 3.5f * scale, strokePaint)
                canvas.drawLine(cRect.left, cy - r * 0.16f, cRect.right, cy - r * 0.16f, strokePaint)
                canvas.drawLine(cx - r * 0.52f, cy + r * 0.24f, cx - r * 0.10f, cy + r * 0.24f, strokePaint)
            }
        }
    }

    private fun drawFooterBar(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        payload: CardRenderPayload,
        template: TemplateMetadata,
        footerTypeface: Typeface
    ) {
        val secondaryTextColor = parseHexColorSafe(template.textSecondaryHex, Color.LTGRAY)
        val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = footerTypeface
            textSize = 16.5f * scale
            color = secondaryTextColor
            alpha = 220
        }
        val startX = when {
            template.artworkPattern == ArtworkPatternStyle.G3_BOLD_SPORT_EDITORIAL -> 96f * scale
            template.artworkPattern == ArtworkPatternStyle.P3_BLACK_TITANIUM -> 82f * scale
            else -> 64f * scale
        }
        val contact = payload.brandContact.trim().ifEmpty { payload.brandName }
        val fittedContact = fitAndEllipsizeText(
            text = contact,
            paint = footerPaint,
            maxWidth = width - startX - 56f * scale,
            minTextSize = 13.5f * scale
        )
        canvas.drawText(fittedContact, startX, height - 34f * scale, footerPaint)
    }

    fun fitAndEllipsizeText(
        text: String,
        paint: TextPaint,
        maxWidth: Float,
        minTextSize: Float
    ): String {
        if (text.isEmpty() || maxWidth <= 0f) return text
        var currentSize = paint.textSize
        while (paint.measureText(text) > maxWidth && currentSize > minTextSize) {
            currentSize = (currentSize - 1.5f).coerceAtLeast(minTextSize)
            paint.textSize = currentSize
        }
        return if (paint.measureText(text) > maxWidth) {
            TextUtils.ellipsize(text, paint, maxWidth, TextUtils.TruncateAt.END).toString()
        } else {
            text
        }
    }

    private fun drawTransformedPhotoInRect(
        canvas: Canvas,
        photoBitmap: Bitmap,
        destRect: RectF,
        cropScale: Float,
        cropOffsetX: Float,
        cropOffsetY: Float
    ) {
        val bw = photoBitmap.width.toFloat().coerceAtLeast(1f)
        val bh = photoBitmap.height.toFloat().coerceAtLeast(1f)
        val baseScale = max(destRect.width() / bw, destRect.height() / bh)
        val userScale = cropScale.coerceIn(0.5f, 5.0f)
        val totalScale = baseScale * userScale

        val scaledW = bw * totalScale
        val scaledH = bh * totalScale

        val dx = destRect.centerX() - (scaledW / 2f) + (cropOffsetX * destRect.width())
        val dy = destRect.centerY() - (scaledH / 2f) + (cropOffsetY * destRect.height())

        val matrix = Matrix().apply {
            postScale(totalScale, totalScale)
            postTranslate(dx, dy)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(photoBitmap, matrix, paint)
    }

    fun decodeSampledBitmap(path: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        return try {
            val file = File(path)
            if (!file.exists()) return null
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, options)
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
            options.inJustDecodeBounds = false
            options.inPreferredConfig = Bitmap.Config.ARGB_8888
            BitmapFactory.decodeFile(path, options)
        } catch (_: Exception) {
            null
        }
    }

    private fun calculateInSampleSize(
        options: BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    fun parseHexColorSafe(hex: String, fallback: Int): Int {
        return try {
            Color.parseColor(hex.trim())
        } catch (_: Exception) {
            fallback
        }
    }
}
