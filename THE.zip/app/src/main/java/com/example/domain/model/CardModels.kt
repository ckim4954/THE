package com.example.domain.model

enum class CardType(
    val code: String,
    val displayTitle: String,
    val cardBadgeText: String,
    val subtitleVi: String
) {
    GYM_MONTHLY(
        code = "GYM_MONTHLY",
        displayTitle = "Gym tháng",
        cardBadgeText = "GYM MONTHLY",
        subtitleVi = "Thẻ tập Gym theo tháng (Nam / Nữ / Trẻ em)"
    ),
    GYM_PT(
        code = "GYM_PT",
        displayTitle = "Gym PT",
        cardBadgeText = "PERSONAL TRAINING",
        subtitleVi = "Thẻ tập Huấn luyện viên cá nhân theo số buổi"
    ),
    YOGA_MONTHLY(
        code = "YOGA_MONTHLY",
        displayTitle = "Yoga tháng",
        cardBadgeText = "YOGA MONTHLY",
        subtitleVi = "Thẻ tập Yoga theo tháng"
    );

    companion object {
        fun fromCode(code: String): CardType =
            entries.firstOrNull { it.code == code } ?: GYM_MONTHLY
    }
}

enum class TargetGroup(
    val code: String,
    val displayLabel: String
) {
    NAM("NAM", "Nam"),
    NU("NU", "Nữ"),
    TRE_EM("TRE_EM", "Trẻ em");

    companion object {
        fun fromCode(code: String?): TargetGroup? =
            entries.firstOrNull { it.code == code }
    }
}

enum class ThemeMode(
    val code: String,
    val displayLabel: String
) {
    LIGHT("LIGHT", "Light Mode (Sáng)"),
    DARK("DARK", "Dark Mode (Tối)"),
    SYSTEM("SYSTEM", "System Default (Mặc định hệ thống)");

    companion object {
        fun fromCode(code: String?): ThemeMode =
            entries.firstOrNull { it.code == code } ?: SYSTEM
    }
}

enum class ExportResolution(
    val code: String,
    val widthPx: Int,
    val heightPx: Int,
    val displayLabel: String
) {
    STANDARD_HD("STANDARD_HD", 1200, 750, "Tiêu chuẩn (1200 × 750 px • Tỷ lệ 8:5)"),
    ULTRA_HD("ULTRA_HD", 2400, 1500, "Chất lượng cao 2X (2400 × 1500 px • Tỷ lệ 8:5)");

    companion object {
        fun fromCode(code: String?): ExportResolution =
            entries.firstOrNull { it.code == code } ?: STANDARD_HD
    }
}

data class BrandConfig(
    val brandName: String = "89 FITNESS & YOGA",
    val contactInfo: String = "Hội viên chính thức • 89 FITNESS & YOGA",
    val customLogoPath: String? = null
)

data class ImageSlotSpec(
    val xRatio: Float = 0.055f,
    val yRatio: Float = 0.21f,
    val widthRatio: Float = 0.275f,
    val heightRatio: Float = 0.64f,
    val cornerRadiusRatio: Float = 0.03f,
    val cropMode: String = "CENTER_CROP_FIXED_FRAME"
)

data class TextFieldSpec(
    val fieldKey: String,
    val labelVi: String,
    val xRatio: Float,
    val yRatio: Float,
    val fontFamily: String = "Montserrat",
    val fontSizePx: Float = 32f,
    val minFontSizePx: Float = 22f,
    val textAlign: String = "LEFT",
    val textColorHex: String = "#FFFFFF",
    val maxWidthRatio: Float = 0.56f,
    val overflowBehavior: String = "AUTO_SHRINK_THEN_ELLIPSIZE",
    val isVisible: Boolean = true
)

data class TemplateMetadata(
    val templateId: String,
    val templateVersion: Int = 1,
    val cardType: CardType,
    val templateName: String,
    val canvasWidth: Int = 1200,
    val canvasHeight: Int = 750,
    val backgroundColorHex: String,
    val secondaryColorHex: String,
    val accentColorHex: String,
    val textPrimaryHex: String,
    val textSecondaryHex: String,
    val customBackgroundPath: String? = null,
    val imageSlot: ImageSlotSpec = ImageSlotSpec(),
    val textFields: List<TextFieldSpec> = emptyList()
)

data class CardDraft(
    val editingCardId: Long? = null,
    val cardType: CardType = CardType.GYM_MONTHLY,
    val targetGroup: TargetGroup = TargetGroup.NAM,
    val selectedPackageId: Long? = null,
    val packageName: String = "",
    val fullName: String = "",
    val phoneNumber: String = "",
    val startDate: String = "",
    val endDate: String = "",
    val totalPtSessions: String = "",
    val priceVndText: String = "",
    val originalPhotoId: Long? = null,
    val originalPhotoPath: String? = null,
    val croppedPhotoPath: String? = null,
    val cropScale: Float = 1f,
    val cropOffsetX: Float = 0f,
    val cropOffsetY: Float = 0f
)
